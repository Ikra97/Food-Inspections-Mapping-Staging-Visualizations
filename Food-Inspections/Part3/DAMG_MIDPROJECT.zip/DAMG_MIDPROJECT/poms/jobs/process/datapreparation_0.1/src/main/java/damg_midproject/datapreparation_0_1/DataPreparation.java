
package damg_midproject.datapreparation_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: DataPreparation Purpose: Data Prep - From Staging<br>
 * Description: Data Prep from Staging <br>
 * 
 * @author gorle.g@northeastern.edu
 * @version 8.0.1.20230913_0925-patch
 * @status
 */
public class DataPreparation implements TalendJob {
	static {
		System.setProperty("TalendJob.log", "DataPreparation.log");
	}

	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager
			.getLogger(DataPreparation.class);

	protected static void logIgnoredError(String message, Throwable cause) {
		log.error(message, cause);

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "DataPreparation";
	private final String projectName = "DAMG_MIDPROJECT";
	public Integer errorCode = null;
	private String currentComponent = "";

	private String cLabel = null;

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName,
			"_g3hlEG_FEe6h4vxO7oEA5w", "0.1");
	private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

	private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;

		private String currentComponent = null;
		private String cLabel = null;

		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		private TalendException(Exception e, String errorComponent, String errorComponentLabel,
				final java.util.Map<String, Object> globalMap) {
			this(e, errorComponent, globalMap);
			this.cLabel = errorComponentLabel;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					DataPreparation.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(DataPreparation.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
						if (enableLogStash) {
							talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
							talendJobLogProcess(globalMap);
						}
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tDBInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFilterRow_6_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tExtractRegexFields_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tNormalize_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tHashOutput_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tNormalize_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tHashOutput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tHashOutput_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tHashInput_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tHashOutput_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tHashInput_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUniqRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tHashInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tHashInput_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row10_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row13_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendJobLog_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		talendJobLog_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tHashInput_2_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tHashInput_3_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void talendJobLog_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public String ViolationCodes;

		public String getViolationCodes() {
			return this.ViolationCodes;
		}

		public Boolean ViolationCodesIsNullable() {
			return true;
		}

		public Boolean ViolationCodesIsKey() {
			return false;
		}

		public Integer ViolationCodesLength() {
			return 150;
		}

		public Integer ViolationCodesPrecision() {
			return 0;
		}

		public String ViolationCodesDefault() {

			return null;

		}

		public String ViolationCodesComment() {

			return "";

		}

		public String ViolationCodesPattern() {

			return "";

		}

		public String ViolationCodesOriginalDbColumnName() {

			return "ViolationCodes";

		}

		public Integer Violation_ID;

		public Integer getViolation_ID() {
			return this.Violation_ID;
		}

		public Boolean Violation_IDIsNullable() {
			return true;
		}

		public Boolean Violation_IDIsKey() {
			return false;
		}

		public Integer Violation_IDLength() {
			return null;
		}

		public Integer Violation_IDPrecision() {
			return null;
		}

		public String Violation_IDDefault() {

			return null;

		}

		public String Violation_IDComment() {

			return "";

		}

		public String Violation_IDPattern() {

			return "";

		}

		public String Violation_IDOriginalDbColumnName() {

			return "Violation_ID";

		}

		public String InspectionId;

		public String getInspectionId() {
			return this.InspectionId;
		}

		public Boolean InspectionIdIsNullable() {
			return true;
		}

		public Boolean InspectionIdIsKey() {
			return false;
		}

		public Integer InspectionIdLength() {
			return 9;
		}

		public Integer InspectionIdPrecision() {
			return 0;
		}

		public String InspectionIdDefault() {

			return null;

		}

		public String InspectionIdComment() {

			return "";

		}

		public String InspectionIdPattern() {

			return "";

		}

		public String InspectionIdOriginalDbColumnName() {

			return "InspectionId";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.ViolationCodes = readString(dis);

					this.Violation_ID = readInteger(dis);

					this.InspectionId = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.ViolationCodes = readString(dis);

					this.Violation_ID = readInteger(dis);

					this.InspectionId = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.ViolationCodes, dos);

				// Integer

				writeInteger(this.Violation_ID, dos);

				// String

				writeString(this.InspectionId, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.ViolationCodes, dos);

				// Integer

				writeInteger(this.Violation_ID, dos);

				// String

				writeString(this.InspectionId, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("ViolationCodes=" + ViolationCodes);
			sb.append(",Violation_ID=" + String.valueOf(Violation_ID));
			sb.append(",InspectionId=" + InspectionId);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (ViolationCodes == null) {
				sb.append("<null>");
			} else {
				sb.append(ViolationCodes);
			}

			sb.append("|");

			if (Violation_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(Violation_ID);
			}

			sb.append("|");

			if (InspectionId == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionId);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row4Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row11Struct implements routines.system.IPersistableRow<row11Struct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public String ViolationDesc;

		public String getViolationDesc() {
			return this.ViolationDesc;
		}

		public Boolean ViolationDescIsNullable() {
			return true;
		}

		public Boolean ViolationDescIsKey() {
			return false;
		}

		public Integer ViolationDescLength() {
			return 1200;
		}

		public Integer ViolationDescPrecision() {
			return 0;
		}

		public String ViolationDescDefault() {

			return null;

		}

		public String ViolationDescComment() {

			return "";

		}

		public String ViolationDescPattern() {

			return "";

		}

		public String ViolationDescOriginalDbColumnName() {

			return "ViolationDesc";

		}

		public Integer Violation_ID;

		public Integer getViolation_ID() {
			return this.Violation_ID;
		}

		public Boolean Violation_IDIsNullable() {
			return true;
		}

		public Boolean Violation_IDIsKey() {
			return false;
		}

		public Integer Violation_IDLength() {
			return 9;
		}

		public Integer Violation_IDPrecision() {
			return 0;
		}

		public String Violation_IDDefault() {

			return null;

		}

		public String Violation_IDComment() {

			return "";

		}

		public String Violation_IDPattern() {

			return "";

		}

		public String Violation_IDOriginalDbColumnName() {

			return "Violation_ID";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.ViolationDesc = readString(dis);

					this.Violation_ID = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.ViolationDesc = readString(dis);

					this.Violation_ID = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.ViolationDesc, dos);

				// Integer

				writeInteger(this.Violation_ID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.ViolationDesc, dos);

				// Integer

				writeInteger(this.Violation_ID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("ViolationDesc=" + ViolationDesc);
			sb.append(",Violation_ID=" + String.valueOf(Violation_ID));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (ViolationDesc == null) {
				sb.append("<null>");
			} else {
				sb.append(ViolationDesc);
			}

			sb.append("|");

			if (Violation_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(Violation_ID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row11Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class ViolationDescStruct implements routines.system.IPersistableRow<ViolationDescStruct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public String ViolationDesc;

		public String getViolationDesc() {
			return this.ViolationDesc;
		}

		public Boolean ViolationDescIsNullable() {
			return true;
		}

		public Boolean ViolationDescIsKey() {
			return false;
		}

		public Integer ViolationDescLength() {
			return 1200;
		}

		public Integer ViolationDescPrecision() {
			return 0;
		}

		public String ViolationDescDefault() {

			return null;

		}

		public String ViolationDescComment() {

			return "";

		}

		public String ViolationDescPattern() {

			return "";

		}

		public String ViolationDescOriginalDbColumnName() {

			return "ViolationDesc";

		}

		public Integer Violation_ID;

		public Integer getViolation_ID() {
			return this.Violation_ID;
		}

		public Boolean Violation_IDIsNullable() {
			return true;
		}

		public Boolean Violation_IDIsKey() {
			return false;
		}

		public Integer Violation_IDLength() {
			return 9;
		}

		public Integer Violation_IDPrecision() {
			return 0;
		}

		public String Violation_IDDefault() {

			return null;

		}

		public String Violation_IDComment() {

			return "";

		}

		public String Violation_IDPattern() {

			return "";

		}

		public String Violation_IDOriginalDbColumnName() {

			return "Violation_ID";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.ViolationDesc = readString(dis);

					this.Violation_ID = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.ViolationDesc = readString(dis);

					this.Violation_ID = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.ViolationDesc, dos);

				// Integer

				writeInteger(this.Violation_ID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.ViolationDesc, dos);

				// Integer

				writeInteger(this.Violation_ID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("ViolationDesc=" + ViolationDesc);
			sb.append(",Violation_ID=" + String.valueOf(Violation_ID));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (ViolationDesc == null) {
				sb.append("<null>");
			} else {
				sb.append(ViolationDesc);
			}

			sb.append("|");

			if (Violation_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(Violation_ID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(ViolationDescStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class ViolationCodeStruct implements routines.system.IPersistableRow<ViolationCodeStruct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public String ViolationCodes;

		public String getViolationCodes() {
			return this.ViolationCodes;
		}

		public Boolean ViolationCodesIsNullable() {
			return true;
		}

		public Boolean ViolationCodesIsKey() {
			return false;
		}

		public Integer ViolationCodesLength() {
			return 150;
		}

		public Integer ViolationCodesPrecision() {
			return 0;
		}

		public String ViolationCodesDefault() {

			return null;

		}

		public String ViolationCodesComment() {

			return "";

		}

		public String ViolationCodesPattern() {

			return "";

		}

		public String ViolationCodesOriginalDbColumnName() {

			return "ViolationCodes";

		}

		public Integer Violation_ID;

		public Integer getViolation_ID() {
			return this.Violation_ID;
		}

		public Boolean Violation_IDIsNullable() {
			return true;
		}

		public Boolean Violation_IDIsKey() {
			return false;
		}

		public Integer Violation_IDLength() {
			return null;
		}

		public Integer Violation_IDPrecision() {
			return null;
		}

		public String Violation_IDDefault() {

			return null;

		}

		public String Violation_IDComment() {

			return "";

		}

		public String Violation_IDPattern() {

			return "";

		}

		public String Violation_IDOriginalDbColumnName() {

			return "Violation_ID";

		}

		public String InspectionId;

		public String getInspectionId() {
			return this.InspectionId;
		}

		public Boolean InspectionIdIsNullable() {
			return true;
		}

		public Boolean InspectionIdIsKey() {
			return false;
		}

		public Integer InspectionIdLength() {
			return 9;
		}

		public Integer InspectionIdPrecision() {
			return 0;
		}

		public String InspectionIdDefault() {

			return null;

		}

		public String InspectionIdComment() {

			return "";

		}

		public String InspectionIdPattern() {

			return "";

		}

		public String InspectionIdOriginalDbColumnName() {

			return "InspectionId";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.ViolationCodes = readString(dis);

					this.Violation_ID = readInteger(dis);

					this.InspectionId = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.ViolationCodes = readString(dis);

					this.Violation_ID = readInteger(dis);

					this.InspectionId = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.ViolationCodes, dos);

				// Integer

				writeInteger(this.Violation_ID, dos);

				// String

				writeString(this.InspectionId, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.ViolationCodes, dos);

				// Integer

				writeInteger(this.Violation_ID, dos);

				// String

				writeString(this.InspectionId, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("ViolationCodes=" + ViolationCodes);
			sb.append(",Violation_ID=" + String.valueOf(Violation_ID));
			sb.append(",InspectionId=" + InspectionId);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (ViolationCodes == null) {
				sb.append("<null>");
			} else {
				sb.append(ViolationCodes);
			}

			sb.append("|");

			if (Violation_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(Violation_ID);
			}

			sb.append("|");

			if (InspectionId == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionId);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(ViolationCodeStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class Facts_DimensionsStruct implements routines.system.IPersistableRow<Facts_DimensionsStruct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public String BusinessId;

		public String getBusinessId() {
			return this.BusinessId;
		}

		public Boolean BusinessIdIsNullable() {
			return true;
		}

		public Boolean BusinessIdIsKey() {
			return false;
		}

		public Integer BusinessIdLength() {
			return 9;
		}

		public Integer BusinessIdPrecision() {
			return 0;
		}

		public String BusinessIdDefault() {

			return null;

		}

		public String BusinessIdComment() {

			return "";

		}

		public String BusinessIdPattern() {

			return "";

		}

		public String BusinessIdOriginalDbColumnName() {

			return "BusinessId";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 70;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public String Address;

		public String getAddress() {
			return this.Address;
		}

		public Boolean AddressIsNullable() {
			return true;
		}

		public Boolean AddressIsKey() {
			return false;
		}

		public Integer AddressLength() {
			return 40;
		}

		public Integer AddressPrecision() {
			return 0;
		}

		public String AddressDefault() {

			return null;

		}

		public String AddressComment() {

			return "";

		}

		public String AddressPattern() {

			return "";

		}

		public String AddressOriginalDbColumnName() {

			return "Address";

		}

		public String City;

		public String getCity() {
			return this.City;
		}

		public Boolean CityIsNullable() {
			return true;
		}

		public Boolean CityIsKey() {
			return false;
		}

		public Integer CityLength() {
			return 20;
		}

		public Integer CityPrecision() {
			return 0;
		}

		public String CityDefault() {

			return null;

		}

		public String CityComment() {

			return "";

		}

		public String CityPattern() {

			return "";

		}

		public String CityOriginalDbColumnName() {

			return "City";

		}

		public String State;

		public String getState() {
			return this.State;
		}

		public Boolean StateIsNullable() {
			return true;
		}

		public Boolean StateIsKey() {
			return false;
		}

		public Integer StateLength() {
			return 2;
		}

		public Integer StatePrecision() {
			return 0;
		}

		public String StateDefault() {

			return null;

		}

		public String StateComment() {

			return "";

		}

		public String StatePattern() {

			return "";

		}

		public String StateOriginalDbColumnName() {

			return "State";

		}

		public String ZipCode;

		public String getZipCode() {
			return this.ZipCode;
		}

		public Boolean ZipCodeIsNullable() {
			return true;
		}

		public Boolean ZipCodeIsKey() {
			return false;
		}

		public Integer ZipCodeLength() {
			return 10;
		}

		public Integer ZipCodePrecision() {
			return 0;
		}

		public String ZipCodeDefault() {

			return null;

		}

		public String ZipCodeComment() {

			return "";

		}

		public String ZipCodePattern() {

			return "";

		}

		public String ZipCodeOriginalDbColumnName() {

			return "ZipCode";

		}

		public String PhoneNumber;

		public String getPhoneNumber() {
			return this.PhoneNumber;
		}

		public Boolean PhoneNumberIsNullable() {
			return true;
		}

		public Boolean PhoneNumberIsKey() {
			return false;
		}

		public Integer PhoneNumberLength() {
			return 13;
		}

		public Integer PhoneNumberPrecision() {
			return 0;
		}

		public String PhoneNumberDefault() {

			return null;

		}

		public String PhoneNumberComment() {

			return "";

		}

		public String PhoneNumberPattern() {

			return "";

		}

		public String PhoneNumberOriginalDbColumnName() {

			return "PhoneNumber";

		}

		public String InspectionId;

		public String getInspectionId() {
			return this.InspectionId;
		}

		public Boolean InspectionIdIsNullable() {
			return true;
		}

		public Boolean InspectionIdIsKey() {
			return false;
		}

		public Integer InspectionIdLength() {
			return 9;
		}

		public Integer InspectionIdPrecision() {
			return 0;
		}

		public String InspectionIdDefault() {

			return null;

		}

		public String InspectionIdComment() {

			return "";

		}

		public String InspectionIdPattern() {

			return "";

		}

		public String InspectionIdOriginalDbColumnName() {

			return "InspectionId";

		}

		public java.util.Date Date;

		public java.util.Date getDate() {
			return this.Date;
		}

		public Boolean DateIsNullable() {
			return true;
		}

		public Boolean DateIsKey() {
			return false;
		}

		public Integer DateLength() {
			return 19;
		}

		public Integer DatePrecision() {
			return 0;
		}

		public String DateDefault() {

			return null;

		}

		public String DateComment() {

			return "";

		}

		public String DatePattern() {

			return "dd-MM-yyyy";

		}

		public String DateOriginalDbColumnName() {

			return "Date";

		}

		public String InspectionType;

		public String getInspectionType() {
			return this.InspectionType;
		}

		public Boolean InspectionTypeIsNullable() {
			return true;
		}

		public Boolean InspectionTypeIsKey() {
			return false;
		}

		public Integer InspectionTypeLength() {
			return 9;
		}

		public Integer InspectionTypePrecision() {
			return 0;
		}

		public String InspectionTypeDefault() {

			return null;

		}

		public String InspectionTypeComment() {

			return "";

		}

		public String InspectionTypePattern() {

			return "";

		}

		public String InspectionTypeOriginalDbColumnName() {

			return "InspectionType";

		}

		public String Location;

		public String getLocation() {
			return this.Location;
		}

		public Boolean LocationIsNullable() {
			return true;
		}

		public Boolean LocationIsKey() {
			return false;
		}

		public Integer LocationLength() {
			return 100;
		}

		public Integer LocationPrecision() {
			return 0;
		}

		public String LocationDefault() {

			return null;

		}

		public String LocationComment() {

			return "";

		}

		public String LocationPattern() {

			return "";

		}

		public String LocationOriginalDbColumnName() {

			return "Location";

		}

		public String Latitude;

		public String getLatitude() {
			return this.Latitude;
		}

		public Boolean LatitudeIsNullable() {
			return true;
		}

		public Boolean LatitudeIsKey() {
			return false;
		}

		public Integer LatitudeLength() {
			return 10;
		}

		public Integer LatitudePrecision() {
			return null;
		}

		public String LatitudeDefault() {

			return null;

		}

		public String LatitudeComment() {

			return "";

		}

		public String LatitudePattern() {

			return "";

		}

		public String LatitudeOriginalDbColumnName() {

			return "Latitude";

		}

		public String Longitude;

		public String getLongitude() {
			return this.Longitude;
		}

		public Boolean LongitudeIsNullable() {
			return true;
		}

		public Boolean LongitudeIsKey() {
			return false;
		}

		public Integer LongitudeLength() {
			return 10;
		}

		public Integer LongitudePrecision() {
			return null;
		}

		public String LongitudeDefault() {

			return null;

		}

		public String LongitudeComment() {

			return "";

		}

		public String LongitudePattern() {

			return "";

		}

		public String LongitudeOriginalDbColumnName() {

			return "Longitude";

		}

		public java.util.Date DI_CreatedDate;

		public java.util.Date getDI_CreatedDate() {
			return this.DI_CreatedDate;
		}

		public Boolean DI_CreatedDateIsNullable() {
			return true;
		}

		public Boolean DI_CreatedDateIsKey() {
			return false;
		}

		public Integer DI_CreatedDateLength() {
			return 19;
		}

		public Integer DI_CreatedDatePrecision() {
			return 0;
		}

		public String DI_CreatedDateDefault() {

			return null;

		}

		public String DI_CreatedDateComment() {

			return "";

		}

		public String DI_CreatedDatePattern() {

			return "dd-MM-yyyy";

		}

		public String DI_CreatedDateOriginalDbColumnName() {

			return "DI_CreatedDate";

		}

		public String DI_WorkflowFileName;

		public String getDI_WorkflowFileName() {
			return this.DI_WorkflowFileName;
		}

		public Boolean DI_WorkflowFileNameIsNullable() {
			return true;
		}

		public Boolean DI_WorkflowFileNameIsKey() {
			return false;
		}

		public Integer DI_WorkflowFileNameLength() {
			return 255;
		}

		public Integer DI_WorkflowFileNamePrecision() {
			return 0;
		}

		public String DI_WorkflowFileNameDefault() {

			return null;

		}

		public String DI_WorkflowFileNameComment() {

			return "";

		}

		public String DI_WorkflowFileNamePattern() {

			return "";

		}

		public String DI_WorkflowFileNameOriginalDbColumnName() {

			return "DI_WorkflowFileName";

		}

		public String DI_Workflow_ProcessID;

		public String getDI_Workflow_ProcessID() {
			return this.DI_Workflow_ProcessID;
		}

		public Boolean DI_Workflow_ProcessIDIsNullable() {
			return true;
		}

		public Boolean DI_Workflow_ProcessIDIsKey() {
			return false;
		}

		public Integer DI_Workflow_ProcessIDLength() {
			return 30;
		}

		public Integer DI_Workflow_ProcessIDPrecision() {
			return 0;
		}

		public String DI_Workflow_ProcessIDDefault() {

			return null;

		}

		public String DI_Workflow_ProcessIDComment() {

			return "";

		}

		public String DI_Workflow_ProcessIDPattern() {

			return "";

		}

		public String DI_Workflow_ProcessIDOriginalDbColumnName() {

			return "DI_Workflow_ProcessID";

		}

		public String Date_SK;

		public String getDate_SK() {
			return this.Date_SK;
		}

		public Boolean Date_SKIsNullable() {
			return true;
		}

		public Boolean Date_SKIsKey() {
			return false;
		}

		public Integer Date_SKLength() {
			return null;
		}

		public Integer Date_SKPrecision() {
			return null;
		}

		public String Date_SKDefault() {

			return null;

		}

		public String Date_SKComment() {

			return "";

		}

		public String Date_SKPattern() {

			return "";

		}

		public String Date_SKOriginalDbColumnName() {

			return "Date_SK";

		}

		public Integer InspectionType_ID;

		public Integer getInspectionType_ID() {
			return this.InspectionType_ID;
		}

		public Boolean InspectionType_IDIsNullable() {
			return true;
		}

		public Boolean InspectionType_IDIsKey() {
			return false;
		}

		public Integer InspectionType_IDLength() {
			return null;
		}

		public Integer InspectionType_IDPrecision() {
			return null;
		}

		public String InspectionType_IDDefault() {

			return null;

		}

		public String InspectionType_IDComment() {

			return "";

		}

		public String InspectionType_IDPattern() {

			return "";

		}

		public String InspectionType_IDOriginalDbColumnName() {

			return "InspectionType_ID";

		}

		public Integer Business_ID_SK;

		public Integer getBusiness_ID_SK() {
			return this.Business_ID_SK;
		}

		public Boolean Business_ID_SKIsNullable() {
			return true;
		}

		public Boolean Business_ID_SKIsKey() {
			return false;
		}

		public Integer Business_ID_SKLength() {
			return null;
		}

		public Integer Business_ID_SKPrecision() {
			return null;
		}

		public String Business_ID_SKDefault() {

			return null;

		}

		public String Business_ID_SKComment() {

			return "";

		}

		public String Business_ID_SKPattern() {

			return "";

		}

		public String Business_ID_SKOriginalDbColumnName() {

			return "Business_ID_SK";

		}

		public Integer Location_SK;

		public Integer getLocation_SK() {
			return this.Location_SK;
		}

		public Boolean Location_SKIsNullable() {
			return true;
		}

		public Boolean Location_SKIsKey() {
			return false;
		}

		public Integer Location_SKLength() {
			return null;
		}

		public Integer Location_SKPrecision() {
			return null;
		}

		public String Location_SKDefault() {

			return null;

		}

		public String Location_SKComment() {

			return "";

		}

		public String Location_SKPattern() {

			return "";

		}

		public String Location_SKOriginalDbColumnName() {

			return "Location_SK";

		}

		public Integer Inspection_SK;

		public Integer getInspection_SK() {
			return this.Inspection_SK;
		}

		public Boolean Inspection_SKIsNullable() {
			return true;
		}

		public Boolean Inspection_SKIsKey() {
			return false;
		}

		public Integer Inspection_SKLength() {
			return null;
		}

		public Integer Inspection_SKPrecision() {
			return null;
		}

		public String Inspection_SKDefault() {

			return null;

		}

		public String Inspection_SKComment() {

			return "";

		}

		public String Inspection_SKPattern() {

			return "";

		}

		public String Inspection_SKOriginalDbColumnName() {

			return "Inspection_SK";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.BusinessId = readString(dis);

					this.Name = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.State = readString(dis);

					this.ZipCode = readString(dis);

					this.PhoneNumber = readString(dis);

					this.InspectionId = readString(dis);

					this.Date = readDate(dis);

					this.InspectionType = readString(dis);

					this.Location = readString(dis);

					this.Latitude = readString(dis);

					this.Longitude = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

					this.Date_SK = readString(dis);

					this.InspectionType_ID = readInteger(dis);

					this.Business_ID_SK = readInteger(dis);

					this.Location_SK = readInteger(dis);

					this.Inspection_SK = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.BusinessId = readString(dis);

					this.Name = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.State = readString(dis);

					this.ZipCode = readString(dis);

					this.PhoneNumber = readString(dis);

					this.InspectionId = readString(dis);

					this.Date = readDate(dis);

					this.InspectionType = readString(dis);

					this.Location = readString(dis);

					this.Latitude = readString(dis);

					this.Longitude = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

					this.Date_SK = readString(dis);

					this.InspectionType_ID = readInteger(dis);

					this.Business_ID_SK = readInteger(dis);

					this.Location_SK = readInteger(dis);

					this.Inspection_SK = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.BusinessId, dos);

				// String

				writeString(this.Name, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.State, dos);

				// String

				writeString(this.ZipCode, dos);

				// String

				writeString(this.PhoneNumber, dos);

				// String

				writeString(this.InspectionId, dos);

				// java.util.Date

				writeDate(this.Date, dos);

				// String

				writeString(this.InspectionType, dos);

				// String

				writeString(this.Location, dos);

				// String

				writeString(this.Latitude, dos);

				// String

				writeString(this.Longitude, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

				// String

				writeString(this.Date_SK, dos);

				// Integer

				writeInteger(this.InspectionType_ID, dos);

				// Integer

				writeInteger(this.Business_ID_SK, dos);

				// Integer

				writeInteger(this.Location_SK, dos);

				// Integer

				writeInteger(this.Inspection_SK, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.BusinessId, dos);

				// String

				writeString(this.Name, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.State, dos);

				// String

				writeString(this.ZipCode, dos);

				// String

				writeString(this.PhoneNumber, dos);

				// String

				writeString(this.InspectionId, dos);

				// java.util.Date

				writeDate(this.Date, dos);

				// String

				writeString(this.InspectionType, dos);

				// String

				writeString(this.Location, dos);

				// String

				writeString(this.Latitude, dos);

				// String

				writeString(this.Longitude, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

				// String

				writeString(this.Date_SK, dos);

				// Integer

				writeInteger(this.InspectionType_ID, dos);

				// Integer

				writeInteger(this.Business_ID_SK, dos);

				// Integer

				writeInteger(this.Location_SK, dos);

				// Integer

				writeInteger(this.Inspection_SK, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("BusinessId=" + BusinessId);
			sb.append(",Name=" + Name);
			sb.append(",Address=" + Address);
			sb.append(",City=" + City);
			sb.append(",State=" + State);
			sb.append(",ZipCode=" + ZipCode);
			sb.append(",PhoneNumber=" + PhoneNumber);
			sb.append(",InspectionId=" + InspectionId);
			sb.append(",Date=" + String.valueOf(Date));
			sb.append(",InspectionType=" + InspectionType);
			sb.append(",Location=" + Location);
			sb.append(",Latitude=" + Latitude);
			sb.append(",Longitude=" + Longitude);
			sb.append(",DI_CreatedDate=" + String.valueOf(DI_CreatedDate));
			sb.append(",DI_WorkflowFileName=" + DI_WorkflowFileName);
			sb.append(",DI_Workflow_ProcessID=" + DI_Workflow_ProcessID);
			sb.append(",Date_SK=" + Date_SK);
			sb.append(",InspectionType_ID=" + String.valueOf(InspectionType_ID));
			sb.append(",Business_ID_SK=" + String.valueOf(Business_ID_SK));
			sb.append(",Location_SK=" + String.valueOf(Location_SK));
			sb.append(",Inspection_SK=" + String.valueOf(Inspection_SK));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (BusinessId == null) {
				sb.append("<null>");
			} else {
				sb.append(BusinessId);
			}

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (Address == null) {
				sb.append("<null>");
			} else {
				sb.append(Address);
			}

			sb.append("|");

			if (City == null) {
				sb.append("<null>");
			} else {
				sb.append(City);
			}

			sb.append("|");

			if (State == null) {
				sb.append("<null>");
			} else {
				sb.append(State);
			}

			sb.append("|");

			if (ZipCode == null) {
				sb.append("<null>");
			} else {
				sb.append(ZipCode);
			}

			sb.append("|");

			if (PhoneNumber == null) {
				sb.append("<null>");
			} else {
				sb.append(PhoneNumber);
			}

			sb.append("|");

			if (InspectionId == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionId);
			}

			sb.append("|");

			if (Date == null) {
				sb.append("<null>");
			} else {
				sb.append(Date);
			}

			sb.append("|");

			if (InspectionType == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionType);
			}

			sb.append("|");

			if (Location == null) {
				sb.append("<null>");
			} else {
				sb.append(Location);
			}

			sb.append("|");

			if (Latitude == null) {
				sb.append("<null>");
			} else {
				sb.append(Latitude);
			}

			sb.append("|");

			if (Longitude == null) {
				sb.append("<null>");
			} else {
				sb.append(Longitude);
			}

			sb.append("|");

			if (DI_CreatedDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreatedDate);
			}

			sb.append("|");

			if (DI_WorkflowFileName == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_WorkflowFileName);
			}

			sb.append("|");

			if (DI_Workflow_ProcessID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Workflow_ProcessID);
			}

			sb.append("|");

			if (Date_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Date_SK);
			}

			sb.append("|");

			if (InspectionType_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionType_ID);
			}

			sb.append("|");

			if (Business_ID_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Business_ID_SK);
			}

			sb.append("|");

			if (Location_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Location_SK);
			}

			sb.append("|");

			if (Inspection_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Inspection_SK);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(Facts_DimensionsStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public String BusinessId;

		public String getBusinessId() {
			return this.BusinessId;
		}

		public Boolean BusinessIdIsNullable() {
			return true;
		}

		public Boolean BusinessIdIsKey() {
			return false;
		}

		public Integer BusinessIdLength() {
			return 9;
		}

		public Integer BusinessIdPrecision() {
			return 0;
		}

		public String BusinessIdDefault() {

			return null;

		}

		public String BusinessIdComment() {

			return "";

		}

		public String BusinessIdPattern() {

			return "";

		}

		public String BusinessIdOriginalDbColumnName() {

			return "BusinessId";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 70;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public String Address;

		public String getAddress() {
			return this.Address;
		}

		public Boolean AddressIsNullable() {
			return true;
		}

		public Boolean AddressIsKey() {
			return false;
		}

		public Integer AddressLength() {
			return 40;
		}

		public Integer AddressPrecision() {
			return 0;
		}

		public String AddressDefault() {

			return null;

		}

		public String AddressComment() {

			return "";

		}

		public String AddressPattern() {

			return "";

		}

		public String AddressOriginalDbColumnName() {

			return "Address";

		}

		public String City;

		public String getCity() {
			return this.City;
		}

		public Boolean CityIsNullable() {
			return true;
		}

		public Boolean CityIsKey() {
			return false;
		}

		public Integer CityLength() {
			return 20;
		}

		public Integer CityPrecision() {
			return 0;
		}

		public String CityDefault() {

			return null;

		}

		public String CityComment() {

			return "";

		}

		public String CityPattern() {

			return "";

		}

		public String CityOriginalDbColumnName() {

			return "City";

		}

		public String State;

		public String getState() {
			return this.State;
		}

		public Boolean StateIsNullable() {
			return true;
		}

		public Boolean StateIsKey() {
			return false;
		}

		public Integer StateLength() {
			return 2;
		}

		public Integer StatePrecision() {
			return 0;
		}

		public String StateDefault() {

			return null;

		}

		public String StateComment() {

			return "";

		}

		public String StatePattern() {

			return "";

		}

		public String StateOriginalDbColumnName() {

			return "State";

		}

		public String ZipCode;

		public String getZipCode() {
			return this.ZipCode;
		}

		public Boolean ZipCodeIsNullable() {
			return true;
		}

		public Boolean ZipCodeIsKey() {
			return false;
		}

		public Integer ZipCodeLength() {
			return 10;
		}

		public Integer ZipCodePrecision() {
			return 0;
		}

		public String ZipCodeDefault() {

			return null;

		}

		public String ZipCodeComment() {

			return "";

		}

		public String ZipCodePattern() {

			return "";

		}

		public String ZipCodeOriginalDbColumnName() {

			return "ZipCode";

		}

		public String PhoneNumber;

		public String getPhoneNumber() {
			return this.PhoneNumber;
		}

		public Boolean PhoneNumberIsNullable() {
			return true;
		}

		public Boolean PhoneNumberIsKey() {
			return false;
		}

		public Integer PhoneNumberLength() {
			return 13;
		}

		public Integer PhoneNumberPrecision() {
			return 0;
		}

		public String PhoneNumberDefault() {

			return null;

		}

		public String PhoneNumberComment() {

			return "";

		}

		public String PhoneNumberPattern() {

			return "";

		}

		public String PhoneNumberOriginalDbColumnName() {

			return "PhoneNumber";

		}

		public String InspectionId;

		public String getInspectionId() {
			return this.InspectionId;
		}

		public Boolean InspectionIdIsNullable() {
			return true;
		}

		public Boolean InspectionIdIsKey() {
			return false;
		}

		public Integer InspectionIdLength() {
			return 9;
		}

		public Integer InspectionIdPrecision() {
			return 0;
		}

		public String InspectionIdDefault() {

			return null;

		}

		public String InspectionIdComment() {

			return "";

		}

		public String InspectionIdPattern() {

			return "";

		}

		public String InspectionIdOriginalDbColumnName() {

			return "InspectionId";

		}

		public java.util.Date Date;

		public java.util.Date getDate() {
			return this.Date;
		}

		public Boolean DateIsNullable() {
			return true;
		}

		public Boolean DateIsKey() {
			return false;
		}

		public Integer DateLength() {
			return 19;
		}

		public Integer DatePrecision() {
			return 0;
		}

		public String DateDefault() {

			return null;

		}

		public String DateComment() {

			return "";

		}

		public String DatePattern() {

			return "dd-MM-yyyy";

		}

		public String DateOriginalDbColumnName() {

			return "Date";

		}

		public String InspectionType;

		public String getInspectionType() {
			return this.InspectionType;
		}

		public Boolean InspectionTypeIsNullable() {
			return true;
		}

		public Boolean InspectionTypeIsKey() {
			return false;
		}

		public Integer InspectionTypeLength() {
			return 9;
		}

		public Integer InspectionTypePrecision() {
			return 0;
		}

		public String InspectionTypeDefault() {

			return null;

		}

		public String InspectionTypeComment() {

			return "";

		}

		public String InspectionTypePattern() {

			return "";

		}

		public String InspectionTypeOriginalDbColumnName() {

			return "InspectionType";

		}

		public String ViolationCodes;

		public String getViolationCodes() {
			return this.ViolationCodes;
		}

		public Boolean ViolationCodesIsNullable() {
			return true;
		}

		public Boolean ViolationCodesIsKey() {
			return false;
		}

		public Integer ViolationCodesLength() {
			return 150;
		}

		public Integer ViolationCodesPrecision() {
			return 0;
		}

		public String ViolationCodesDefault() {

			return null;

		}

		public String ViolationCodesComment() {

			return "";

		}

		public String ViolationCodesPattern() {

			return "";

		}

		public String ViolationCodesOriginalDbColumnName() {

			return "ViolationCodes";

		}

		public String ViolationDesc;

		public String getViolationDesc() {
			return this.ViolationDesc;
		}

		public Boolean ViolationDescIsNullable() {
			return true;
		}

		public Boolean ViolationDescIsKey() {
			return false;
		}

		public Integer ViolationDescLength() {
			return 1200;
		}

		public Integer ViolationDescPrecision() {
			return 0;
		}

		public String ViolationDescDefault() {

			return null;

		}

		public String ViolationDescComment() {

			return "";

		}

		public String ViolationDescPattern() {

			return "";

		}

		public String ViolationDescOriginalDbColumnName() {

			return "ViolationDesc";

		}

		public String Location;

		public String getLocation() {
			return this.Location;
		}

		public Boolean LocationIsNullable() {
			return true;
		}

		public Boolean LocationIsKey() {
			return false;
		}

		public Integer LocationLength() {
			return 100;
		}

		public Integer LocationPrecision() {
			return 0;
		}

		public String LocationDefault() {

			return null;

		}

		public String LocationComment() {

			return "";

		}

		public String LocationPattern() {

			return "";

		}

		public String LocationOriginalDbColumnName() {

			return "Location";

		}

		public String Latitude;

		public String getLatitude() {
			return this.Latitude;
		}

		public Boolean LatitudeIsNullable() {
			return true;
		}

		public Boolean LatitudeIsKey() {
			return false;
		}

		public Integer LatitudeLength() {
			return 10;
		}

		public Integer LatitudePrecision() {
			return null;
		}

		public String LatitudeDefault() {

			return null;

		}

		public String LatitudeComment() {

			return "";

		}

		public String LatitudePattern() {

			return "";

		}

		public String LatitudeOriginalDbColumnName() {

			return "Latitude";

		}

		public String Longitude;

		public String getLongitude() {
			return this.Longitude;
		}

		public Boolean LongitudeIsNullable() {
			return true;
		}

		public Boolean LongitudeIsKey() {
			return false;
		}

		public Integer LongitudeLength() {
			return 10;
		}

		public Integer LongitudePrecision() {
			return null;
		}

		public String LongitudeDefault() {

			return null;

		}

		public String LongitudeComment() {

			return "";

		}

		public String LongitudePattern() {

			return "";

		}

		public String LongitudeOriginalDbColumnName() {

			return "Longitude";

		}

		public java.util.Date DI_CreatedDate;

		public java.util.Date getDI_CreatedDate() {
			return this.DI_CreatedDate;
		}

		public Boolean DI_CreatedDateIsNullable() {
			return true;
		}

		public Boolean DI_CreatedDateIsKey() {
			return false;
		}

		public Integer DI_CreatedDateLength() {
			return 19;
		}

		public Integer DI_CreatedDatePrecision() {
			return 0;
		}

		public String DI_CreatedDateDefault() {

			return null;

		}

		public String DI_CreatedDateComment() {

			return "";

		}

		public String DI_CreatedDatePattern() {

			return "dd-MM-yyyy";

		}

		public String DI_CreatedDateOriginalDbColumnName() {

			return "DI_CreatedDate";

		}

		public String DI_WorkflowFileName;

		public String getDI_WorkflowFileName() {
			return this.DI_WorkflowFileName;
		}

		public Boolean DI_WorkflowFileNameIsNullable() {
			return true;
		}

		public Boolean DI_WorkflowFileNameIsKey() {
			return false;
		}

		public Integer DI_WorkflowFileNameLength() {
			return 255;
		}

		public Integer DI_WorkflowFileNamePrecision() {
			return 0;
		}

		public String DI_WorkflowFileNameDefault() {

			return null;

		}

		public String DI_WorkflowFileNameComment() {

			return "";

		}

		public String DI_WorkflowFileNamePattern() {

			return "";

		}

		public String DI_WorkflowFileNameOriginalDbColumnName() {

			return "DI_WorkflowFileName";

		}

		public String DI_Workflow_ProcessID;

		public String getDI_Workflow_ProcessID() {
			return this.DI_Workflow_ProcessID;
		}

		public Boolean DI_Workflow_ProcessIDIsNullable() {
			return true;
		}

		public Boolean DI_Workflow_ProcessIDIsKey() {
			return false;
		}

		public Integer DI_Workflow_ProcessIDLength() {
			return 30;
		}

		public Integer DI_Workflow_ProcessIDPrecision() {
			return 0;
		}

		public String DI_Workflow_ProcessIDDefault() {

			return null;

		}

		public String DI_Workflow_ProcessIDComment() {

			return "";

		}

		public String DI_Workflow_ProcessIDPattern() {

			return "";

		}

		public String DI_Workflow_ProcessIDOriginalDbColumnName() {

			return "DI_Workflow_ProcessID";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.BusinessId = readString(dis);

					this.Name = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.State = readString(dis);

					this.ZipCode = readString(dis);

					this.PhoneNumber = readString(dis);

					this.InspectionId = readString(dis);

					this.Date = readDate(dis);

					this.InspectionType = readString(dis);

					this.ViolationCodes = readString(dis);

					this.ViolationDesc = readString(dis);

					this.Location = readString(dis);

					this.Latitude = readString(dis);

					this.Longitude = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.BusinessId = readString(dis);

					this.Name = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.State = readString(dis);

					this.ZipCode = readString(dis);

					this.PhoneNumber = readString(dis);

					this.InspectionId = readString(dis);

					this.Date = readDate(dis);

					this.InspectionType = readString(dis);

					this.ViolationCodes = readString(dis);

					this.ViolationDesc = readString(dis);

					this.Location = readString(dis);

					this.Latitude = readString(dis);

					this.Longitude = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.BusinessId, dos);

				// String

				writeString(this.Name, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.State, dos);

				// String

				writeString(this.ZipCode, dos);

				// String

				writeString(this.PhoneNumber, dos);

				// String

				writeString(this.InspectionId, dos);

				// java.util.Date

				writeDate(this.Date, dos);

				// String

				writeString(this.InspectionType, dos);

				// String

				writeString(this.ViolationCodes, dos);

				// String

				writeString(this.ViolationDesc, dos);

				// String

				writeString(this.Location, dos);

				// String

				writeString(this.Latitude, dos);

				// String

				writeString(this.Longitude, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.BusinessId, dos);

				// String

				writeString(this.Name, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.State, dos);

				// String

				writeString(this.ZipCode, dos);

				// String

				writeString(this.PhoneNumber, dos);

				// String

				writeString(this.InspectionId, dos);

				// java.util.Date

				writeDate(this.Date, dos);

				// String

				writeString(this.InspectionType, dos);

				// String

				writeString(this.ViolationCodes, dos);

				// String

				writeString(this.ViolationDesc, dos);

				// String

				writeString(this.Location, dos);

				// String

				writeString(this.Latitude, dos);

				// String

				writeString(this.Longitude, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("BusinessId=" + BusinessId);
			sb.append(",Name=" + Name);
			sb.append(",Address=" + Address);
			sb.append(",City=" + City);
			sb.append(",State=" + State);
			sb.append(",ZipCode=" + ZipCode);
			sb.append(",PhoneNumber=" + PhoneNumber);
			sb.append(",InspectionId=" + InspectionId);
			sb.append(",Date=" + String.valueOf(Date));
			sb.append(",InspectionType=" + InspectionType);
			sb.append(",ViolationCodes=" + ViolationCodes);
			sb.append(",ViolationDesc=" + ViolationDesc);
			sb.append(",Location=" + Location);
			sb.append(",Latitude=" + Latitude);
			sb.append(",Longitude=" + Longitude);
			sb.append(",DI_CreatedDate=" + String.valueOf(DI_CreatedDate));
			sb.append(",DI_WorkflowFileName=" + DI_WorkflowFileName);
			sb.append(",DI_Workflow_ProcessID=" + DI_Workflow_ProcessID);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (BusinessId == null) {
				sb.append("<null>");
			} else {
				sb.append(BusinessId);
			}

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (Address == null) {
				sb.append("<null>");
			} else {
				sb.append(Address);
			}

			sb.append("|");

			if (City == null) {
				sb.append("<null>");
			} else {
				sb.append(City);
			}

			sb.append("|");

			if (State == null) {
				sb.append("<null>");
			} else {
				sb.append(State);
			}

			sb.append("|");

			if (ZipCode == null) {
				sb.append("<null>");
			} else {
				sb.append(ZipCode);
			}

			sb.append("|");

			if (PhoneNumber == null) {
				sb.append("<null>");
			} else {
				sb.append(PhoneNumber);
			}

			sb.append("|");

			if (InspectionId == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionId);
			}

			sb.append("|");

			if (Date == null) {
				sb.append("<null>");
			} else {
				sb.append(Date);
			}

			sb.append("|");

			if (InspectionType == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionType);
			}

			sb.append("|");

			if (ViolationCodes == null) {
				sb.append("<null>");
			} else {
				sb.append(ViolationCodes);
			}

			sb.append("|");

			if (ViolationDesc == null) {
				sb.append("<null>");
			} else {
				sb.append(ViolationDesc);
			}

			sb.append("|");

			if (Location == null) {
				sb.append("<null>");
			} else {
				sb.append(Location);
			}

			sb.append("|");

			if (Latitude == null) {
				sb.append("<null>");
			} else {
				sb.append(Latitude);
			}

			sb.append("|");

			if (Longitude == null) {
				sb.append("<null>");
			} else {
				sb.append(Longitude);
			}

			sb.append("|");

			if (DI_CreatedDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreatedDate);
			}

			sb.append("|");

			if (DI_WorkflowFileName == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_WorkflowFileName);
			}

			sb.append("|");

			if (DI_Workflow_ProcessID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Workflow_ProcessID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public String BusinessId;

		public String getBusinessId() {
			return this.BusinessId;
		}

		public Boolean BusinessIdIsNullable() {
			return true;
		}

		public Boolean BusinessIdIsKey() {
			return false;
		}

		public Integer BusinessIdLength() {
			return 9;
		}

		public Integer BusinessIdPrecision() {
			return 0;
		}

		public String BusinessIdDefault() {

			return null;

		}

		public String BusinessIdComment() {

			return "";

		}

		public String BusinessIdPattern() {

			return "";

		}

		public String BusinessIdOriginalDbColumnName() {

			return "BusinessId";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 70;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public String Address;

		public String getAddress() {
			return this.Address;
		}

		public Boolean AddressIsNullable() {
			return true;
		}

		public Boolean AddressIsKey() {
			return false;
		}

		public Integer AddressLength() {
			return 40;
		}

		public Integer AddressPrecision() {
			return 0;
		}

		public String AddressDefault() {

			return null;

		}

		public String AddressComment() {

			return "";

		}

		public String AddressPattern() {

			return "";

		}

		public String AddressOriginalDbColumnName() {

			return "Address";

		}

		public String City;

		public String getCity() {
			return this.City;
		}

		public Boolean CityIsNullable() {
			return true;
		}

		public Boolean CityIsKey() {
			return false;
		}

		public Integer CityLength() {
			return 20;
		}

		public Integer CityPrecision() {
			return 0;
		}

		public String CityDefault() {

			return null;

		}

		public String CityComment() {

			return "";

		}

		public String CityPattern() {

			return "";

		}

		public String CityOriginalDbColumnName() {

			return "City";

		}

		public String State;

		public String getState() {
			return this.State;
		}

		public Boolean StateIsNullable() {
			return true;
		}

		public Boolean StateIsKey() {
			return false;
		}

		public Integer StateLength() {
			return 2;
		}

		public Integer StatePrecision() {
			return 0;
		}

		public String StateDefault() {

			return null;

		}

		public String StateComment() {

			return "";

		}

		public String StatePattern() {

			return "";

		}

		public String StateOriginalDbColumnName() {

			return "State";

		}

		public String ZipCode;

		public String getZipCode() {
			return this.ZipCode;
		}

		public Boolean ZipCodeIsNullable() {
			return true;
		}

		public Boolean ZipCodeIsKey() {
			return false;
		}

		public Integer ZipCodeLength() {
			return 10;
		}

		public Integer ZipCodePrecision() {
			return 0;
		}

		public String ZipCodeDefault() {

			return null;

		}

		public String ZipCodeComment() {

			return "";

		}

		public String ZipCodePattern() {

			return "";

		}

		public String ZipCodeOriginalDbColumnName() {

			return "ZipCode";

		}

		public String PhoneNumber;

		public String getPhoneNumber() {
			return this.PhoneNumber;
		}

		public Boolean PhoneNumberIsNullable() {
			return true;
		}

		public Boolean PhoneNumberIsKey() {
			return false;
		}

		public Integer PhoneNumberLength() {
			return 13;
		}

		public Integer PhoneNumberPrecision() {
			return 0;
		}

		public String PhoneNumberDefault() {

			return null;

		}

		public String PhoneNumberComment() {

			return "";

		}

		public String PhoneNumberPattern() {

			return "";

		}

		public String PhoneNumberOriginalDbColumnName() {

			return "PhoneNumber";

		}

		public String InspectionId;

		public String getInspectionId() {
			return this.InspectionId;
		}

		public Boolean InspectionIdIsNullable() {
			return true;
		}

		public Boolean InspectionIdIsKey() {
			return false;
		}

		public Integer InspectionIdLength() {
			return 9;
		}

		public Integer InspectionIdPrecision() {
			return 0;
		}

		public String InspectionIdDefault() {

			return null;

		}

		public String InspectionIdComment() {

			return "";

		}

		public String InspectionIdPattern() {

			return "";

		}

		public String InspectionIdOriginalDbColumnName() {

			return "InspectionId";

		}

		public java.util.Date Date;

		public java.util.Date getDate() {
			return this.Date;
		}

		public Boolean DateIsNullable() {
			return true;
		}

		public Boolean DateIsKey() {
			return false;
		}

		public Integer DateLength() {
			return 19;
		}

		public Integer DatePrecision() {
			return 0;
		}

		public String DateDefault() {

			return null;

		}

		public String DateComment() {

			return "";

		}

		public String DatePattern() {

			return "dd-MM-yyyy";

		}

		public String DateOriginalDbColumnName() {

			return "Date";

		}

		public String InspectionType;

		public String getInspectionType() {
			return this.InspectionType;
		}

		public Boolean InspectionTypeIsNullable() {
			return true;
		}

		public Boolean InspectionTypeIsKey() {
			return false;
		}

		public Integer InspectionTypeLength() {
			return 9;
		}

		public Integer InspectionTypePrecision() {
			return 0;
		}

		public String InspectionTypeDefault() {

			return null;

		}

		public String InspectionTypeComment() {

			return "";

		}

		public String InspectionTypePattern() {

			return "";

		}

		public String InspectionTypeOriginalDbColumnName() {

			return "InspectionType";

		}

		public String ViolationCodes;

		public String getViolationCodes() {
			return this.ViolationCodes;
		}

		public Boolean ViolationCodesIsNullable() {
			return true;
		}

		public Boolean ViolationCodesIsKey() {
			return false;
		}

		public Integer ViolationCodesLength() {
			return 150;
		}

		public Integer ViolationCodesPrecision() {
			return 0;
		}

		public String ViolationCodesDefault() {

			return null;

		}

		public String ViolationCodesComment() {

			return "";

		}

		public String ViolationCodesPattern() {

			return "";

		}

		public String ViolationCodesOriginalDbColumnName() {

			return "ViolationCodes";

		}

		public String ViolationDesc;

		public String getViolationDesc() {
			return this.ViolationDesc;
		}

		public Boolean ViolationDescIsNullable() {
			return true;
		}

		public Boolean ViolationDescIsKey() {
			return false;
		}

		public Integer ViolationDescLength() {
			return 1200;
		}

		public Integer ViolationDescPrecision() {
			return 0;
		}

		public String ViolationDescDefault() {

			return null;

		}

		public String ViolationDescComment() {

			return "";

		}

		public String ViolationDescPattern() {

			return "";

		}

		public String ViolationDescOriginalDbColumnName() {

			return "ViolationDesc";

		}

		public String Location;

		public String getLocation() {
			return this.Location;
		}

		public Boolean LocationIsNullable() {
			return true;
		}

		public Boolean LocationIsKey() {
			return false;
		}

		public Integer LocationLength() {
			return 100;
		}

		public Integer LocationPrecision() {
			return 0;
		}

		public String LocationDefault() {

			return null;

		}

		public String LocationComment() {

			return "";

		}

		public String LocationPattern() {

			return "";

		}

		public String LocationOriginalDbColumnName() {

			return "Location";

		}

		public java.util.Date DI_CreatedDate;

		public java.util.Date getDI_CreatedDate() {
			return this.DI_CreatedDate;
		}

		public Boolean DI_CreatedDateIsNullable() {
			return true;
		}

		public Boolean DI_CreatedDateIsKey() {
			return false;
		}

		public Integer DI_CreatedDateLength() {
			return 19;
		}

		public Integer DI_CreatedDatePrecision() {
			return 0;
		}

		public String DI_CreatedDateDefault() {

			return null;

		}

		public String DI_CreatedDateComment() {

			return "";

		}

		public String DI_CreatedDatePattern() {

			return "dd-MM-yyyy";

		}

		public String DI_CreatedDateOriginalDbColumnName() {

			return "DI_CreatedDate";

		}

		public String DI_WorkflowFileName;

		public String getDI_WorkflowFileName() {
			return this.DI_WorkflowFileName;
		}

		public Boolean DI_WorkflowFileNameIsNullable() {
			return true;
		}

		public Boolean DI_WorkflowFileNameIsKey() {
			return false;
		}

		public Integer DI_WorkflowFileNameLength() {
			return 255;
		}

		public Integer DI_WorkflowFileNamePrecision() {
			return 0;
		}

		public String DI_WorkflowFileNameDefault() {

			return null;

		}

		public String DI_WorkflowFileNameComment() {

			return "";

		}

		public String DI_WorkflowFileNamePattern() {

			return "";

		}

		public String DI_WorkflowFileNameOriginalDbColumnName() {

			return "DI_WorkflowFileName";

		}

		public String DI_Workflow_ProcessID;

		public String getDI_Workflow_ProcessID() {
			return this.DI_Workflow_ProcessID;
		}

		public Boolean DI_Workflow_ProcessIDIsNullable() {
			return true;
		}

		public Boolean DI_Workflow_ProcessIDIsKey() {
			return false;
		}

		public Integer DI_Workflow_ProcessIDLength() {
			return 30;
		}

		public Integer DI_Workflow_ProcessIDPrecision() {
			return 0;
		}

		public String DI_Workflow_ProcessIDDefault() {

			return null;

		}

		public String DI_Workflow_ProcessIDComment() {

			return "";

		}

		public String DI_Workflow_ProcessIDPattern() {

			return "";

		}

		public String DI_Workflow_ProcessIDOriginalDbColumnName() {

			return "DI_Workflow_ProcessID";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.BusinessId = readString(dis);

					this.Name = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.State = readString(dis);

					this.ZipCode = readString(dis);

					this.PhoneNumber = readString(dis);

					this.InspectionId = readString(dis);

					this.Date = readDate(dis);

					this.InspectionType = readString(dis);

					this.ViolationCodes = readString(dis);

					this.ViolationDesc = readString(dis);

					this.Location = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.BusinessId = readString(dis);

					this.Name = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.State = readString(dis);

					this.ZipCode = readString(dis);

					this.PhoneNumber = readString(dis);

					this.InspectionId = readString(dis);

					this.Date = readDate(dis);

					this.InspectionType = readString(dis);

					this.ViolationCodes = readString(dis);

					this.ViolationDesc = readString(dis);

					this.Location = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.BusinessId, dos);

				// String

				writeString(this.Name, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.State, dos);

				// String

				writeString(this.ZipCode, dos);

				// String

				writeString(this.PhoneNumber, dos);

				// String

				writeString(this.InspectionId, dos);

				// java.util.Date

				writeDate(this.Date, dos);

				// String

				writeString(this.InspectionType, dos);

				// String

				writeString(this.ViolationCodes, dos);

				// String

				writeString(this.ViolationDesc, dos);

				// String

				writeString(this.Location, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.BusinessId, dos);

				// String

				writeString(this.Name, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.State, dos);

				// String

				writeString(this.ZipCode, dos);

				// String

				writeString(this.PhoneNumber, dos);

				// String

				writeString(this.InspectionId, dos);

				// java.util.Date

				writeDate(this.Date, dos);

				// String

				writeString(this.InspectionType, dos);

				// String

				writeString(this.ViolationCodes, dos);

				// String

				writeString(this.ViolationDesc, dos);

				// String

				writeString(this.Location, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("BusinessId=" + BusinessId);
			sb.append(",Name=" + Name);
			sb.append(",Address=" + Address);
			sb.append(",City=" + City);
			sb.append(",State=" + State);
			sb.append(",ZipCode=" + ZipCode);
			sb.append(",PhoneNumber=" + PhoneNumber);
			sb.append(",InspectionId=" + InspectionId);
			sb.append(",Date=" + String.valueOf(Date));
			sb.append(",InspectionType=" + InspectionType);
			sb.append(",ViolationCodes=" + ViolationCodes);
			sb.append(",ViolationDesc=" + ViolationDesc);
			sb.append(",Location=" + Location);
			sb.append(",DI_CreatedDate=" + String.valueOf(DI_CreatedDate));
			sb.append(",DI_WorkflowFileName=" + DI_WorkflowFileName);
			sb.append(",DI_Workflow_ProcessID=" + DI_Workflow_ProcessID);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (BusinessId == null) {
				sb.append("<null>");
			} else {
				sb.append(BusinessId);
			}

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (Address == null) {
				sb.append("<null>");
			} else {
				sb.append(Address);
			}

			sb.append("|");

			if (City == null) {
				sb.append("<null>");
			} else {
				sb.append(City);
			}

			sb.append("|");

			if (State == null) {
				sb.append("<null>");
			} else {
				sb.append(State);
			}

			sb.append("|");

			if (ZipCode == null) {
				sb.append("<null>");
			} else {
				sb.append(ZipCode);
			}

			sb.append("|");

			if (PhoneNumber == null) {
				sb.append("<null>");
			} else {
				sb.append(PhoneNumber);
			}

			sb.append("|");

			if (InspectionId == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionId);
			}

			sb.append("|");

			if (Date == null) {
				sb.append("<null>");
			} else {
				sb.append(Date);
			}

			sb.append("|");

			if (InspectionType == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionType);
			}

			sb.append("|");

			if (ViolationCodes == null) {
				sb.append("<null>");
			} else {
				sb.append(ViolationCodes);
			}

			sb.append("|");

			if (ViolationDesc == null) {
				sb.append("<null>");
			} else {
				sb.append(ViolationDesc);
			}

			sb.append("|");

			if (Location == null) {
				sb.append("<null>");
			} else {
				sb.append(Location);
			}

			sb.append("|");

			if (DI_CreatedDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreatedDate);
			}

			sb.append("|");

			if (DI_WorkflowFileName == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_WorkflowFileName);
			}

			sb.append("|");

			if (DI_Workflow_ProcessID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Workflow_ProcessID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public String BusinessId;

		public String getBusinessId() {
			return this.BusinessId;
		}

		public Boolean BusinessIdIsNullable() {
			return true;
		}

		public Boolean BusinessIdIsKey() {
			return false;
		}

		public Integer BusinessIdLength() {
			return 9;
		}

		public Integer BusinessIdPrecision() {
			return 0;
		}

		public String BusinessIdDefault() {

			return null;

		}

		public String BusinessIdComment() {

			return "";

		}

		public String BusinessIdPattern() {

			return "";

		}

		public String BusinessIdOriginalDbColumnName() {

			return "BusinessId";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 70;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public String Address;

		public String getAddress() {
			return this.Address;
		}

		public Boolean AddressIsNullable() {
			return true;
		}

		public Boolean AddressIsKey() {
			return false;
		}

		public Integer AddressLength() {
			return 40;
		}

		public Integer AddressPrecision() {
			return 0;
		}

		public String AddressDefault() {

			return null;

		}

		public String AddressComment() {

			return "";

		}

		public String AddressPattern() {

			return "";

		}

		public String AddressOriginalDbColumnName() {

			return "Address";

		}

		public String City;

		public String getCity() {
			return this.City;
		}

		public Boolean CityIsNullable() {
			return true;
		}

		public Boolean CityIsKey() {
			return false;
		}

		public Integer CityLength() {
			return 20;
		}

		public Integer CityPrecision() {
			return 0;
		}

		public String CityDefault() {

			return null;

		}

		public String CityComment() {

			return "";

		}

		public String CityPattern() {

			return "";

		}

		public String CityOriginalDbColumnName() {

			return "City";

		}

		public String State;

		public String getState() {
			return this.State;
		}

		public Boolean StateIsNullable() {
			return true;
		}

		public Boolean StateIsKey() {
			return false;
		}

		public Integer StateLength() {
			return 2;
		}

		public Integer StatePrecision() {
			return 0;
		}

		public String StateDefault() {

			return null;

		}

		public String StateComment() {

			return "";

		}

		public String StatePattern() {

			return "";

		}

		public String StateOriginalDbColumnName() {

			return "State";

		}

		public String ZipCode;

		public String getZipCode() {
			return this.ZipCode;
		}

		public Boolean ZipCodeIsNullable() {
			return true;
		}

		public Boolean ZipCodeIsKey() {
			return false;
		}

		public Integer ZipCodeLength() {
			return 10;
		}

		public Integer ZipCodePrecision() {
			return 0;
		}

		public String ZipCodeDefault() {

			return null;

		}

		public String ZipCodeComment() {

			return "";

		}

		public String ZipCodePattern() {

			return "";

		}

		public String ZipCodeOriginalDbColumnName() {

			return "ZipCode";

		}

		public String PhoneNumber;

		public String getPhoneNumber() {
			return this.PhoneNumber;
		}

		public Boolean PhoneNumberIsNullable() {
			return true;
		}

		public Boolean PhoneNumberIsKey() {
			return false;
		}

		public Integer PhoneNumberLength() {
			return 13;
		}

		public Integer PhoneNumberPrecision() {
			return 0;
		}

		public String PhoneNumberDefault() {

			return null;

		}

		public String PhoneNumberComment() {

			return "";

		}

		public String PhoneNumberPattern() {

			return "";

		}

		public String PhoneNumberOriginalDbColumnName() {

			return "PhoneNumber";

		}

		public String InspectionId;

		public String getInspectionId() {
			return this.InspectionId;
		}

		public Boolean InspectionIdIsNullable() {
			return true;
		}

		public Boolean InspectionIdIsKey() {
			return false;
		}

		public Integer InspectionIdLength() {
			return 9;
		}

		public Integer InspectionIdPrecision() {
			return 0;
		}

		public String InspectionIdDefault() {

			return null;

		}

		public String InspectionIdComment() {

			return "";

		}

		public String InspectionIdPattern() {

			return "";

		}

		public String InspectionIdOriginalDbColumnName() {

			return "InspectionId";

		}

		public java.util.Date Date;

		public java.util.Date getDate() {
			return this.Date;
		}

		public Boolean DateIsNullable() {
			return true;
		}

		public Boolean DateIsKey() {
			return false;
		}

		public Integer DateLength() {
			return 19;
		}

		public Integer DatePrecision() {
			return 0;
		}

		public String DateDefault() {

			return null;

		}

		public String DateComment() {

			return "";

		}

		public String DatePattern() {

			return "dd-MM-yyyy";

		}

		public String DateOriginalDbColumnName() {

			return "Date";

		}

		public String InspectionType;

		public String getInspectionType() {
			return this.InspectionType;
		}

		public Boolean InspectionTypeIsNullable() {
			return true;
		}

		public Boolean InspectionTypeIsKey() {
			return false;
		}

		public Integer InspectionTypeLength() {
			return 9;
		}

		public Integer InspectionTypePrecision() {
			return 0;
		}

		public String InspectionTypeDefault() {

			return null;

		}

		public String InspectionTypeComment() {

			return "";

		}

		public String InspectionTypePattern() {

			return "";

		}

		public String InspectionTypeOriginalDbColumnName() {

			return "InspectionType";

		}

		public String ViolationCodes;

		public String getViolationCodes() {
			return this.ViolationCodes;
		}

		public Boolean ViolationCodesIsNullable() {
			return true;
		}

		public Boolean ViolationCodesIsKey() {
			return false;
		}

		public Integer ViolationCodesLength() {
			return 150;
		}

		public Integer ViolationCodesPrecision() {
			return 0;
		}

		public String ViolationCodesDefault() {

			return null;

		}

		public String ViolationCodesComment() {

			return "";

		}

		public String ViolationCodesPattern() {

			return "";

		}

		public String ViolationCodesOriginalDbColumnName() {

			return "ViolationCodes";

		}

		public String ViolationDesc;

		public String getViolationDesc() {
			return this.ViolationDesc;
		}

		public Boolean ViolationDescIsNullable() {
			return true;
		}

		public Boolean ViolationDescIsKey() {
			return false;
		}

		public Integer ViolationDescLength() {
			return 1200;
		}

		public Integer ViolationDescPrecision() {
			return 0;
		}

		public String ViolationDescDefault() {

			return null;

		}

		public String ViolationDescComment() {

			return "";

		}

		public String ViolationDescPattern() {

			return "";

		}

		public String ViolationDescOriginalDbColumnName() {

			return "ViolationDesc";

		}

		public String Location;

		public String getLocation() {
			return this.Location;
		}

		public Boolean LocationIsNullable() {
			return true;
		}

		public Boolean LocationIsKey() {
			return false;
		}

		public Integer LocationLength() {
			return 100;
		}

		public Integer LocationPrecision() {
			return 0;
		}

		public String LocationDefault() {

			return null;

		}

		public String LocationComment() {

			return "";

		}

		public String LocationPattern() {

			return "";

		}

		public String LocationOriginalDbColumnName() {

			return "Location";

		}

		public java.util.Date DI_CreatedDate;

		public java.util.Date getDI_CreatedDate() {
			return this.DI_CreatedDate;
		}

		public Boolean DI_CreatedDateIsNullable() {
			return true;
		}

		public Boolean DI_CreatedDateIsKey() {
			return false;
		}

		public Integer DI_CreatedDateLength() {
			return 19;
		}

		public Integer DI_CreatedDatePrecision() {
			return 0;
		}

		public String DI_CreatedDateDefault() {

			return null;

		}

		public String DI_CreatedDateComment() {

			return "";

		}

		public String DI_CreatedDatePattern() {

			return "dd-MM-yyyy";

		}

		public String DI_CreatedDateOriginalDbColumnName() {

			return "DI_CreatedDate";

		}

		public String DI_WorkflowFileName;

		public String getDI_WorkflowFileName() {
			return this.DI_WorkflowFileName;
		}

		public Boolean DI_WorkflowFileNameIsNullable() {
			return true;
		}

		public Boolean DI_WorkflowFileNameIsKey() {
			return false;
		}

		public Integer DI_WorkflowFileNameLength() {
			return 255;
		}

		public Integer DI_WorkflowFileNamePrecision() {
			return 0;
		}

		public String DI_WorkflowFileNameDefault() {

			return null;

		}

		public String DI_WorkflowFileNameComment() {

			return "";

		}

		public String DI_WorkflowFileNamePattern() {

			return "";

		}

		public String DI_WorkflowFileNameOriginalDbColumnName() {

			return "DI_WorkflowFileName";

		}

		public String DI_Workflow_ProcessID;

		public String getDI_Workflow_ProcessID() {
			return this.DI_Workflow_ProcessID;
		}

		public Boolean DI_Workflow_ProcessIDIsNullable() {
			return true;
		}

		public Boolean DI_Workflow_ProcessIDIsKey() {
			return false;
		}

		public Integer DI_Workflow_ProcessIDLength() {
			return 30;
		}

		public Integer DI_Workflow_ProcessIDPrecision() {
			return 0;
		}

		public String DI_Workflow_ProcessIDDefault() {

			return null;

		}

		public String DI_Workflow_ProcessIDComment() {

			return "";

		}

		public String DI_Workflow_ProcessIDPattern() {

			return "";

		}

		public String DI_Workflow_ProcessIDOriginalDbColumnName() {

			return "DI_Workflow_ProcessID";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.BusinessId = readString(dis);

					this.Name = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.State = readString(dis);

					this.ZipCode = readString(dis);

					this.PhoneNumber = readString(dis);

					this.InspectionId = readString(dis);

					this.Date = readDate(dis);

					this.InspectionType = readString(dis);

					this.ViolationCodes = readString(dis);

					this.ViolationDesc = readString(dis);

					this.Location = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.BusinessId = readString(dis);

					this.Name = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.State = readString(dis);

					this.ZipCode = readString(dis);

					this.PhoneNumber = readString(dis);

					this.InspectionId = readString(dis);

					this.Date = readDate(dis);

					this.InspectionType = readString(dis);

					this.ViolationCodes = readString(dis);

					this.ViolationDesc = readString(dis);

					this.Location = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.BusinessId, dos);

				// String

				writeString(this.Name, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.State, dos);

				// String

				writeString(this.ZipCode, dos);

				// String

				writeString(this.PhoneNumber, dos);

				// String

				writeString(this.InspectionId, dos);

				// java.util.Date

				writeDate(this.Date, dos);

				// String

				writeString(this.InspectionType, dos);

				// String

				writeString(this.ViolationCodes, dos);

				// String

				writeString(this.ViolationDesc, dos);

				// String

				writeString(this.Location, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.BusinessId, dos);

				// String

				writeString(this.Name, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.State, dos);

				// String

				writeString(this.ZipCode, dos);

				// String

				writeString(this.PhoneNumber, dos);

				// String

				writeString(this.InspectionId, dos);

				// java.util.Date

				writeDate(this.Date, dos);

				// String

				writeString(this.InspectionType, dos);

				// String

				writeString(this.ViolationCodes, dos);

				// String

				writeString(this.ViolationDesc, dos);

				// String

				writeString(this.Location, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("BusinessId=" + BusinessId);
			sb.append(",Name=" + Name);
			sb.append(",Address=" + Address);
			sb.append(",City=" + City);
			sb.append(",State=" + State);
			sb.append(",ZipCode=" + ZipCode);
			sb.append(",PhoneNumber=" + PhoneNumber);
			sb.append(",InspectionId=" + InspectionId);
			sb.append(",Date=" + String.valueOf(Date));
			sb.append(",InspectionType=" + InspectionType);
			sb.append(",ViolationCodes=" + ViolationCodes);
			sb.append(",ViolationDesc=" + ViolationDesc);
			sb.append(",Location=" + Location);
			sb.append(",DI_CreatedDate=" + String.valueOf(DI_CreatedDate));
			sb.append(",DI_WorkflowFileName=" + DI_WorkflowFileName);
			sb.append(",DI_Workflow_ProcessID=" + DI_Workflow_ProcessID);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (BusinessId == null) {
				sb.append("<null>");
			} else {
				sb.append(BusinessId);
			}

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (Address == null) {
				sb.append("<null>");
			} else {
				sb.append(Address);
			}

			sb.append("|");

			if (City == null) {
				sb.append("<null>");
			} else {
				sb.append(City);
			}

			sb.append("|");

			if (State == null) {
				sb.append("<null>");
			} else {
				sb.append(State);
			}

			sb.append("|");

			if (ZipCode == null) {
				sb.append("<null>");
			} else {
				sb.append(ZipCode);
			}

			sb.append("|");

			if (PhoneNumber == null) {
				sb.append("<null>");
			} else {
				sb.append(PhoneNumber);
			}

			sb.append("|");

			if (InspectionId == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionId);
			}

			sb.append("|");

			if (Date == null) {
				sb.append("<null>");
			} else {
				sb.append(Date);
			}

			sb.append("|");

			if (InspectionType == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionType);
			}

			sb.append("|");

			if (ViolationCodes == null) {
				sb.append("<null>");
			} else {
				sb.append(ViolationCodes);
			}

			sb.append("|");

			if (ViolationDesc == null) {
				sb.append("<null>");
			} else {
				sb.append(ViolationDesc);
			}

			sb.append("|");

			if (Location == null) {
				sb.append("<null>");
			} else {
				sb.append(Location);
			}

			sb.append("|");

			if (DI_CreatedDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreatedDate);
			}

			sb.append("|");

			if (DI_WorkflowFileName == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_WorkflowFileName);
			}

			sb.append("|");

			if (DI_Workflow_ProcessID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Workflow_ProcessID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_1");
		org.slf4j.MDC.put("_subJobPid", "qBmFE9_" + subJobPidCounter.getAndIncrement());

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();
				row2Struct row2 = new row2Struct();
				row3Struct row3 = new row3Struct();
				ViolationDescStruct ViolationDesc = new ViolationDescStruct();
				row11Struct row11 = new row11Struct();
				ViolationCodeStruct ViolationCode = new ViolationCodeStruct();
				row4Struct row4 = new row4Struct();
				Facts_DimensionsStruct Facts_Dimensions = new Facts_DimensionsStruct();

				/**
				 * [tHashOutput_2 begin ] start
				 */

				ok_Hash.put("tHashOutput_2", false);
				start_Hash.put("tHashOutput_2", System.currentTimeMillis());

				currentComponent = "tHashOutput_2";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row11");

				int tos_count_tHashOutput_2 = 0;

				if (enableLogStash) {
					talendJobLog.addCM("tHashOutput_2", "tHashOutput_2", "tHashOutput");
					talendJobLogProcess(globalMap);
				}

				org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_2 = org.talend.designer.components.hashfile.common.MapHashFile
						.getMapHashFile();
				org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row11Struct> tHashFile_tHashOutput_2 = null;
				String hashKey_tHashOutput_2 = "tHashFile_DataPreparation_" + pid + "_tHashOutput_2";
				synchronized (org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap
						.get(hashKey_tHashOutput_2)) {
					if (mf_tHashOutput_2.getResourceMap().get(hashKey_tHashOutput_2) == null) {
						mf_tHashOutput_2.getResourceMap().put(hashKey_tHashOutput_2,
								new org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row11Struct>(
										org.talend.designer.components.hashfile.common.MATCHING_MODE.KEEP_ALL));
						tHashFile_tHashOutput_2 = mf_tHashOutput_2.getResourceMap().get(hashKey_tHashOutput_2);
					} else {
						tHashFile_tHashOutput_2 = mf_tHashOutput_2.getResourceMap().get(hashKey_tHashOutput_2);
					}
				}
				int nb_line_tHashOutput_2 = 0;

				/**
				 * [tHashOutput_2 begin ] stop
				 */

				/**
				 * [tNormalize_2 begin ] start
				 */

				ok_Hash.put("tNormalize_2", false);
				start_Hash.put("tNormalize_2", System.currentTimeMillis());

				currentComponent = "tNormalize_2";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "ViolationDesc");

				int tos_count_tNormalize_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tNormalize_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tNormalize_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tNormalize_2 = new StringBuilder();
							log4jParamters_tNormalize_2.append("Parameters:");
							log4jParamters_tNormalize_2.append("NORMALIZE_COLUMN" + " = " + "ViolationDesc");
							log4jParamters_tNormalize_2.append(" | ");
							log4jParamters_tNormalize_2.append("ITEMSEPARATOR" + " = " + "\"\\\\|\"");
							log4jParamters_tNormalize_2.append(" | ");
							log4jParamters_tNormalize_2.append("DEDUPLICATE" + " = " + "false");
							log4jParamters_tNormalize_2.append(" | ");
							log4jParamters_tNormalize_2.append("CSV_OPTION" + " = " + "false");
							log4jParamters_tNormalize_2.append(" | ");
							log4jParamters_tNormalize_2.append("DISCARD_TRAILING_EMPTY_STR" + " = " + "false");
							log4jParamters_tNormalize_2.append(" | ");
							log4jParamters_tNormalize_2.append("TRIM" + " = " + "false");
							log4jParamters_tNormalize_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tNormalize_2 - " + (log4jParamters_tNormalize_2));
						}
					}
					new BytesLimit65535_tNormalize_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tNormalize_2", "tNormalize_2", "tNormalize");
					talendJobLogProcess(globalMap);
				}

				int lastNoEmptyIndex_tNormalize_2 = 0;
				int nb_line_tNormalize_2 = 0;
				String tmp_tNormalize_2 = null;
				StringBuilder currentRecord_tNormalize_2 = null;
				String[] normalizeRecord_tNormalize_2 = null;
				java.util.Set<String> recordSet_tNormalize_2 = new java.util.HashSet<String>();

				if (((String) "\\|").length() == 0) {
					throw new IllegalArgumentException("Field Separator must be assigned a char.");
				}

				/**
				 * [tNormalize_2 begin ] stop
				 */

				/**
				 * [tHashOutput_1 begin ] start
				 */

				ok_Hash.put("tHashOutput_1", false);
				start_Hash.put("tHashOutput_1", System.currentTimeMillis());

				currentComponent = "tHashOutput_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row4");

				int tos_count_tHashOutput_1 = 0;

				if (enableLogStash) {
					talendJobLog.addCM("tHashOutput_1", "tHashOutput_1", "tHashOutput");
					talendJobLogProcess(globalMap);
				}

				org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_1 = org.talend.designer.components.hashfile.common.MapHashFile
						.getMapHashFile();
				org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row4Struct> tHashFile_tHashOutput_1 = null;
				String hashKey_tHashOutput_1 = "tHashFile_DataPreparation_" + pid + "_tHashOutput_1";
				synchronized (org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap
						.get(hashKey_tHashOutput_1)) {
					if (mf_tHashOutput_1.getResourceMap().get(hashKey_tHashOutput_1) == null) {
						mf_tHashOutput_1.getResourceMap().put(hashKey_tHashOutput_1,
								new org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row4Struct>(
										org.talend.designer.components.hashfile.common.MATCHING_MODE.KEEP_ALL));
						tHashFile_tHashOutput_1 = mf_tHashOutput_1.getResourceMap().get(hashKey_tHashOutput_1);
					} else {
						tHashFile_tHashOutput_1 = mf_tHashOutput_1.getResourceMap().get(hashKey_tHashOutput_1);
					}
				}
				int nb_line_tHashOutput_1 = 0;

				/**
				 * [tHashOutput_1 begin ] stop
				 */

				/**
				 * [tNormalize_1 begin ] start
				 */

				ok_Hash.put("tNormalize_1", false);
				start_Hash.put("tNormalize_1", System.currentTimeMillis());

				currentComponent = "tNormalize_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "ViolationCode");

				int tos_count_tNormalize_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tNormalize_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tNormalize_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tNormalize_1 = new StringBuilder();
							log4jParamters_tNormalize_1.append("Parameters:");
							log4jParamters_tNormalize_1.append("NORMALIZE_COLUMN" + " = " + "ViolationCodes");
							log4jParamters_tNormalize_1.append(" | ");
							log4jParamters_tNormalize_1.append("ITEMSEPARATOR" + " = " + "\"\\\\|\"");
							log4jParamters_tNormalize_1.append(" | ");
							log4jParamters_tNormalize_1.append("DEDUPLICATE" + " = " + "false");
							log4jParamters_tNormalize_1.append(" | ");
							log4jParamters_tNormalize_1.append("CSV_OPTION" + " = " + "false");
							log4jParamters_tNormalize_1.append(" | ");
							log4jParamters_tNormalize_1.append("DISCARD_TRAILING_EMPTY_STR" + " = " + "false");
							log4jParamters_tNormalize_1.append(" | ");
							log4jParamters_tNormalize_1.append("TRIM" + " = " + "false");
							log4jParamters_tNormalize_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tNormalize_1 - " + (log4jParamters_tNormalize_1));
						}
					}
					new BytesLimit65535_tNormalize_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tNormalize_1", "tNormalize_1", "tNormalize");
					talendJobLogProcess(globalMap);
				}

				int lastNoEmptyIndex_tNormalize_1 = 0;
				int nb_line_tNormalize_1 = 0;
				String tmp_tNormalize_1 = null;
				StringBuilder currentRecord_tNormalize_1 = null;
				String[] normalizeRecord_tNormalize_1 = null;
				java.util.Set<String> recordSet_tNormalize_1 = new java.util.HashSet<String>();

				if (((String) "\\|").length() == 0) {
					throw new IllegalArgumentException("Field Separator must be assigned a char.");
				}

				/**
				 * [tNormalize_1 begin ] stop
				 */

				/**
				 * [tHashOutput_3 begin ] start
				 */

				ok_Hash.put("tHashOutput_3", false);
				start_Hash.put("tHashOutput_3", System.currentTimeMillis());

				currentComponent = "tHashOutput_3";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Facts_Dimensions");

				int tos_count_tHashOutput_3 = 0;

				if (enableLogStash) {
					talendJobLog.addCM("tHashOutput_3", "tHashOutput_3", "tHashOutput");
					talendJobLogProcess(globalMap);
				}

				org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_3 = org.talend.designer.components.hashfile.common.MapHashFile
						.getMapHashFile();
				org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<Facts_DimensionsStruct> tHashFile_tHashOutput_3 = null;
				String hashKey_tHashOutput_3 = "tHashFile_DataPreparation_" + pid + "_tHashOutput_3";
				synchronized (org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap
						.get(hashKey_tHashOutput_3)) {
					if (mf_tHashOutput_3.getResourceMap().get(hashKey_tHashOutput_3) == null) {
						mf_tHashOutput_3.getResourceMap().put(hashKey_tHashOutput_3,
								new org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<Facts_DimensionsStruct>(
										org.talend.designer.components.hashfile.common.MATCHING_MODE.KEEP_ALL));
						tHashFile_tHashOutput_3 = mf_tHashOutput_3.getResourceMap().get(hashKey_tHashOutput_3);
					} else {
						tHashFile_tHashOutput_3 = mf_tHashOutput_3.getResourceMap().get(hashKey_tHashOutput_3);
					}
				}
				int nb_line_tHashOutput_3 = 0;

				/**
				 * [tHashOutput_3 begin ] stop
				 */

				/**
				 * [tMap_2 begin ] start
				 */

				ok_Hash.put("tMap_2", false);
				start_Hash.put("tMap_2", System.currentTimeMillis());

				currentComponent = "tMap_2";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row3");

				int tos_count_tMap_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_2 = new StringBuilder();
							log4jParamters_tMap_2.append("Parameters:");
							log4jParamters_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_2.append(" | ");
							log4jParamters_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_2.append(" | ");
							log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_2.append(" | ");
							log4jParamters_tMap_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_2 - " + (log4jParamters_tMap_2));
						}
					}
					new BytesLimit65535_tMap_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_2", "tMap_2", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row3_tMap_2 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_2__Struct {
				}
				Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_ViolationDesc_tMap_2 = 0;

				ViolationDescStruct ViolationDesc_tmp = new ViolationDescStruct();
				int count_ViolationCode_tMap_2 = 0;

				ViolationCodeStruct ViolationCode_tmp = new ViolationCodeStruct();
				int count_Facts_Dimensions_tMap_2 = 0;

				Facts_DimensionsStruct Facts_Dimensions_tmp = new Facts_DimensionsStruct();
// ###############################

				/**
				 * [tMap_2 begin ] stop
				 */

				/**
				 * [tExtractRegexFields_1 begin ] start
				 */

				ok_Hash.put("tExtractRegexFields_1", false);
				start_Hash.put("tExtractRegexFields_1", System.currentTimeMillis());

				currentComponent = "tExtractRegexFields_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row2");

				int tos_count_tExtractRegexFields_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tExtractRegexFields_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tExtractRegexFields_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tExtractRegexFields_1 = new StringBuilder();
							log4jParamters_tExtractRegexFields_1.append("Parameters:");
							log4jParamters_tExtractRegexFields_1.append("FIELD" + " = " + "Location");
							log4jParamters_tExtractRegexFields_1.append(" | ");
							log4jParamters_tExtractRegexFields_1.append("REGEX" + " = "
									+ "\".*\\n\\\\((-?[0-9]+\\\\.[0-9]+), (-?[0-9]+\\\\.[0-9]+)\\\\)\"");
							log4jParamters_tExtractRegexFields_1.append(" | ");
							log4jParamters_tExtractRegexFields_1.append("DIE_ON_ERROR" + " = " + "true");
							log4jParamters_tExtractRegexFields_1.append(" | ");
							log4jParamters_tExtractRegexFields_1.append("CHECK_FIELDS_NUM" + " = " + "false");
							log4jParamters_tExtractRegexFields_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tExtractRegexFields_1 - " + (log4jParamters_tExtractRegexFields_1));
						}
					}
					new BytesLimit65535_tExtractRegexFields_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tExtractRegexFields_1", "tExtractRegexFields_1", "tExtractRegexFields");
					talendJobLogProcess(globalMap);
				}

				java.util.regex.Pattern pattern_tExtractRegexFields_1 = java.util.regex.Pattern
						.compile(".*\n\\((-?[0-9]+\\.[0-9]+), (-?[0-9]+\\.[0-9]+)\\)");

				/**
				 * [tExtractRegexFields_1 begin ] stop
				 */

				/**
				 * [tFilterRow_6 begin ] start
				 */

				ok_Hash.put("tFilterRow_6", false);
				start_Hash.put("tFilterRow_6", System.currentTimeMillis());

				currentComponent = "tFilterRow_6";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row1");

				int tos_count_tFilterRow_6 = 0;

				if (log.isDebugEnabled())
					log.debug("tFilterRow_6 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tFilterRow_6 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tFilterRow_6 = new StringBuilder();
							log4jParamters_tFilterRow_6.append("Parameters:");
							log4jParamters_tFilterRow_6.append("LOGICAL_OP" + " = " + "||");
							log4jParamters_tFilterRow_6.append(" | ");
							log4jParamters_tFilterRow_6.append("CONDITIONS" + " = " + "[]");
							log4jParamters_tFilterRow_6.append(" | ");
							log4jParamters_tFilterRow_6.append("USE_ADVANCED" + " = " + "true");
							log4jParamters_tFilterRow_6.append(" | ");
							log4jParamters_tFilterRow_6.append("ADVANCED_COND" + " = "
									+ "// code sample : use input_row to define the condition. // input_row.columnName1.equals(\"foo\") ||!(input_row.columnName2.equals(\"bar\")) // replace the following expression by your own filter condition  Relational.ISNULL(input_row.Date)?false:true");
							log4jParamters_tFilterRow_6.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tFilterRow_6 - " + (log4jParamters_tFilterRow_6));
						}
					}
					new BytesLimit65535_tFilterRow_6().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tFilterRow_6", "tFilterRow_6", "tFilterRow");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tFilterRow_6 = 0;
				int nb_line_ok_tFilterRow_6 = 0;
				int nb_line_reject_tFilterRow_6 = 0;

				class Operator_tFilterRow_6 {
					private String sErrorMsg = "";
					private boolean bMatchFlag = true;
					private String sUnionFlag = "&&";

					public Operator_tFilterRow_6(String unionFlag) {
						sUnionFlag = unionFlag;
						bMatchFlag = "||".equals(unionFlag) ? false : true;
					}

					public String getErrorMsg() {
						if (sErrorMsg != null && sErrorMsg.length() > 1)
							return sErrorMsg.substring(1);
						else
							return null;
					}

					public boolean getMatchFlag() {
						return bMatchFlag;
					}

					public void matches(boolean partMatched, String reason) {
						// no need to care about the next judgement
						if ("||".equals(sUnionFlag) && bMatchFlag) {
							return;
						}

						if (!partMatched) {
							sErrorMsg += "|" + reason;
						}

						if ("||".equals(sUnionFlag))
							bMatchFlag = bMatchFlag || partMatched;
						else
							bMatchFlag = bMatchFlag && partMatched;
					}
				}

				/**
				 * [tFilterRow_6 begin ] stop
				 */

				/**
				 * [tDBInput_1 begin ] start
				 */

				ok_Hash.put("tDBInput_1", false);
				start_Hash.put("tDBInput_1", System.currentTimeMillis());

				currentComponent = "tDBInput_1";

				cLabel = "StagingMySQL";

				int tos_count_tDBInput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBInput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBInput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
							log4jParamters_tDBInput_1.append("Parameters:");
							log4jParamters_tDBInput_1.append("DB_VERSION" + " = " + "MYSQL_8");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("HOST" + " = " + "\"127.0.0.1\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PORT" + " = " + "\"3306\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("DBNAME" + " = " + "\"food_inspections\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("USER" + " = " + "\"user2\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:CodG9D+yKSyWJ3ptvT+M3FrjkfxPadbwO38CoGdmh7mIvWfb")
									.substring(0, 4) + "...");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"stg_ca_food_inspections\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append(
									"QUERY" + " = " + "\"SELECT * FROM food_inspections.stg_ca_food_inspections;\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PROPERTIES" + " = "
									+ "\"noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("ENABLE_STREAM" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("BusinessId") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("Name") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("Address")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("City") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("State") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("ZipCode") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("PhoneNumber")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("InspectionId") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("Date") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("InspectionType") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("ViolationCodes") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("ViolationDesc") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Location") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("DI_CreatedDate") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("DI_WorkflowFileName") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("DI_Workflow_ProcessID") + "}]");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
							log4jParamters_tDBInput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBInput_1 - " + (log4jParamters_tDBInput_1));
						}
					}
					new BytesLimit65535_tDBInput_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBInput_1", "StagingMySQL", "tMysqlInput");
					talendJobLogProcess(globalMap);
				}

				java.util.Calendar calendar_tDBInput_1 = java.util.Calendar.getInstance();
				calendar_tDBInput_1.set(0, 0, 0, 0, 0, 0);
				java.util.Date year0_tDBInput_1 = calendar_tDBInput_1.getTime();
				int nb_line_tDBInput_1 = 0;
				java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "com.mysql.cj.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBInput_1 = java.lang.Class.forName(driverClass_tDBInput_1);
				String dbUser_tDBInput_1 = "user2";

				final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:mkGIz/hqScDBmf10BFeJ7C7l9tPVxlDNjZE6oca3/e1b0B1V");

				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;

				String properties_tDBInput_1 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBInput_1 == null || properties_tDBInput_1.trim().length() == 0) {
					properties_tDBInput_1 = "";
				}
				String url_tDBInput_1 = "jdbc:mysql://" + "127.0.0.1" + ":" + "3306" + "/" + "food_inspections" + "?"
						+ properties_tDBInput_1;

				log.debug("tDBInput_1 - Driver ClassName: " + driverClass_tDBInput_1 + ".");

				log.debug("tDBInput_1 - Connection attempt to '" + url_tDBInput_1 + "' with the username '"
						+ dbUser_tDBInput_1 + "'.");

				conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1, dbUser_tDBInput_1,
						dbPwd_tDBInput_1);
				log.debug("tDBInput_1 - Connection to '" + url_tDBInput_1 + "' has succeeded.");

				java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

				String dbquery_tDBInput_1 = "SELECT * FROM food_inspections.stg_ca_food_inspections;";

				log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");

				globalMap.put("tDBInput_1_QUERY", dbquery_tDBInput_1);

				java.sql.ResultSet rs_tDBInput_1 = null;

				try {
					rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
					java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
					int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

					String tmpContent_tDBInput_1 = null;

					log.debug("tDBInput_1 - Retrieving records from the database.");

					while (rs_tDBInput_1.next()) {
						nb_line_tDBInput_1++;

						if (colQtyInRs_tDBInput_1 < 1) {
							row1.BusinessId = null;
						} else {

							row1.BusinessId = routines.system.JDBCUtil.getString(rs_tDBInput_1, 1, false);
						}
						if (colQtyInRs_tDBInput_1 < 2) {
							row1.Name = null;
						} else {

							row1.Name = routines.system.JDBCUtil.getString(rs_tDBInput_1, 2, false);
						}
						if (colQtyInRs_tDBInput_1 < 3) {
							row1.Address = null;
						} else {

							row1.Address = routines.system.JDBCUtil.getString(rs_tDBInput_1, 3, false);
						}
						if (colQtyInRs_tDBInput_1 < 4) {
							row1.City = null;
						} else {

							row1.City = routines.system.JDBCUtil.getString(rs_tDBInput_1, 4, false);
						}
						if (colQtyInRs_tDBInput_1 < 5) {
							row1.State = null;
						} else {

							row1.State = routines.system.JDBCUtil.getString(rs_tDBInput_1, 5, false);
						}
						if (colQtyInRs_tDBInput_1 < 6) {
							row1.ZipCode = null;
						} else {

							row1.ZipCode = routines.system.JDBCUtil.getString(rs_tDBInput_1, 6, false);
						}
						if (colQtyInRs_tDBInput_1 < 7) {
							row1.PhoneNumber = null;
						} else {

							row1.PhoneNumber = routines.system.JDBCUtil.getString(rs_tDBInput_1, 7, false);
						}
						if (colQtyInRs_tDBInput_1 < 8) {
							row1.InspectionId = null;
						} else {

							row1.InspectionId = routines.system.JDBCUtil.getString(rs_tDBInput_1, 8, false);
						}
						if (colQtyInRs_tDBInput_1 < 9) {
							row1.Date = null;
						} else {

							if (rs_tDBInput_1.getString(9) != null) {
								String dateString_tDBInput_1 = rs_tDBInput_1.getString(9);
								if (!("0000-00-00").equals(dateString_tDBInput_1)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
									row1.Date = rs_tDBInput_1.getTimestamp(9);
								} else {
									row1.Date = (java.util.Date) year0_tDBInput_1.clone();
								}
							} else {
								row1.Date = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 10) {
							row1.InspectionType = null;
						} else {

							row1.InspectionType = routines.system.JDBCUtil.getString(rs_tDBInput_1, 10, false);
						}
						if (colQtyInRs_tDBInput_1 < 11) {
							row1.ViolationCodes = null;
						} else {

							row1.ViolationCodes = routines.system.JDBCUtil.getString(rs_tDBInput_1, 11, false);
						}
						if (colQtyInRs_tDBInput_1 < 12) {
							row1.ViolationDesc = null;
						} else {

							row1.ViolationDesc = routines.system.JDBCUtil.getString(rs_tDBInput_1, 12, false);
						}
						if (colQtyInRs_tDBInput_1 < 13) {
							row1.Location = null;
						} else {

							row1.Location = routines.system.JDBCUtil.getString(rs_tDBInput_1, 13, false);
						}
						if (colQtyInRs_tDBInput_1 < 14) {
							row1.DI_CreatedDate = null;
						} else {

							if (rs_tDBInput_1.getString(14) != null) {
								String dateString_tDBInput_1 = rs_tDBInput_1.getString(14);
								if (!("0000-00-00").equals(dateString_tDBInput_1)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
									row1.DI_CreatedDate = rs_tDBInput_1.getTimestamp(14);
								} else {
									row1.DI_CreatedDate = (java.util.Date) year0_tDBInput_1.clone();
								}
							} else {
								row1.DI_CreatedDate = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 15) {
							row1.DI_WorkflowFileName = null;
						} else {

							row1.DI_WorkflowFileName = routines.system.JDBCUtil.getString(rs_tDBInput_1, 15, false);
						}
						if (colQtyInRs_tDBInput_1 < 16) {
							row1.DI_Workflow_ProcessID = null;
						} else {

							row1.DI_Workflow_ProcessID = routines.system.JDBCUtil.getString(rs_tDBInput_1, 16, false);
						}

						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");

						/**
						 * [tDBInput_1 begin ] stop
						 */

						/**
						 * [tDBInput_1 main ] start
						 */

						currentComponent = "tDBInput_1";

						cLabel = "StagingMySQL";

						tos_count_tDBInput_1++;

						/**
						 * [tDBInput_1 main ] stop
						 */

						/**
						 * [tDBInput_1 process_data_begin ] start
						 */

						currentComponent = "tDBInput_1";

						cLabel = "StagingMySQL";

						/**
						 * [tDBInput_1 process_data_begin ] stop
						 */

						/**
						 * [tFilterRow_6 main ] start
						 */

						currentComponent = "tFilterRow_6";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "row1", "tDBInput_1", "StagingMySQL", "tMysqlInput", "tFilterRow_6", "tFilterRow_6",
								"tFilterRow"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("row1 - " + (row1 == null ? "" : row1.toLogString()));
						}

						row2 = null;
						Operator_tFilterRow_6 ope_tFilterRow_6 = new Operator_tFilterRow_6("||");
						ope_tFilterRow_6.matches((// code sample : use row1 to define the condition.
// row1.columnName1.equals("foo") ||!(row1.columnName2.equals("bar"))
// replace the following expression by your own filter condition 
						Relational.ISNULL(row1.Date) ? false : true), "advanced condition failed");

						if (ope_tFilterRow_6.getMatchFlag()) {
							if (row2 == null) {
								row2 = new row2Struct();
							}
							row2.BusinessId = row1.BusinessId;
							row2.Name = row1.Name;
							row2.Address = row1.Address;
							row2.City = row1.City;
							row2.State = row1.State;
							row2.ZipCode = row1.ZipCode;
							row2.PhoneNumber = row1.PhoneNumber;
							row2.InspectionId = row1.InspectionId;
							row2.Date = row1.Date;
							row2.InspectionType = row1.InspectionType;
							row2.ViolationCodes = row1.ViolationCodes;
							row2.ViolationDesc = row1.ViolationDesc;
							row2.Location = row1.Location;
							row2.DI_CreatedDate = row1.DI_CreatedDate;
							row2.DI_WorkflowFileName = row1.DI_WorkflowFileName;
							row2.DI_Workflow_ProcessID = row1.DI_Workflow_ProcessID;
							log.debug("tFilterRow_6 - Process the record " + (nb_line_tFilterRow_6 + 1) + ".");

							nb_line_ok_tFilterRow_6++;
						} else {
							nb_line_reject_tFilterRow_6++;
						}

						nb_line_tFilterRow_6++;

						tos_count_tFilterRow_6++;

						/**
						 * [tFilterRow_6 main ] stop
						 */

						/**
						 * [tFilterRow_6 process_data_begin ] start
						 */

						currentComponent = "tFilterRow_6";

						/**
						 * [tFilterRow_6 process_data_begin ] stop
						 */
// Start of branch "row2"
						if (row2 != null) {

							/**
							 * [tExtractRegexFields_1 main ] start
							 */

							currentComponent = "tExtractRegexFields_1";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "row2", "tFilterRow_6", "tFilterRow_6", "tFilterRow", "tExtractRegexFields_1",
									"tExtractRegexFields_1", "tExtractRegexFields"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("row2 - " + (row2 == null ? "" : row2.toLogString()));
							}

							row3 = null;
							if (row2.Location != null) {// C_01
								java.util.regex.Matcher matcher_tExtractRegexFields_1 = pattern_tExtractRegexFields_1
										.matcher(row2.Location);

								int groupCount_tExtractRegexFields_1 = matcher_tExtractRegexFields_1.groupCount();
								while (matcher_tExtractRegexFields_1.find()) {
									currentComponent = "tExtractRegexFields_1";

									try {
										row3 = new row3Struct();
										row3.BusinessId = row2.BusinessId;
										row3.Name = row2.Name;
										row3.Address = row2.Address;
										row3.City = row2.City;
										row3.State = row2.State;
										row3.ZipCode = row2.ZipCode;
										row3.PhoneNumber = row2.PhoneNumber;
										row3.InspectionId = row2.InspectionId;
										row3.Date = row2.Date;
										row3.InspectionType = row2.InspectionType;
										row3.ViolationCodes = row2.ViolationCodes;
										row3.ViolationDesc = row2.ViolationDesc;
										row3.Location = row2.Location;
										row3.DI_CreatedDate = row2.DI_CreatedDate;
										row3.DI_WorkflowFileName = row2.DI_WorkflowFileName;
										row3.DI_Workflow_ProcessID = row2.DI_Workflow_ProcessID;

										String temp_tExtractRegexFields_1 = null;
										row3.Latitude = groupCount_tExtractRegexFields_1 <= 0 ? ""
												: matcher_tExtractRegexFields_1.group(1);
										row3.Longitude = groupCount_tExtractRegexFields_1 <= 1 ? ""
												: matcher_tExtractRegexFields_1.group(2);
									} catch (java.lang.Exception ex_tExtractRegexFields_1) {
										globalMap.put("tExtractRegexFields_1_ERROR_MESSAGE",
												ex_tExtractRegexFields_1.getMessage());
										throw (ex_tExtractRegexFields_1);
									}

									tos_count_tExtractRegexFields_1++;

									/**
									 * [tExtractRegexFields_1 main ] stop
									 */

									/**
									 * [tExtractRegexFields_1 process_data_begin ] start
									 */

									currentComponent = "tExtractRegexFields_1";

									/**
									 * [tExtractRegexFields_1 process_data_begin ] stop
									 */
// Start of branch "row3"
									if (row3 != null) {

										/**
										 * [tMap_2 main ] start
										 */

										currentComponent = "tMap_2";

										if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

												, "row3", "tExtractRegexFields_1", "tExtractRegexFields_1",
												"tExtractRegexFields", "tMap_2", "tMap_2", "tMap"

										)) {
											talendJobLogProcess(globalMap);
										}

										if (log.isTraceEnabled()) {
											log.trace("row3 - " + (row3 == null ? "" : row3.toLogString()));
										}

										boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;

										// ###############################
										// # Input tables (lookups)

										boolean rejectedInnerJoin_tMap_2 = false;
										boolean mainRowRejected_tMap_2 = false;
										// ###############################
										{ // start of Var scope

											// ###############################
											// # Vars tables

											Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
											// ###############################
											// # Output tables

											ViolationDesc = null;
											ViolationCode = null;
											Facts_Dimensions = null;

// # Output table : 'ViolationDesc'
											count_ViolationDesc_tMap_2++;

											ViolationDesc_tmp.ViolationDesc = row3.ViolationDesc;
											ViolationDesc_tmp.Violation_ID = Numeric.sequence("ViolationDescId", 1, 1);
											ViolationDesc = ViolationDesc_tmp;
											log.debug("tMap_2 - Outputting the record " + count_ViolationDesc_tMap_2
													+ " of the output table 'ViolationDesc'.");

// # Output table : 'ViolationCode'
											count_ViolationCode_tMap_2++;

											ViolationCode_tmp.ViolationCodes = row3.ViolationCodes;
											ViolationCode_tmp.Violation_ID = Numeric.sequence("ViolationCodeId", 1, 1);
											ViolationCode_tmp.InspectionId = row3.InspectionId;
											ViolationCode = ViolationCode_tmp;
											log.debug("tMap_2 - Outputting the record " + count_ViolationCode_tMap_2
													+ " of the output table 'ViolationCode'.");

// # Output table : 'Facts_Dimensions'
											count_Facts_Dimensions_tMap_2++;

											Facts_Dimensions_tmp.BusinessId = row3.BusinessId;
											Facts_Dimensions_tmp.Name = row3.Name;
											Facts_Dimensions_tmp.Address = row3.Address;
											Facts_Dimensions_tmp.City = row3.City;
											Facts_Dimensions_tmp.State = row3.State;
											Facts_Dimensions_tmp.ZipCode = row3.ZipCode;
											Facts_Dimensions_tmp.PhoneNumber = row3.PhoneNumber;
											Facts_Dimensions_tmp.InspectionId = row3.InspectionId;
											Facts_Dimensions_tmp.Date = row3.Date;
											Facts_Dimensions_tmp.InspectionType = row3.InspectionType;
											Facts_Dimensions_tmp.Location = row3.Location;
											Facts_Dimensions_tmp.Latitude = row3.Latitude;
											Facts_Dimensions_tmp.Longitude = row3.Longitude;
											Facts_Dimensions_tmp.DI_CreatedDate = row3.DI_CreatedDate;
											Facts_Dimensions_tmp.DI_WorkflowFileName = row3.DI_WorkflowFileName;
											Facts_Dimensions_tmp.DI_Workflow_ProcessID = row3.DI_Workflow_ProcessID;
											Facts_Dimensions_tmp.Date_SK = TalendDate.formatDate("yyyyMMdd", row3.Date);
											Facts_Dimensions_tmp.InspectionType_ID = Numeric
													.sequence("InspectionType_ID", 1, 1);
											Facts_Dimensions_tmp.Business_ID_SK = Numeric.sequence("Business_ID_SK", 1,
													1);
											Facts_Dimensions_tmp.Location_SK = Numeric.sequence("Location_SK", 1, 1);
											Facts_Dimensions_tmp.Inspection_SK = Numeric.sequence("Inspection_SK", 1,
													1);
											Facts_Dimensions = Facts_Dimensions_tmp;
											log.debug("tMap_2 - Outputting the record " + count_Facts_Dimensions_tMap_2
													+ " of the output table 'Facts_Dimensions'.");

// ###############################

										} // end of Var scope

										rejectedInnerJoin_tMap_2 = false;

										tos_count_tMap_2++;

										/**
										 * [tMap_2 main ] stop
										 */

										/**
										 * [tMap_2 process_data_begin ] start
										 */

										currentComponent = "tMap_2";

										/**
										 * [tMap_2 process_data_begin ] stop
										 */
// Start of branch "ViolationDesc"
										if (ViolationDesc != null) {

											/**
											 * [tNormalize_2 main ] start
											 */

											currentComponent = "tNormalize_2";

											if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

													, "ViolationDesc", "tMap_2", "tMap_2", "tMap", "tNormalize_2",
													"tNormalize_2", "tNormalize"

											)) {
												talendJobLogProcess(globalMap);
											}

											if (log.isTraceEnabled()) {
												log.trace("ViolationDesc - "
														+ (ViolationDesc == null ? "" : ViolationDesc.toLogString()));
											}

											normalizeRecord_tNormalize_2 = new String[1];
											if (ViolationDesc.ViolationDesc != null) {
												if ("".equals(ViolationDesc.ViolationDesc)) {
													normalizeRecord_tNormalize_2[0] = "";
												} else {

													normalizeRecord_tNormalize_2 = ViolationDesc.ViolationDesc
															.split("\\|", -1);

												}
											}
											lastNoEmptyIndex_tNormalize_2 = normalizeRecord_tNormalize_2.length;

											for (int i_tNormalize_2 = 0; i_tNormalize_2 < lastNoEmptyIndex_tNormalize_2; i_tNormalize_2++) {

												currentRecord_tNormalize_2 = new StringBuilder();
												nb_line_tNormalize_2++;

												row11.ViolationDesc = normalizeRecord_tNormalize_2[i_tNormalize_2];

												row11.Violation_ID = ViolationDesc.Violation_ID;

												tos_count_tNormalize_2++;

												/**
												 * [tNormalize_2 main ] stop
												 */

												/**
												 * [tNormalize_2 process_data_begin ] start
												 */

												currentComponent = "tNormalize_2";

												/**
												 * [tNormalize_2 process_data_begin ] stop
												 */

												/**
												 * [tHashOutput_2 main ] start
												 */

												currentComponent = "tHashOutput_2";

												if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

														, "row11", "tNormalize_2", "tNormalize_2", "tNormalize",
														"tHashOutput_2", "tHashOutput_2", "tHashOutput"

												)) {
													talendJobLogProcess(globalMap);
												}

												if (log.isTraceEnabled()) {
													log.trace("row11 - " + (row11 == null ? "" : row11.toLogString()));
												}

												row11Struct oneRow_tHashOutput_2 = new row11Struct();

												oneRow_tHashOutput_2.ViolationDesc = row11.ViolationDesc;
												oneRow_tHashOutput_2.Violation_ID = row11.Violation_ID;

												tHashFile_tHashOutput_2.put(oneRow_tHashOutput_2);
												nb_line_tHashOutput_2++;

												tos_count_tHashOutput_2++;

												/**
												 * [tHashOutput_2 main ] stop
												 */

												/**
												 * [tHashOutput_2 process_data_begin ] start
												 */

												currentComponent = "tHashOutput_2";

												/**
												 * [tHashOutput_2 process_data_begin ] stop
												 */

												/**
												 * [tHashOutput_2 process_data_end ] start
												 */

												currentComponent = "tHashOutput_2";

												/**
												 * [tHashOutput_2 process_data_end ] stop
												 */
												// end for
											}

											/**
											 * [tNormalize_2 process_data_end ] start
											 */

											currentComponent = "tNormalize_2";

											/**
											 * [tNormalize_2 process_data_end ] stop
											 */

										} // End of branch "ViolationDesc"

// Start of branch "ViolationCode"
										if (ViolationCode != null) {

											/**
											 * [tNormalize_1 main ] start
											 */

											currentComponent = "tNormalize_1";

											if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

													, "ViolationCode", "tMap_2", "tMap_2", "tMap", "tNormalize_1",
													"tNormalize_1", "tNormalize"

											)) {
												talendJobLogProcess(globalMap);
											}

											if (log.isTraceEnabled()) {
												log.trace("ViolationCode - "
														+ (ViolationCode == null ? "" : ViolationCode.toLogString()));
											}

											normalizeRecord_tNormalize_1 = new String[1];
											if (ViolationCode.ViolationCodes != null) {
												if ("".equals(ViolationCode.ViolationCodes)) {
													normalizeRecord_tNormalize_1[0] = "";
												} else {

													normalizeRecord_tNormalize_1 = ViolationCode.ViolationCodes
															.split("\\|", -1);

												}
											}
											lastNoEmptyIndex_tNormalize_1 = normalizeRecord_tNormalize_1.length;

											for (int i_tNormalize_1 = 0; i_tNormalize_1 < lastNoEmptyIndex_tNormalize_1; i_tNormalize_1++) {

												currentRecord_tNormalize_1 = new StringBuilder();
												nb_line_tNormalize_1++;

												row4.ViolationCodes = normalizeRecord_tNormalize_1[i_tNormalize_1];

												row4.Violation_ID = ViolationCode.Violation_ID;

												row4.InspectionId = ViolationCode.InspectionId;

												tos_count_tNormalize_1++;

												/**
												 * [tNormalize_1 main ] stop
												 */

												/**
												 * [tNormalize_1 process_data_begin ] start
												 */

												currentComponent = "tNormalize_1";

												/**
												 * [tNormalize_1 process_data_begin ] stop
												 */

												/**
												 * [tHashOutput_1 main ] start
												 */

												currentComponent = "tHashOutput_1";

												if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

														, "row4", "tNormalize_1", "tNormalize_1", "tNormalize",
														"tHashOutput_1", "tHashOutput_1", "tHashOutput"

												)) {
													talendJobLogProcess(globalMap);
												}

												if (log.isTraceEnabled()) {
													log.trace("row4 - " + (row4 == null ? "" : row4.toLogString()));
												}

												row4Struct oneRow_tHashOutput_1 = new row4Struct();

												oneRow_tHashOutput_1.ViolationCodes = row4.ViolationCodes;
												oneRow_tHashOutput_1.Violation_ID = row4.Violation_ID;
												oneRow_tHashOutput_1.InspectionId = row4.InspectionId;

												tHashFile_tHashOutput_1.put(oneRow_tHashOutput_1);
												nb_line_tHashOutput_1++;

												tos_count_tHashOutput_1++;

												/**
												 * [tHashOutput_1 main ] stop
												 */

												/**
												 * [tHashOutput_1 process_data_begin ] start
												 */

												currentComponent = "tHashOutput_1";

												/**
												 * [tHashOutput_1 process_data_begin ] stop
												 */

												/**
												 * [tHashOutput_1 process_data_end ] start
												 */

												currentComponent = "tHashOutput_1";

												/**
												 * [tHashOutput_1 process_data_end ] stop
												 */
												// end for
											}

											/**
											 * [tNormalize_1 process_data_end ] start
											 */

											currentComponent = "tNormalize_1";

											/**
											 * [tNormalize_1 process_data_end ] stop
											 */

										} // End of branch "ViolationCode"

// Start of branch "Facts_Dimensions"
										if (Facts_Dimensions != null) {

											/**
											 * [tHashOutput_3 main ] start
											 */

											currentComponent = "tHashOutput_3";

											if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

													, "Facts_Dimensions", "tMap_2", "tMap_2", "tMap", "tHashOutput_3",
													"tHashOutput_3", "tHashOutput"

											)) {
												talendJobLogProcess(globalMap);
											}

											if (log.isTraceEnabled()) {
												log.trace("Facts_Dimensions - " + (Facts_Dimensions == null ? ""
														: Facts_Dimensions.toLogString()));
											}

											Facts_DimensionsStruct oneRow_tHashOutput_3 = new Facts_DimensionsStruct();

											oneRow_tHashOutput_3.BusinessId = Facts_Dimensions.BusinessId;
											oneRow_tHashOutput_3.Name = Facts_Dimensions.Name;
											oneRow_tHashOutput_3.Address = Facts_Dimensions.Address;
											oneRow_tHashOutput_3.City = Facts_Dimensions.City;
											oneRow_tHashOutput_3.State = Facts_Dimensions.State;
											oneRow_tHashOutput_3.ZipCode = Facts_Dimensions.ZipCode;
											oneRow_tHashOutput_3.PhoneNumber = Facts_Dimensions.PhoneNumber;
											oneRow_tHashOutput_3.InspectionId = Facts_Dimensions.InspectionId;
											oneRow_tHashOutput_3.Date = Facts_Dimensions.Date;
											oneRow_tHashOutput_3.InspectionType = Facts_Dimensions.InspectionType;
											oneRow_tHashOutput_3.Location = Facts_Dimensions.Location;
											oneRow_tHashOutput_3.Latitude = Facts_Dimensions.Latitude;
											oneRow_tHashOutput_3.Longitude = Facts_Dimensions.Longitude;
											oneRow_tHashOutput_3.DI_CreatedDate = Facts_Dimensions.DI_CreatedDate;
											oneRow_tHashOutput_3.DI_WorkflowFileName = Facts_Dimensions.DI_WorkflowFileName;
											oneRow_tHashOutput_3.DI_Workflow_ProcessID = Facts_Dimensions.DI_Workflow_ProcessID;
											oneRow_tHashOutput_3.Date_SK = Facts_Dimensions.Date_SK;
											oneRow_tHashOutput_3.InspectionType_ID = Facts_Dimensions.InspectionType_ID;
											oneRow_tHashOutput_3.Business_ID_SK = Facts_Dimensions.Business_ID_SK;
											oneRow_tHashOutput_3.Location_SK = Facts_Dimensions.Location_SK;
											oneRow_tHashOutput_3.Inspection_SK = Facts_Dimensions.Inspection_SK;

											tHashFile_tHashOutput_3.put(oneRow_tHashOutput_3);
											nb_line_tHashOutput_3++;

											tos_count_tHashOutput_3++;

											/**
											 * [tHashOutput_3 main ] stop
											 */

											/**
											 * [tHashOutput_3 process_data_begin ] start
											 */

											currentComponent = "tHashOutput_3";

											/**
											 * [tHashOutput_3 process_data_begin ] stop
											 */

											/**
											 * [tHashOutput_3 process_data_end ] start
											 */

											currentComponent = "tHashOutput_3";

											/**
											 * [tHashOutput_3 process_data_end ] stop
											 */

										} // End of branch "Facts_Dimensions"

										/**
										 * [tMap_2 process_data_end ] start
										 */

										currentComponent = "tMap_2";

										/**
										 * [tMap_2 process_data_end ] stop
										 */

									} // End of branch "row3"

									// end for
								}

							} // C_01

							/**
							 * [tExtractRegexFields_1 process_data_end ] start
							 */

							currentComponent = "tExtractRegexFields_1";

							/**
							 * [tExtractRegexFields_1 process_data_end ] stop
							 */

						} // End of branch "row2"

						/**
						 * [tFilterRow_6 process_data_end ] start
						 */

						currentComponent = "tFilterRow_6";

						/**
						 * [tFilterRow_6 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 process_data_end ] start
						 */

						currentComponent = "tDBInput_1";

						cLabel = "StagingMySQL";

						/**
						 * [tDBInput_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 end ] start
						 */

						currentComponent = "tDBInput_1";

						cLabel = "StagingMySQL";

					}
				} finally {
					if (rs_tDBInput_1 != null) {
						rs_tDBInput_1.close();
					}
					if (stmt_tDBInput_1 != null) {
						stmt_tDBInput_1.close();
					}
					if (conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {

						log.debug("tDBInput_1 - Closing the connection to the database.");

						conn_tDBInput_1.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

						log.debug("tDBInput_1 - Connection to the database closed.");

					}

				}
				globalMap.put("tDBInput_1_NB_LINE", nb_line_tDBInput_1);
				log.debug("tDBInput_1 - Retrieved records count: " + nb_line_tDBInput_1 + " .");

				if (log.isDebugEnabled())
					log.debug("tDBInput_1 - " + ("Done."));

				ok_Hash.put("tDBInput_1", true);
				end_Hash.put("tDBInput_1", System.currentTimeMillis());

				/**
				 * [tDBInput_1 end ] stop
				 */

				/**
				 * [tFilterRow_6 end ] start
				 */

				currentComponent = "tFilterRow_6";

				globalMap.put("tFilterRow_6_NB_LINE", nb_line_tFilterRow_6);
				globalMap.put("tFilterRow_6_NB_LINE_OK", nb_line_ok_tFilterRow_6);
				globalMap.put("tFilterRow_6_NB_LINE_REJECT", nb_line_reject_tFilterRow_6);

				log.info("tFilterRow_6 - Processed records count:" + nb_line_tFilterRow_6 + ". Matched records count:"
						+ nb_line_ok_tFilterRow_6 + ". Rejected records count:" + nb_line_reject_tFilterRow_6 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row1", 2, 0,
						"tDBInput_1", "StagingMySQL", "tMysqlInput", "tFilterRow_6", "tFilterRow_6", "tFilterRow",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tFilterRow_6 - " + ("Done."));

				ok_Hash.put("tFilterRow_6", true);
				end_Hash.put("tFilterRow_6", System.currentTimeMillis());

				/**
				 * [tFilterRow_6 end ] stop
				 */

				/**
				 * [tExtractRegexFields_1 end ] start
				 */

				currentComponent = "tExtractRegexFields_1";

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row2", 2, 0,
						"tFilterRow_6", "tFilterRow_6", "tFilterRow", "tExtractRegexFields_1", "tExtractRegexFields_1",
						"tExtractRegexFields", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tExtractRegexFields_1 - " + ("Done."));

				ok_Hash.put("tExtractRegexFields_1", true);
				end_Hash.put("tExtractRegexFields_1", System.currentTimeMillis());

				/**
				 * [tExtractRegexFields_1 end ] stop
				 */

				/**
				 * [tMap_2 end ] start
				 */

				currentComponent = "tMap_2";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_2 - Written records count in the table 'ViolationDesc': " + count_ViolationDesc_tMap_2
						+ ".");
				log.debug("tMap_2 - Written records count in the table 'ViolationCode': " + count_ViolationCode_tMap_2
						+ ".");
				log.debug("tMap_2 - Written records count in the table 'Facts_Dimensions': "
						+ count_Facts_Dimensions_tMap_2 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row3", 2, 0,
						"tExtractRegexFields_1", "tExtractRegexFields_1", "tExtractRegexFields", "tMap_2", "tMap_2",
						"tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_2 - " + ("Done."));

				ok_Hash.put("tMap_2", true);
				end_Hash.put("tMap_2", System.currentTimeMillis());

				/**
				 * [tMap_2 end ] stop
				 */

				/**
				 * [tNormalize_2 end ] start
				 */

				currentComponent = "tNormalize_2";

				globalMap.put("tNormalize_2_NB_LINE", nb_line_tNormalize_2);
				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "ViolationDesc", 2, 0,
						"tMap_2", "tMap_2", "tMap", "tNormalize_2", "tNormalize_2", "tNormalize", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tNormalize_2 - " + ("Done."));

				ok_Hash.put("tNormalize_2", true);
				end_Hash.put("tNormalize_2", System.currentTimeMillis());

				/**
				 * [tNormalize_2 end ] stop
				 */

				/**
				 * [tHashOutput_2 end ] start
				 */

				currentComponent = "tHashOutput_2";

				globalMap.put("tHashOutput_2_NB_LINE", nb_line_tHashOutput_2);
				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row11", 2, 0,
						"tNormalize_2", "tNormalize_2", "tNormalize", "tHashOutput_2", "tHashOutput_2", "tHashOutput",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				ok_Hash.put("tHashOutput_2", true);
				end_Hash.put("tHashOutput_2", System.currentTimeMillis());

				/**
				 * [tHashOutput_2 end ] stop
				 */

				/**
				 * [tNormalize_1 end ] start
				 */

				currentComponent = "tNormalize_1";

				globalMap.put("tNormalize_1_NB_LINE", nb_line_tNormalize_1);
				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "ViolationCode", 2, 0,
						"tMap_2", "tMap_2", "tMap", "tNormalize_1", "tNormalize_1", "tNormalize", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tNormalize_1 - " + ("Done."));

				ok_Hash.put("tNormalize_1", true);
				end_Hash.put("tNormalize_1", System.currentTimeMillis());

				/**
				 * [tNormalize_1 end ] stop
				 */

				/**
				 * [tHashOutput_1 end ] start
				 */

				currentComponent = "tHashOutput_1";

				globalMap.put("tHashOutput_1_NB_LINE", nb_line_tHashOutput_1);
				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row4", 2, 0,
						"tNormalize_1", "tNormalize_1", "tNormalize", "tHashOutput_1", "tHashOutput_1", "tHashOutput",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				ok_Hash.put("tHashOutput_1", true);
				end_Hash.put("tHashOutput_1", System.currentTimeMillis());

				/**
				 * [tHashOutput_1 end ] stop
				 */

				/**
				 * [tHashOutput_3 end ] start
				 */

				currentComponent = "tHashOutput_3";

				globalMap.put("tHashOutput_3_NB_LINE", nb_line_tHashOutput_3);
				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Facts_Dimensions", 2, 0,
						"tMap_2", "tMap_2", "tMap", "tHashOutput_3", "tHashOutput_3", "tHashOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				ok_Hash.put("tHashOutput_3", true);
				end_Hash.put("tHashOutput_3", System.currentTimeMillis());

				/**
				 * [tHashOutput_3 end ] stop
				 */

			} // end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBInput_1:OnSubjobOk", "",
						Thread.currentThread().getId() + "", "", "", "", "", "");
			}

			if (execStat) {
				runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
			}

			tHashInput_2Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_1 finally ] start
				 */

				currentComponent = "tDBInput_1";

				cLabel = "StagingMySQL";

				/**
				 * [tDBInput_1 finally ] stop
				 */

				/**
				 * [tFilterRow_6 finally ] start
				 */

				currentComponent = "tFilterRow_6";

				/**
				 * [tFilterRow_6 finally ] stop
				 */

				/**
				 * [tExtractRegexFields_1 finally ] start
				 */

				currentComponent = "tExtractRegexFields_1";

				/**
				 * [tExtractRegexFields_1 finally ] stop
				 */

				/**
				 * [tMap_2 finally ] start
				 */

				currentComponent = "tMap_2";

				/**
				 * [tMap_2 finally ] stop
				 */

				/**
				 * [tNormalize_2 finally ] start
				 */

				currentComponent = "tNormalize_2";

				/**
				 * [tNormalize_2 finally ] stop
				 */

				/**
				 * [tHashOutput_2 finally ] start
				 */

				currentComponent = "tHashOutput_2";

				/**
				 * [tHashOutput_2 finally ] stop
				 */

				/**
				 * [tNormalize_1 finally ] start
				 */

				currentComponent = "tNormalize_1";

				/**
				 * [tNormalize_1 finally ] stop
				 */

				/**
				 * [tHashOutput_1 finally ] start
				 */

				currentComponent = "tHashOutput_1";

				/**
				 * [tHashOutput_1 finally ] stop
				 */

				/**
				 * [tHashOutput_3 finally ] start
				 */

				currentComponent = "tHashOutput_3";

				/**
				 * [tHashOutput_3 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}

	public static class ViolationCode_DescStruct implements routines.system.IPersistableRow<ViolationCode_DescStruct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public Integer Violation_ID;

		public Integer getViolation_ID() {
			return this.Violation_ID;
		}

		public Boolean Violation_IDIsNullable() {
			return true;
		}

		public Boolean Violation_IDIsKey() {
			return false;
		}

		public Integer Violation_IDLength() {
			return null;
		}

		public Integer Violation_IDPrecision() {
			return null;
		}

		public String Violation_IDDefault() {

			return null;

		}

		public String Violation_IDComment() {

			return "";

		}

		public String Violation_IDPattern() {

			return "";

		}

		public String Violation_IDOriginalDbColumnName() {

			return "Violation_ID";

		}

		public String InspectionId;

		public String getInspectionId() {
			return this.InspectionId;
		}

		public Boolean InspectionIdIsNullable() {
			return true;
		}

		public Boolean InspectionIdIsKey() {
			return false;
		}

		public Integer InspectionIdLength() {
			return 9;
		}

		public Integer InspectionIdPrecision() {
			return 0;
		}

		public String InspectionIdDefault() {

			return null;

		}

		public String InspectionIdComment() {

			return "";

		}

		public String InspectionIdPattern() {

			return "";

		}

		public String InspectionIdOriginalDbColumnName() {

			return "InspectionId";

		}

		public String ViolationCodes;

		public String getViolationCodes() {
			return this.ViolationCodes;
		}

		public Boolean ViolationCodesIsNullable() {
			return true;
		}

		public Boolean ViolationCodesIsKey() {
			return false;
		}

		public Integer ViolationCodesLength() {
			return 150;
		}

		public Integer ViolationCodesPrecision() {
			return 0;
		}

		public String ViolationCodesDefault() {

			return null;

		}

		public String ViolationCodesComment() {

			return "";

		}

		public String ViolationCodesPattern() {

			return "";

		}

		public String ViolationCodesOriginalDbColumnName() {

			return "ViolationCodes";

		}

		public String ViolationCategory;

		public String getViolationCategory() {
			return this.ViolationCategory;
		}

		public Boolean ViolationCategoryIsNullable() {
			return true;
		}

		public Boolean ViolationCategoryIsKey() {
			return false;
		}

		public Integer ViolationCategoryLength() {
			return null;
		}

		public Integer ViolationCategoryPrecision() {
			return null;
		}

		public String ViolationCategoryDefault() {

			return null;

		}

		public String ViolationCategoryComment() {

			return "";

		}

		public String ViolationCategoryPattern() {

			return "";

		}

		public String ViolationCategoryOriginalDbColumnName() {

			return "ViolationCategory";

		}

		public Integer CodeScore;

		public Integer getCodeScore() {
			return this.CodeScore;
		}

		public Boolean CodeScoreIsNullable() {
			return true;
		}

		public Boolean CodeScoreIsKey() {
			return false;
		}

		public Integer CodeScoreLength() {
			return null;
		}

		public Integer CodeScorePrecision() {
			return null;
		}

		public String CodeScoreDefault() {

			return null;

		}

		public String CodeScoreComment() {

			return "";

		}

		public String CodeScorePattern() {

			return "";

		}

		public String CodeScoreOriginalDbColumnName() {

			return "CodeScore";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Violation_ID = readInteger(dis);

					this.InspectionId = readString(dis);

					this.ViolationCodes = readString(dis);

					this.ViolationCategory = readString(dis);

					this.CodeScore = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Violation_ID = readInteger(dis);

					this.InspectionId = readString(dis);

					this.ViolationCodes = readString(dis);

					this.ViolationCategory = readString(dis);

					this.CodeScore = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.Violation_ID, dos);

				// String

				writeString(this.InspectionId, dos);

				// String

				writeString(this.ViolationCodes, dos);

				// String

				writeString(this.ViolationCategory, dos);

				// Integer

				writeInteger(this.CodeScore, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.Violation_ID, dos);

				// String

				writeString(this.InspectionId, dos);

				// String

				writeString(this.ViolationCodes, dos);

				// String

				writeString(this.ViolationCategory, dos);

				// Integer

				writeInteger(this.CodeScore, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Violation_ID=" + String.valueOf(Violation_ID));
			sb.append(",InspectionId=" + InspectionId);
			sb.append(",ViolationCodes=" + ViolationCodes);
			sb.append(",ViolationCategory=" + ViolationCategory);
			sb.append(",CodeScore=" + String.valueOf(CodeScore));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (Violation_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(Violation_ID);
			}

			sb.append("|");

			if (InspectionId == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionId);
			}

			sb.append("|");

			if (ViolationCodes == null) {
				sb.append("<null>");
			} else {
				sb.append(ViolationCodes);
			}

			sb.append("|");

			if (ViolationCategory == null) {
				sb.append("<null>");
			} else {
				sb.append(ViolationCategory);
			}

			sb.append("|");

			if (CodeScore == null) {
				sb.append("<null>");
			} else {
				sb.append(CodeScore);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(ViolationCode_DescStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public String ViolationDesc;

		public String getViolationDesc() {
			return this.ViolationDesc;
		}

		public Boolean ViolationDescIsNullable() {
			return true;
		}

		public Boolean ViolationDescIsKey() {
			return false;
		}

		public Integer ViolationDescLength() {
			return 1200;
		}

		public Integer ViolationDescPrecision() {
			return 0;
		}

		public String ViolationDescDefault() {

			return null;

		}

		public String ViolationDescComment() {

			return "";

		}

		public String ViolationDescPattern() {

			return "";

		}

		public String ViolationDescOriginalDbColumnName() {

			return "ViolationDesc";

		}

		public Integer Violation_ID;

		public Integer getViolation_ID() {
			return this.Violation_ID;
		}

		public Boolean Violation_IDIsNullable() {
			return true;
		}

		public Boolean Violation_IDIsKey() {
			return false;
		}

		public Integer Violation_IDLength() {
			return 9;
		}

		public Integer Violation_IDPrecision() {
			return 0;
		}

		public String Violation_IDDefault() {

			return null;

		}

		public String Violation_IDComment() {

			return "";

		}

		public String Violation_IDPattern() {

			return "";

		}

		public String Violation_IDOriginalDbColumnName() {

			return "Violation_ID";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.ViolationDesc = readString(dis);

					this.Violation_ID = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.ViolationDesc = readString(dis);

					this.Violation_ID = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.ViolationDesc, dos);

				// Integer

				writeInteger(this.Violation_ID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.ViolationDesc, dos);

				// Integer

				writeInteger(this.Violation_ID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("ViolationDesc=" + ViolationDesc);
			sb.append(",Violation_ID=" + String.valueOf(Violation_ID));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (ViolationDesc == null) {
				sb.append("<null>");
			} else {
				sb.append(ViolationDesc);
			}

			sb.append("|");

			if (Violation_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(Violation_ID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row9Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class after_tHashInput_2Struct implements routines.system.IPersistableRow<after_tHashInput_2Struct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public String ViolationDesc;

		public String getViolationDesc() {
			return this.ViolationDesc;
		}

		public Boolean ViolationDescIsNullable() {
			return true;
		}

		public Boolean ViolationDescIsKey() {
			return false;
		}

		public Integer ViolationDescLength() {
			return 1200;
		}

		public Integer ViolationDescPrecision() {
			return 0;
		}

		public String ViolationDescDefault() {

			return null;

		}

		public String ViolationDescComment() {

			return "";

		}

		public String ViolationDescPattern() {

			return "";

		}

		public String ViolationDescOriginalDbColumnName() {

			return "ViolationDesc";

		}

		public Integer Violation_ID;

		public Integer getViolation_ID() {
			return this.Violation_ID;
		}

		public Boolean Violation_IDIsNullable() {
			return true;
		}

		public Boolean Violation_IDIsKey() {
			return false;
		}

		public Integer Violation_IDLength() {
			return 9;
		}

		public Integer Violation_IDPrecision() {
			return 0;
		}

		public String Violation_IDDefault() {

			return null;

		}

		public String Violation_IDComment() {

			return "";

		}

		public String Violation_IDPattern() {

			return "";

		}

		public String Violation_IDOriginalDbColumnName() {

			return "Violation_ID";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.ViolationDesc = readString(dis);

					this.Violation_ID = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.ViolationDesc = readString(dis);

					this.Violation_ID = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.ViolationDesc, dos);

				// Integer

				writeInteger(this.Violation_ID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.ViolationDesc, dos);

				// Integer

				writeInteger(this.Violation_ID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("ViolationDesc=" + ViolationDesc);
			sb.append(",Violation_ID=" + String.valueOf(Violation_ID));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (ViolationDesc == null) {
				sb.append("<null>");
			} else {
				sb.append(ViolationDesc);
			}

			sb.append("|");

			if (Violation_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(Violation_ID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(after_tHashInput_2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tHashInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tHashInput_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tHashInput_2");
		org.slf4j.MDC.put("_subJobPid", "5AwDO7_" + subJobPidCounter.getAndIncrement());

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				tHashInput_1Process(globalMap);

				row9Struct row9 = new row9Struct();
				ViolationCode_DescStruct ViolationCode_Desc = new ViolationCode_DescStruct();

				/**
				 * [tHashOutput_4 begin ] start
				 */

				ok_Hash.put("tHashOutput_4", false);
				start_Hash.put("tHashOutput_4", System.currentTimeMillis());

				currentComponent = "tHashOutput_4";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "ViolationCode_Desc");

				int tos_count_tHashOutput_4 = 0;

				if (enableLogStash) {
					talendJobLog.addCM("tHashOutput_4", "tHashOutput_4", "tHashOutput");
					talendJobLogProcess(globalMap);
				}

				org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_4 = org.talend.designer.components.hashfile.common.MapHashFile
						.getMapHashFile();
				org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<ViolationCode_DescStruct> tHashFile_tHashOutput_4 = null;
				String hashKey_tHashOutput_4 = "tHashFile_DataPreparation_" + pid + "_tHashOutput_4";
				synchronized (org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap
						.get(hashKey_tHashOutput_4)) {
					if (mf_tHashOutput_4.getResourceMap().get(hashKey_tHashOutput_4) == null) {
						mf_tHashOutput_4.getResourceMap().put(hashKey_tHashOutput_4,
								new org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<ViolationCode_DescStruct>(
										org.talend.designer.components.hashfile.common.MATCHING_MODE.KEEP_ALL));
						tHashFile_tHashOutput_4 = mf_tHashOutput_4.getResourceMap().get(hashKey_tHashOutput_4);
					} else {
						tHashFile_tHashOutput_4 = mf_tHashOutput_4.getResourceMap().get(hashKey_tHashOutput_4);
					}
				}
				int nb_line_tHashOutput_4 = 0;

				/**
				 * [tHashOutput_4 begin ] stop
				 */

				/**
				 * [tMap_3 begin ] start
				 */

				ok_Hash.put("tMap_3", false);
				start_Hash.put("tMap_3", System.currentTimeMillis());

				currentComponent = "tMap_3";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row9");

				int tos_count_tMap_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_3 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_3 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_3 = new StringBuilder();
							log4jParamters_tMap_3.append("Parameters:");
							log4jParamters_tMap_3.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_3.append(" | ");
							log4jParamters_tMap_3.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_3.append(" | ");
							log4jParamters_tMap_3.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_3.append(" | ");
							log4jParamters_tMap_3.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_3.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_3 - " + (log4jParamters_tMap_3));
						}
					}
					new BytesLimit65535_tMap_3().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_3", "tMap_3", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row9_tMap_3 = 0;

				int count_row10_tMap_3 = 0;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row10Struct> tHash_Lookup_row10 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row10Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row10Struct>) globalMap
						.get("tHash_Lookup_row10"));

				row10Struct row10HashKey = new row10Struct();
				row10Struct row10Default = new row10Struct();
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_3__Struct {
					String v_category;
				}
				Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_ViolationCode_Desc_tMap_3 = 0;

				ViolationCode_DescStruct ViolationCode_Desc_tmp = new ViolationCode_DescStruct();
// ###############################

				/**
				 * [tMap_3 begin ] stop
				 */

				/**
				 * [tHashInput_2 begin ] start
				 */

				ok_Hash.put("tHashInput_2", false);
				start_Hash.put("tHashInput_2", System.currentTimeMillis());

				currentComponent = "tHashInput_2";

				int tos_count_tHashInput_2 = 0;

				if (enableLogStash) {
					talendJobLog.addCM("tHashInput_2", "tHashInput_2", "tHashInput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tHashInput_2 = 0;

				org.talend.designer.components.hashfile.common.MapHashFile mf_tHashInput_2 = org.talend.designer.components.hashfile.common.MapHashFile
						.getMapHashFile();
				org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row11Struct> tHashFile_tHashInput_2 = mf_tHashInput_2
						.getAdvancedMemoryHashFile("tHashFile_DataPreparation_" + pid + "_tHashOutput_2");
				if (tHashFile_tHashInput_2 == null) {
					throw new RuntimeException(
							"The hash is not initialized : The hash must exist before you read from it");
				}
				java.util.Iterator<row11Struct> iterator_tHashInput_2 = tHashFile_tHashInput_2.iterator();
				while (iterator_tHashInput_2.hasNext()) {
					row11Struct next_tHashInput_2 = iterator_tHashInput_2.next();

					row9.ViolationDesc = next_tHashInput_2.ViolationDesc;
					row9.Violation_ID = next_tHashInput_2.Violation_ID;

					/**
					 * [tHashInput_2 begin ] stop
					 */

					/**
					 * [tHashInput_2 main ] start
					 */

					currentComponent = "tHashInput_2";

					tos_count_tHashInput_2++;

					/**
					 * [tHashInput_2 main ] stop
					 */

					/**
					 * [tHashInput_2 process_data_begin ] start
					 */

					currentComponent = "tHashInput_2";

					/**
					 * [tHashInput_2 process_data_begin ] stop
					 */

					/**
					 * [tMap_3 main ] start
					 */

					currentComponent = "tMap_3";

					if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

							, "row9", "tHashInput_2", "tHashInput_2", "tHashInput", "tMap_3", "tMap_3", "tMap"

					)) {
						talendJobLogProcess(globalMap);
					}

					if (log.isTraceEnabled()) {
						log.trace("row9 - " + (row9 == null ? "" : row9.toLogString()));
					}

					boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;

					row10Struct row10 = null;

					// ###############################
					// # Input tables (lookups)

					boolean rejectedInnerJoin_tMap_3 = false;
					boolean mainRowRejected_tMap_3 = false;

					///////////////////////////////////////////////
					// Starting Lookup Table "row10"
					///////////////////////////////////////////////

					boolean forceLooprow10 = false;

					row10Struct row10ObjectFromLookup = null;

					if (!rejectedInnerJoin_tMap_3) { // G_TM_M_020

						hasCasePrimitiveKeyWithNull_tMap_3 = false;

						row10HashKey.Violation_ID = row9.Violation_ID;

						row10HashKey.hashCodeDirty = true;

						tHash_Lookup_row10.lookup(row10HashKey);

						if (!tHash_Lookup_row10.hasNext()) { // G_TM_M_090

							rejectedInnerJoin_tMap_3 = true;

						} // G_TM_M_090

					} // G_TM_M_020

					if (tHash_Lookup_row10 != null && tHash_Lookup_row10.getCount(row10HashKey) > 1) { // G 071

						// System.out.println("WARNING: UNIQUE MATCH is configured for the lookup
						// 'row10' and it contains more one result from keys : row10.Violation_ID = '" +
						// row10HashKey.Violation_ID + "'");
					} // G 071

					row10Struct fromLookup_row10 = null;
					row10 = row10Default;

					if (tHash_Lookup_row10 != null && tHash_Lookup_row10.hasNext()) { // G 099

						fromLookup_row10 = tHash_Lookup_row10.next();

					} // G 099

					if (fromLookup_row10 != null) {
						row10 = fromLookup_row10;
					}

					// ###############################
					{ // start of Var scope

						// ###############################
						// # Vars tables

						Var__tMap_3__Struct Var = Var__tMap_3;
						Var.v_category = row9.ViolationDesc.toLowerCase().contains("major") ? "MAJOR"
								: (row9.ViolationDesc.toLowerCase().contains("minor") ? "MINOR" : "OTHER");// ###############################
						// ###############################
						// # Output tables

						ViolationCode_Desc = null;

						if (!rejectedInnerJoin_tMap_3) {

// # Output table : 'ViolationCode_Desc'
							count_ViolationCode_Desc_tMap_3++;

							ViolationCode_Desc_tmp.Violation_ID = row10.Violation_ID;
							ViolationCode_Desc_tmp.InspectionId = row10.InspectionId;
							ViolationCode_Desc_tmp.ViolationCodes = row10.ViolationCodes;
							ViolationCode_Desc_tmp.ViolationCategory = Var.v_category;
							ViolationCode_Desc_tmp.CodeScore = Var.v_category == "MAJOR" ? 10
									: (Var.v_category == "MINOR" ? 5 : 0);
							ViolationCode_Desc = ViolationCode_Desc_tmp;
							log.debug("tMap_3 - Outputting the record " + count_ViolationCode_Desc_tMap_3
									+ " of the output table 'ViolationCode_Desc'.");

						} // closing inner join bracket (2)
// ###############################

					} // end of Var scope

					rejectedInnerJoin_tMap_3 = false;

					tos_count_tMap_3++;

					/**
					 * [tMap_3 main ] stop
					 */

					/**
					 * [tMap_3 process_data_begin ] start
					 */

					currentComponent = "tMap_3";

					/**
					 * [tMap_3 process_data_begin ] stop
					 */
// Start of branch "ViolationCode_Desc"
					if (ViolationCode_Desc != null) {

						/**
						 * [tHashOutput_4 main ] start
						 */

						currentComponent = "tHashOutput_4";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "ViolationCode_Desc", "tMap_3", "tMap_3", "tMap", "tHashOutput_4", "tHashOutput_4",
								"tHashOutput"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("ViolationCode_Desc - "
									+ (ViolationCode_Desc == null ? "" : ViolationCode_Desc.toLogString()));
						}

						ViolationCode_DescStruct oneRow_tHashOutput_4 = new ViolationCode_DescStruct();

						oneRow_tHashOutput_4.Violation_ID = ViolationCode_Desc.Violation_ID;
						oneRow_tHashOutput_4.InspectionId = ViolationCode_Desc.InspectionId;
						oneRow_tHashOutput_4.ViolationCodes = ViolationCode_Desc.ViolationCodes;
						oneRow_tHashOutput_4.ViolationCategory = ViolationCode_Desc.ViolationCategory;
						oneRow_tHashOutput_4.CodeScore = ViolationCode_Desc.CodeScore;

						tHashFile_tHashOutput_4.put(oneRow_tHashOutput_4);
						nb_line_tHashOutput_4++;

						tos_count_tHashOutput_4++;

						/**
						 * [tHashOutput_4 main ] stop
						 */

						/**
						 * [tHashOutput_4 process_data_begin ] start
						 */

						currentComponent = "tHashOutput_4";

						/**
						 * [tHashOutput_4 process_data_begin ] stop
						 */

						/**
						 * [tHashOutput_4 process_data_end ] start
						 */

						currentComponent = "tHashOutput_4";

						/**
						 * [tHashOutput_4 process_data_end ] stop
						 */

					} // End of branch "ViolationCode_Desc"

					/**
					 * [tMap_3 process_data_end ] start
					 */

					currentComponent = "tMap_3";

					/**
					 * [tMap_3 process_data_end ] stop
					 */

					/**
					 * [tHashInput_2 process_data_end ] start
					 */

					currentComponent = "tHashInput_2";

					/**
					 * [tHashInput_2 process_data_end ] stop
					 */

					/**
					 * [tHashInput_2 end ] start
					 */

					currentComponent = "tHashInput_2";

					nb_line_tHashInput_2++;
				}

				mf_tHashInput_2.clearCache("tHashFile_DataPreparation_" + pid + "_tHashOutput_2");

				org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap
						.remove("tHashFile_DataPreparation_" + pid + "_tHashOutput_2");

				globalMap.put("tHashInput_2_NB_LINE", nb_line_tHashInput_2);

				ok_Hash.put("tHashInput_2", true);
				end_Hash.put("tHashInput_2", System.currentTimeMillis());

				/**
				 * [tHashInput_2 end ] stop
				 */

				/**
				 * [tMap_3 end ] start
				 */

				currentComponent = "tMap_3";

// ###############################
// # Lookup hashes releasing
				if (tHash_Lookup_row10 != null) {
					tHash_Lookup_row10.endGet();
				}
				globalMap.remove("tHash_Lookup_row10");

// ###############################      
				log.debug("tMap_3 - Written records count in the table 'ViolationCode_Desc': "
						+ count_ViolationCode_Desc_tMap_3 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row9", 2, 0,
						"tHashInput_2", "tHashInput_2", "tHashInput", "tMap_3", "tMap_3", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_3 - " + ("Done."));

				ok_Hash.put("tMap_3", true);
				end_Hash.put("tMap_3", System.currentTimeMillis());

				/**
				 * [tMap_3 end ] stop
				 */

				/**
				 * [tHashOutput_4 end ] start
				 */

				currentComponent = "tHashOutput_4";

				globalMap.put("tHashOutput_4_NB_LINE", nb_line_tHashOutput_4);
				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "ViolationCode_Desc", 2,
						0, "tMap_3", "tMap_3", "tMap", "tHashOutput_4", "tHashOutput_4", "tHashOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				ok_Hash.put("tHashOutput_4", true);
				end_Hash.put("tHashOutput_4", System.currentTimeMillis());

				/**
				 * [tHashOutput_4 end ] stop
				 */

			} // end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tHashInput_2:OnSubjobOk", "",
						Thread.currentThread().getId() + "", "", "", "", "", "");
			}

			if (execStat) {
				runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
			}

			tHashInput_3Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			// free memory for "tMap_3"
			globalMap.remove("tHash_Lookup_row10");

			try {

				/**
				 * [tHashInput_2 finally ] start
				 */

				currentComponent = "tHashInput_2";

				/**
				 * [tHashInput_2 finally ] stop
				 */

				/**
				 * [tMap_3 finally ] start
				 */

				currentComponent = "tMap_3";

				/**
				 * [tMap_3 finally ] stop
				 */

				/**
				 * [tHashOutput_4 finally ] start
				 */

				currentComponent = "tHashOutput_4";

				/**
				 * [tHashOutput_4 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tHashInput_2_SUBPROCESS_STATE", 1);
	}

	public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public Integer Business_ID_SK;

		public Integer getBusiness_ID_SK() {
			return this.Business_ID_SK;
		}

		public Boolean Business_ID_SKIsNullable() {
			return true;
		}

		public Boolean Business_ID_SKIsKey() {
			return false;
		}

		public Integer Business_ID_SKLength() {
			return null;
		}

		public Integer Business_ID_SKPrecision() {
			return null;
		}

		public String Business_ID_SKDefault() {

			return null;

		}

		public String Business_ID_SKComment() {

			return "";

		}

		public String Business_ID_SKPattern() {

			return "";

		}

		public String Business_ID_SKOriginalDbColumnName() {

			return "Business_ID_SK";

		}

		public String BusinessId;

		public String getBusinessId() {
			return this.BusinessId;
		}

		public Boolean BusinessIdIsNullable() {
			return true;
		}

		public Boolean BusinessIdIsKey() {
			return false;
		}

		public Integer BusinessIdLength() {
			return 9;
		}

		public Integer BusinessIdPrecision() {
			return null;
		}

		public String BusinessIdDefault() {

			return null;

		}

		public String BusinessIdComment() {

			return "";

		}

		public String BusinessIdPattern() {

			return "";

		}

		public String BusinessIdOriginalDbColumnName() {

			return "BusinessId";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 70;
		}

		public Integer NamePrecision() {
			return null;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public String PhoneNumber;

		public String getPhoneNumber() {
			return this.PhoneNumber;
		}

		public Boolean PhoneNumberIsNullable() {
			return true;
		}

		public Boolean PhoneNumberIsKey() {
			return false;
		}

		public Integer PhoneNumberLength() {
			return 13;
		}

		public Integer PhoneNumberPrecision() {
			return null;
		}

		public String PhoneNumberDefault() {

			return null;

		}

		public String PhoneNumberComment() {

			return "";

		}

		public String PhoneNumberPattern() {

			return "";

		}

		public String PhoneNumberOriginalDbColumnName() {

			return "PhoneNumber";

		}

		public java.util.Date DI_CreatedDate;

		public java.util.Date getDI_CreatedDate() {
			return this.DI_CreatedDate;
		}

		public Boolean DI_CreatedDateIsNullable() {
			return true;
		}

		public Boolean DI_CreatedDateIsKey() {
			return false;
		}

		public Integer DI_CreatedDateLength() {
			return 19;
		}

		public Integer DI_CreatedDatePrecision() {
			return null;
		}

		public String DI_CreatedDateDefault() {

			return null;

		}

		public String DI_CreatedDateComment() {

			return "";

		}

		public String DI_CreatedDatePattern() {

			return "dd-MM-yyyy";

		}

		public String DI_CreatedDateOriginalDbColumnName() {

			return "DI_CreatedDate";

		}

		public String DI_WorkflowFileName;

		public String getDI_WorkflowFileName() {
			return this.DI_WorkflowFileName;
		}

		public Boolean DI_WorkflowFileNameIsNullable() {
			return true;
		}

		public Boolean DI_WorkflowFileNameIsKey() {
			return false;
		}

		public Integer DI_WorkflowFileNameLength() {
			return 255;
		}

		public Integer DI_WorkflowFileNamePrecision() {
			return null;
		}

		public String DI_WorkflowFileNameDefault() {

			return null;

		}

		public String DI_WorkflowFileNameComment() {

			return "";

		}

		public String DI_WorkflowFileNamePattern() {

			return "";

		}

		public String DI_WorkflowFileNameOriginalDbColumnName() {

			return "DI_WorkflowFileName";

		}

		public String DI_Workflow_ProcessID;

		public String getDI_Workflow_ProcessID() {
			return this.DI_Workflow_ProcessID;
		}

		public Boolean DI_Workflow_ProcessIDIsNullable() {
			return true;
		}

		public Boolean DI_Workflow_ProcessIDIsKey() {
			return false;
		}

		public Integer DI_Workflow_ProcessIDLength() {
			return 30;
		}

		public Integer DI_Workflow_ProcessIDPrecision() {
			return null;
		}

		public String DI_Workflow_ProcessIDDefault() {

			return null;

		}

		public String DI_Workflow_ProcessIDComment() {

			return "";

		}

		public String DI_Workflow_ProcessIDPattern() {

			return "";

		}

		public String DI_Workflow_ProcessIDOriginalDbColumnName() {

			return "DI_Workflow_ProcessID";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Business_ID_SK = readInteger(dis);

					this.BusinessId = readString(dis);

					this.Name = readString(dis);

					this.PhoneNumber = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Business_ID_SK = readInteger(dis);

					this.BusinessId = readString(dis);

					this.Name = readString(dis);

					this.PhoneNumber = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.Business_ID_SK, dos);

				// String

				writeString(this.BusinessId, dos);

				// String

				writeString(this.Name, dos);

				// String

				writeString(this.PhoneNumber, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.Business_ID_SK, dos);

				// String

				writeString(this.BusinessId, dos);

				// String

				writeString(this.Name, dos);

				// String

				writeString(this.PhoneNumber, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Business_ID_SK=" + String.valueOf(Business_ID_SK));
			sb.append(",BusinessId=" + BusinessId);
			sb.append(",Name=" + Name);
			sb.append(",PhoneNumber=" + PhoneNumber);
			sb.append(",DI_CreatedDate=" + String.valueOf(DI_CreatedDate));
			sb.append(",DI_WorkflowFileName=" + DI_WorkflowFileName);
			sb.append(",DI_Workflow_ProcessID=" + DI_Workflow_ProcessID);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (Business_ID_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Business_ID_SK);
			}

			sb.append("|");

			if (BusinessId == null) {
				sb.append("<null>");
			} else {
				sb.append(BusinessId);
			}

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (PhoneNumber == null) {
				sb.append("<null>");
			} else {
				sb.append(PhoneNumber);
			}

			sb.append("|");

			if (DI_CreatedDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreatedDate);
			}

			sb.append("|");

			if (DI_WorkflowFileName == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_WorkflowFileName);
			}

			sb.append("|");

			if (DI_Workflow_ProcessID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Workflow_ProcessID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row5Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row14Struct implements routines.system.IPersistableRow<row14Struct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public Integer Violation_ID;

		public Integer getViolation_ID() {
			return this.Violation_ID;
		}

		public Boolean Violation_IDIsNullable() {
			return true;
		}

		public Boolean Violation_IDIsKey() {
			return false;
		}

		public Integer Violation_IDLength() {
			return null;
		}

		public Integer Violation_IDPrecision() {
			return null;
		}

		public String Violation_IDDefault() {

			return null;

		}

		public String Violation_IDComment() {

			return "";

		}

		public String Violation_IDPattern() {

			return "";

		}

		public String Violation_IDOriginalDbColumnName() {

			return "Violation_ID";

		}

		public String Violation_Code;

		public String getViolation_Code() {
			return this.Violation_Code;
		}

		public Boolean Violation_CodeIsNullable() {
			return true;
		}

		public Boolean Violation_CodeIsKey() {
			return false;
		}

		public Integer Violation_CodeLength() {
			return null;
		}

		public Integer Violation_CodePrecision() {
			return null;
		}

		public String Violation_CodeDefault() {

			return null;

		}

		public String Violation_CodeComment() {

			return "";

		}

		public String Violation_CodePattern() {

			return "";

		}

		public String Violation_CodeOriginalDbColumnName() {

			return "Violation_Code";

		}

		public Integer Code_Score;

		public Integer getCode_Score() {
			return this.Code_Score;
		}

		public Boolean Code_ScoreIsNullable() {
			return true;
		}

		public Boolean Code_ScoreIsKey() {
			return false;
		}

		public Integer Code_ScoreLength() {
			return null;
		}

		public Integer Code_ScorePrecision() {
			return null;
		}

		public String Code_ScoreDefault() {

			return null;

		}

		public String Code_ScoreComment() {

			return "";

		}

		public String Code_ScorePattern() {

			return "";

		}

		public String Code_ScoreOriginalDbColumnName() {

			return "Code_Score";

		}

		public String Violation_Category;

		public String getViolation_Category() {
			return this.Violation_Category;
		}

		public Boolean Violation_CategoryIsNullable() {
			return true;
		}

		public Boolean Violation_CategoryIsKey() {
			return false;
		}

		public Integer Violation_CategoryLength() {
			return null;
		}

		public Integer Violation_CategoryPrecision() {
			return null;
		}

		public String Violation_CategoryDefault() {

			return null;

		}

		public String Violation_CategoryComment() {

			return "";

		}

		public String Violation_CategoryPattern() {

			return "";

		}

		public String Violation_CategoryOriginalDbColumnName() {

			return "Violation_Category";

		}

		public java.util.Date DI_CreatedDate;

		public java.util.Date getDI_CreatedDate() {
			return this.DI_CreatedDate;
		}

		public Boolean DI_CreatedDateIsNullable() {
			return true;
		}

		public Boolean DI_CreatedDateIsKey() {
			return false;
		}

		public Integer DI_CreatedDateLength() {
			return 19;
		}

		public Integer DI_CreatedDatePrecision() {
			return 0;
		}

		public String DI_CreatedDateDefault() {

			return null;

		}

		public String DI_CreatedDateComment() {

			return "";

		}

		public String DI_CreatedDatePattern() {

			return "dd-MM-yyyy";

		}

		public String DI_CreatedDateOriginalDbColumnName() {

			return "DI_CreatedDate";

		}

		public String DI_WorkflowFileName;

		public String getDI_WorkflowFileName() {
			return this.DI_WorkflowFileName;
		}

		public Boolean DI_WorkflowFileNameIsNullable() {
			return true;
		}

		public Boolean DI_WorkflowFileNameIsKey() {
			return false;
		}

		public Integer DI_WorkflowFileNameLength() {
			return 255;
		}

		public Integer DI_WorkflowFileNamePrecision() {
			return 0;
		}

		public String DI_WorkflowFileNameDefault() {

			return null;

		}

		public String DI_WorkflowFileNameComment() {

			return "";

		}

		public String DI_WorkflowFileNamePattern() {

			return "";

		}

		public String DI_WorkflowFileNameOriginalDbColumnName() {

			return "DI_WorkflowFileName";

		}

		public String DI_Workflow_ProcessID;

		public String getDI_Workflow_ProcessID() {
			return this.DI_Workflow_ProcessID;
		}

		public Boolean DI_Workflow_ProcessIDIsNullable() {
			return true;
		}

		public Boolean DI_Workflow_ProcessIDIsKey() {
			return false;
		}

		public Integer DI_Workflow_ProcessIDLength() {
			return 30;
		}

		public Integer DI_Workflow_ProcessIDPrecision() {
			return 0;
		}

		public String DI_Workflow_ProcessIDDefault() {

			return null;

		}

		public String DI_Workflow_ProcessIDComment() {

			return "";

		}

		public String DI_Workflow_ProcessIDPattern() {

			return "";

		}

		public String DI_Workflow_ProcessIDOriginalDbColumnName() {

			return "DI_Workflow_ProcessID";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Violation_ID = readInteger(dis);

					this.Violation_Code = readString(dis);

					this.Code_Score = readInteger(dis);

					this.Violation_Category = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Violation_ID = readInteger(dis);

					this.Violation_Code = readString(dis);

					this.Code_Score = readInteger(dis);

					this.Violation_Category = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.Violation_ID, dos);

				// String

				writeString(this.Violation_Code, dos);

				// Integer

				writeInteger(this.Code_Score, dos);

				// String

				writeString(this.Violation_Category, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.Violation_ID, dos);

				// String

				writeString(this.Violation_Code, dos);

				// Integer

				writeInteger(this.Code_Score, dos);

				// String

				writeString(this.Violation_Category, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Violation_ID=" + String.valueOf(Violation_ID));
			sb.append(",Violation_Code=" + Violation_Code);
			sb.append(",Code_Score=" + String.valueOf(Code_Score));
			sb.append(",Violation_Category=" + Violation_Category);
			sb.append(",DI_CreatedDate=" + String.valueOf(DI_CreatedDate));
			sb.append(",DI_WorkflowFileName=" + DI_WorkflowFileName);
			sb.append(",DI_Workflow_ProcessID=" + DI_Workflow_ProcessID);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (Violation_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(Violation_ID);
			}

			sb.append("|");

			if (Violation_Code == null) {
				sb.append("<null>");
			} else {
				sb.append(Violation_Code);
			}

			sb.append("|");

			if (Code_Score == null) {
				sb.append("<null>");
			} else {
				sb.append(Code_Score);
			}

			sb.append("|");

			if (Violation_Category == null) {
				sb.append("<null>");
			} else {
				sb.append(Violation_Category);
			}

			sb.append("|");

			if (DI_CreatedDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreatedDate);
			}

			sb.append("|");

			if (DI_WorkflowFileName == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_WorkflowFileName);
			}

			sb.append("|");

			if (DI_Workflow_ProcessID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Workflow_ProcessID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row14Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public Integer Location_SK;

		public Integer getLocation_SK() {
			return this.Location_SK;
		}

		public Boolean Location_SKIsNullable() {
			return true;
		}

		public Boolean Location_SKIsKey() {
			return false;
		}

		public Integer Location_SKLength() {
			return null;
		}

		public Integer Location_SKPrecision() {
			return null;
		}

		public String Location_SKDefault() {

			return null;

		}

		public String Location_SKComment() {

			return "";

		}

		public String Location_SKPattern() {

			return "";

		}

		public String Location_SKOriginalDbColumnName() {

			return "Location_SK";

		}

		public String Address;

		public String getAddress() {
			return this.Address;
		}

		public Boolean AddressIsNullable() {
			return true;
		}

		public Boolean AddressIsKey() {
			return false;
		}

		public Integer AddressLength() {
			return 40;
		}

		public Integer AddressPrecision() {
			return null;
		}

		public String AddressDefault() {

			return null;

		}

		public String AddressComment() {

			return "";

		}

		public String AddressPattern() {

			return "";

		}

		public String AddressOriginalDbColumnName() {

			return "Address";

		}

		public String ZipCode;

		public String getZipCode() {
			return this.ZipCode;
		}

		public Boolean ZipCodeIsNullable() {
			return true;
		}

		public Boolean ZipCodeIsKey() {
			return false;
		}

		public Integer ZipCodeLength() {
			return 10;
		}

		public Integer ZipCodePrecision() {
			return null;
		}

		public String ZipCodeDefault() {

			return null;

		}

		public String ZipCodeComment() {

			return "";

		}

		public String ZipCodePattern() {

			return "";

		}

		public String ZipCodeOriginalDbColumnName() {

			return "ZipCode";

		}

		public String State;

		public String getState() {
			return this.State;
		}

		public Boolean StateIsNullable() {
			return true;
		}

		public Boolean StateIsKey() {
			return false;
		}

		public Integer StateLength() {
			return 2;
		}

		public Integer StatePrecision() {
			return null;
		}

		public String StateDefault() {

			return null;

		}

		public String StateComment() {

			return "";

		}

		public String StatePattern() {

			return "";

		}

		public String StateOriginalDbColumnName() {

			return "State";

		}

		public String City;

		public String getCity() {
			return this.City;
		}

		public Boolean CityIsNullable() {
			return true;
		}

		public Boolean CityIsKey() {
			return false;
		}

		public Integer CityLength() {
			return 20;
		}

		public Integer CityPrecision() {
			return null;
		}

		public String CityDefault() {

			return null;

		}

		public String CityComment() {

			return "";

		}

		public String CityPattern() {

			return "";

		}

		public String CityOriginalDbColumnName() {

			return "City";

		}

		public String Location;

		public String getLocation() {
			return this.Location;
		}

		public Boolean LocationIsNullable() {
			return true;
		}

		public Boolean LocationIsKey() {
			return false;
		}

		public Integer LocationLength() {
			return 100;
		}

		public Integer LocationPrecision() {
			return null;
		}

		public String LocationDefault() {

			return null;

		}

		public String LocationComment() {

			return "";

		}

		public String LocationPattern() {

			return "";

		}

		public String LocationOriginalDbColumnName() {

			return "Location";

		}

		public Double Latitude;

		public Double getLatitude() {
			return this.Latitude;
		}

		public Boolean LatitudeIsNullable() {
			return true;
		}

		public Boolean LatitudeIsKey() {
			return false;
		}

		public Integer LatitudeLength() {
			return null;
		}

		public Integer LatitudePrecision() {
			return null;
		}

		public String LatitudeDefault() {

			return null;

		}

		public String LatitudeComment() {

			return "";

		}

		public String LatitudePattern() {

			return "";

		}

		public String LatitudeOriginalDbColumnName() {

			return "Latitude";

		}

		public Double Longitude;

		public Double getLongitude() {
			return this.Longitude;
		}

		public Boolean LongitudeIsNullable() {
			return true;
		}

		public Boolean LongitudeIsKey() {
			return false;
		}

		public Integer LongitudeLength() {
			return null;
		}

		public Integer LongitudePrecision() {
			return null;
		}

		public String LongitudeDefault() {

			return null;

		}

		public String LongitudeComment() {

			return "";

		}

		public String LongitudePattern() {

			return "";

		}

		public String LongitudeOriginalDbColumnName() {

			return "Longitude";

		}

		public java.util.Date DI_CreatedDate;

		public java.util.Date getDI_CreatedDate() {
			return this.DI_CreatedDate;
		}

		public Boolean DI_CreatedDateIsNullable() {
			return true;
		}

		public Boolean DI_CreatedDateIsKey() {
			return false;
		}

		public Integer DI_CreatedDateLength() {
			return 19;
		}

		public Integer DI_CreatedDatePrecision() {
			return 0;
		}

		public String DI_CreatedDateDefault() {

			return null;

		}

		public String DI_CreatedDateComment() {

			return "";

		}

		public String DI_CreatedDatePattern() {

			return "dd-MM-yyyy";

		}

		public String DI_CreatedDateOriginalDbColumnName() {

			return "DI_CreatedDate";

		}

		public String DI_WorkflowFileName;

		public String getDI_WorkflowFileName() {
			return this.DI_WorkflowFileName;
		}

		public Boolean DI_WorkflowFileNameIsNullable() {
			return true;
		}

		public Boolean DI_WorkflowFileNameIsKey() {
			return false;
		}

		public Integer DI_WorkflowFileNameLength() {
			return 255;
		}

		public Integer DI_WorkflowFileNamePrecision() {
			return 0;
		}

		public String DI_WorkflowFileNameDefault() {

			return null;

		}

		public String DI_WorkflowFileNameComment() {

			return "";

		}

		public String DI_WorkflowFileNamePattern() {

			return "";

		}

		public String DI_WorkflowFileNameOriginalDbColumnName() {

			return "DI_WorkflowFileName";

		}

		public String DI_Workflow_ProcessID;

		public String getDI_Workflow_ProcessID() {
			return this.DI_Workflow_ProcessID;
		}

		public Boolean DI_Workflow_ProcessIDIsNullable() {
			return true;
		}

		public Boolean DI_Workflow_ProcessIDIsKey() {
			return false;
		}

		public Integer DI_Workflow_ProcessIDLength() {
			return 30;
		}

		public Integer DI_Workflow_ProcessIDPrecision() {
			return 0;
		}

		public String DI_Workflow_ProcessIDDefault() {

			return null;

		}

		public String DI_Workflow_ProcessIDComment() {

			return "";

		}

		public String DI_Workflow_ProcessIDPattern() {

			return "";

		}

		public String DI_Workflow_ProcessIDOriginalDbColumnName() {

			return "DI_Workflow_ProcessID";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Location_SK = readInteger(dis);

					this.Address = readString(dis);

					this.ZipCode = readString(dis);

					this.State = readString(dis);

					this.City = readString(dis);

					this.Location = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Latitude = null;
					} else {
						this.Latitude = dis.readDouble();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Longitude = null;
					} else {
						this.Longitude = dis.readDouble();
					}

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Location_SK = readInteger(dis);

					this.Address = readString(dis);

					this.ZipCode = readString(dis);

					this.State = readString(dis);

					this.City = readString(dis);

					this.Location = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Latitude = null;
					} else {
						this.Latitude = dis.readDouble();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Longitude = null;
					} else {
						this.Longitude = dis.readDouble();
					}

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.Location_SK, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.ZipCode, dos);

				// String

				writeString(this.State, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.Location, dos);

				// Double

				if (this.Latitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.Latitude);
				}

				// Double

				if (this.Longitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.Longitude);
				}

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.Location_SK, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.ZipCode, dos);

				// String

				writeString(this.State, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.Location, dos);

				// Double

				if (this.Latitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.Latitude);
				}

				// Double

				if (this.Longitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.Longitude);
				}

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Location_SK=" + String.valueOf(Location_SK));
			sb.append(",Address=" + Address);
			sb.append(",ZipCode=" + ZipCode);
			sb.append(",State=" + State);
			sb.append(",City=" + City);
			sb.append(",Location=" + Location);
			sb.append(",Latitude=" + String.valueOf(Latitude));
			sb.append(",Longitude=" + String.valueOf(Longitude));
			sb.append(",DI_CreatedDate=" + String.valueOf(DI_CreatedDate));
			sb.append(",DI_WorkflowFileName=" + DI_WorkflowFileName);
			sb.append(",DI_Workflow_ProcessID=" + DI_Workflow_ProcessID);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (Location_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Location_SK);
			}

			sb.append("|");

			if (Address == null) {
				sb.append("<null>");
			} else {
				sb.append(Address);
			}

			sb.append("|");

			if (ZipCode == null) {
				sb.append("<null>");
			} else {
				sb.append(ZipCode);
			}

			sb.append("|");

			if (State == null) {
				sb.append("<null>");
			} else {
				sb.append(State);
			}

			sb.append("|");

			if (City == null) {
				sb.append("<null>");
			} else {
				sb.append(City);
			}

			sb.append("|");

			if (Location == null) {
				sb.append("<null>");
			} else {
				sb.append(Location);
			}

			sb.append("|");

			if (Latitude == null) {
				sb.append("<null>");
			} else {
				sb.append(Latitude);
			}

			sb.append("|");

			if (Longitude == null) {
				sb.append("<null>");
			} else {
				sb.append(Longitude);
			}

			sb.append("|");

			if (DI_CreatedDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreatedDate);
			}

			sb.append("|");

			if (DI_WorkflowFileName == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_WorkflowFileName);
			}

			sb.append("|");

			if (DI_Workflow_ProcessID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Workflow_ProcessID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row6Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public Integer InspectionType_ID;

		public Integer getInspectionType_ID() {
			return this.InspectionType_ID;
		}

		public Boolean InspectionType_IDIsNullable() {
			return true;
		}

		public Boolean InspectionType_IDIsKey() {
			return false;
		}

		public Integer InspectionType_IDLength() {
			return null;
		}

		public Integer InspectionType_IDPrecision() {
			return null;
		}

		public String InspectionType_IDDefault() {

			return null;

		}

		public String InspectionType_IDComment() {

			return "";

		}

		public String InspectionType_IDPattern() {

			return "";

		}

		public String InspectionType_IDOriginalDbColumnName() {

			return "InspectionType_ID";

		}

		public String InspectionType;

		public String getInspectionType() {
			return this.InspectionType;
		}

		public Boolean InspectionTypeIsNullable() {
			return true;
		}

		public Boolean InspectionTypeIsKey() {
			return false;
		}

		public Integer InspectionTypeLength() {
			return 9;
		}

		public Integer InspectionTypePrecision() {
			return null;
		}

		public String InspectionTypeDefault() {

			return null;

		}

		public String InspectionTypeComment() {

			return "";

		}

		public String InspectionTypePattern() {

			return "";

		}

		public String InspectionTypeOriginalDbColumnName() {

			return "InspectionType";

		}

		public java.util.Date DI_CreatedDate;

		public java.util.Date getDI_CreatedDate() {
			return this.DI_CreatedDate;
		}

		public Boolean DI_CreatedDateIsNullable() {
			return true;
		}

		public Boolean DI_CreatedDateIsKey() {
			return false;
		}

		public Integer DI_CreatedDateLength() {
			return 19;
		}

		public Integer DI_CreatedDatePrecision() {
			return 0;
		}

		public String DI_CreatedDateDefault() {

			return null;

		}

		public String DI_CreatedDateComment() {

			return "";

		}

		public String DI_CreatedDatePattern() {

			return "dd-MM-yyyy";

		}

		public String DI_CreatedDateOriginalDbColumnName() {

			return "DI_CreatedDate";

		}

		public String DI_WorkflowFileName;

		public String getDI_WorkflowFileName() {
			return this.DI_WorkflowFileName;
		}

		public Boolean DI_WorkflowFileNameIsNullable() {
			return true;
		}

		public Boolean DI_WorkflowFileNameIsKey() {
			return false;
		}

		public Integer DI_WorkflowFileNameLength() {
			return 255;
		}

		public Integer DI_WorkflowFileNamePrecision() {
			return 0;
		}

		public String DI_WorkflowFileNameDefault() {

			return null;

		}

		public String DI_WorkflowFileNameComment() {

			return "";

		}

		public String DI_WorkflowFileNamePattern() {

			return "";

		}

		public String DI_WorkflowFileNameOriginalDbColumnName() {

			return "DI_WorkflowFileName";

		}

		public String DI_Workflow_ProcessID;

		public String getDI_Workflow_ProcessID() {
			return this.DI_Workflow_ProcessID;
		}

		public Boolean DI_Workflow_ProcessIDIsNullable() {
			return true;
		}

		public Boolean DI_Workflow_ProcessIDIsKey() {
			return false;
		}

		public Integer DI_Workflow_ProcessIDLength() {
			return 30;
		}

		public Integer DI_Workflow_ProcessIDPrecision() {
			return 0;
		}

		public String DI_Workflow_ProcessIDDefault() {

			return null;

		}

		public String DI_Workflow_ProcessIDComment() {

			return "";

		}

		public String DI_Workflow_ProcessIDPattern() {

			return "";

		}

		public String DI_Workflow_ProcessIDOriginalDbColumnName() {

			return "DI_Workflow_ProcessID";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.InspectionType_ID = readInteger(dis);

					this.InspectionType = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.InspectionType_ID = readInteger(dis);

					this.InspectionType = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.InspectionType_ID, dos);

				// String

				writeString(this.InspectionType, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.InspectionType_ID, dos);

				// String

				writeString(this.InspectionType, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("InspectionType_ID=" + String.valueOf(InspectionType_ID));
			sb.append(",InspectionType=" + InspectionType);
			sb.append(",DI_CreatedDate=" + String.valueOf(DI_CreatedDate));
			sb.append(",DI_WorkflowFileName=" + DI_WorkflowFileName);
			sb.append(",DI_Workflow_ProcessID=" + DI_Workflow_ProcessID);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (InspectionType_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionType_ID);
			}

			sb.append("|");

			if (InspectionType == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionType);
			}

			sb.append("|");

			if (DI_CreatedDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreatedDate);
			}

			sb.append("|");

			if (DI_WorkflowFileName == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_WorkflowFileName);
			}

			sb.append("|");

			if (DI_Workflow_ProcessID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Workflow_ProcessID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row7Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public String Date_SK;

		public String getDate_SK() {
			return this.Date_SK;
		}

		public Boolean Date_SKIsNullable() {
			return true;
		}

		public Boolean Date_SKIsKey() {
			return false;
		}

		public Integer Date_SKLength() {
			return 8;
		}

		public Integer Date_SKPrecision() {
			return null;
		}

		public String Date_SKDefault() {

			return null;

		}

		public String Date_SKComment() {

			return "";

		}

		public String Date_SKPattern() {

			return "";

		}

		public String Date_SKOriginalDbColumnName() {

			return "Date_SK";

		}

		public Integer Year;

		public Integer getYear() {
			return this.Year;
		}

		public Boolean YearIsNullable() {
			return true;
		}

		public Boolean YearIsKey() {
			return false;
		}

		public Integer YearLength() {
			return null;
		}

		public Integer YearPrecision() {
			return null;
		}

		public String YearDefault() {

			return null;

		}

		public String YearComment() {

			return "";

		}

		public String YearPattern() {

			return "";

		}

		public String YearOriginalDbColumnName() {

			return "Year";

		}

		public Integer Day;

		public Integer getDay() {
			return this.Day;
		}

		public Boolean DayIsNullable() {
			return true;
		}

		public Boolean DayIsKey() {
			return false;
		}

		public Integer DayLength() {
			return null;
		}

		public Integer DayPrecision() {
			return null;
		}

		public String DayDefault() {

			return null;

		}

		public String DayComment() {

			return "";

		}

		public String DayPattern() {

			return "";

		}

		public String DayOriginalDbColumnName() {

			return "Day";

		}

		public String Day_Of_Week;

		public String getDay_Of_Week() {
			return this.Day_Of_Week;
		}

		public Boolean Day_Of_WeekIsNullable() {
			return true;
		}

		public Boolean Day_Of_WeekIsKey() {
			return false;
		}

		public Integer Day_Of_WeekLength() {
			return 10;
		}

		public Integer Day_Of_WeekPrecision() {
			return null;
		}

		public String Day_Of_WeekDefault() {

			return null;

		}

		public String Day_Of_WeekComment() {

			return "";

		}

		public String Day_Of_WeekPattern() {

			return "";

		}

		public String Day_Of_WeekOriginalDbColumnName() {

			return "Day_Of_Week";

		}

		public Integer Month;

		public Integer getMonth() {
			return this.Month;
		}

		public Boolean MonthIsNullable() {
			return true;
		}

		public Boolean MonthIsKey() {
			return false;
		}

		public Integer MonthLength() {
			return null;
		}

		public Integer MonthPrecision() {
			return null;
		}

		public String MonthDefault() {

			return null;

		}

		public String MonthComment() {

			return "";

		}

		public String MonthPattern() {

			return "";

		}

		public String MonthOriginalDbColumnName() {

			return "Month";

		}

		public java.util.Date Date;

		public java.util.Date getDate() {
			return this.Date;
		}

		public Boolean DateIsNullable() {
			return true;
		}

		public Boolean DateIsKey() {
			return false;
		}

		public Integer DateLength() {
			return null;
		}

		public Integer DatePrecision() {
			return null;
		}

		public String DateDefault() {

			return null;

		}

		public String DateComment() {

			return "";

		}

		public String DatePattern() {

			return "dd-MM-yyyy";

		}

		public String DateOriginalDbColumnName() {

			return "Date";

		}

		public java.util.Date DI_CreatedDate;

		public java.util.Date getDI_CreatedDate() {
			return this.DI_CreatedDate;
		}

		public Boolean DI_CreatedDateIsNullable() {
			return true;
		}

		public Boolean DI_CreatedDateIsKey() {
			return false;
		}

		public Integer DI_CreatedDateLength() {
			return 19;
		}

		public Integer DI_CreatedDatePrecision() {
			return 0;
		}

		public String DI_CreatedDateDefault() {

			return null;

		}

		public String DI_CreatedDateComment() {

			return "";

		}

		public String DI_CreatedDatePattern() {

			return "dd-MM-yyyy";

		}

		public String DI_CreatedDateOriginalDbColumnName() {

			return "DI_CreatedDate";

		}

		public String DI_WorkflowFileName;

		public String getDI_WorkflowFileName() {
			return this.DI_WorkflowFileName;
		}

		public Boolean DI_WorkflowFileNameIsNullable() {
			return true;
		}

		public Boolean DI_WorkflowFileNameIsKey() {
			return false;
		}

		public Integer DI_WorkflowFileNameLength() {
			return 255;
		}

		public Integer DI_WorkflowFileNamePrecision() {
			return 0;
		}

		public String DI_WorkflowFileNameDefault() {

			return null;

		}

		public String DI_WorkflowFileNameComment() {

			return "";

		}

		public String DI_WorkflowFileNamePattern() {

			return "";

		}

		public String DI_WorkflowFileNameOriginalDbColumnName() {

			return "DI_WorkflowFileName";

		}

		public String DI_Workflow_ProcessID;

		public String getDI_Workflow_ProcessID() {
			return this.DI_Workflow_ProcessID;
		}

		public Boolean DI_Workflow_ProcessIDIsNullable() {
			return true;
		}

		public Boolean DI_Workflow_ProcessIDIsKey() {
			return false;
		}

		public Integer DI_Workflow_ProcessIDLength() {
			return 30;
		}

		public Integer DI_Workflow_ProcessIDPrecision() {
			return 0;
		}

		public String DI_Workflow_ProcessIDDefault() {

			return null;

		}

		public String DI_Workflow_ProcessIDComment() {

			return "";

		}

		public String DI_Workflow_ProcessIDPattern() {

			return "";

		}

		public String DI_Workflow_ProcessIDOriginalDbColumnName() {

			return "DI_Workflow_ProcessID";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Date_SK = readString(dis);

					this.Year = readInteger(dis);

					this.Day = readInteger(dis);

					this.Day_Of_Week = readString(dis);

					this.Month = readInteger(dis);

					this.Date = readDate(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Date_SK = readString(dis);

					this.Year = readInteger(dis);

					this.Day = readInteger(dis);

					this.Day_Of_Week = readString(dis);

					this.Month = readInteger(dis);

					this.Date = readDate(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.Date_SK, dos);

				// Integer

				writeInteger(this.Year, dos);

				// Integer

				writeInteger(this.Day, dos);

				// String

				writeString(this.Day_Of_Week, dos);

				// Integer

				writeInteger(this.Month, dos);

				// java.util.Date

				writeDate(this.Date, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.Date_SK, dos);

				// Integer

				writeInteger(this.Year, dos);

				// Integer

				writeInteger(this.Day, dos);

				// String

				writeString(this.Day_Of_Week, dos);

				// Integer

				writeInteger(this.Month, dos);

				// java.util.Date

				writeDate(this.Date, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Date_SK=" + Date_SK);
			sb.append(",Year=" + String.valueOf(Year));
			sb.append(",Day=" + String.valueOf(Day));
			sb.append(",Day_Of_Week=" + Day_Of_Week);
			sb.append(",Month=" + String.valueOf(Month));
			sb.append(",Date=" + String.valueOf(Date));
			sb.append(",DI_CreatedDate=" + String.valueOf(DI_CreatedDate));
			sb.append(",DI_WorkflowFileName=" + DI_WorkflowFileName);
			sb.append(",DI_Workflow_ProcessID=" + DI_Workflow_ProcessID);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (Date_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Date_SK);
			}

			sb.append("|");

			if (Year == null) {
				sb.append("<null>");
			} else {
				sb.append(Year);
			}

			sb.append("|");

			if (Day == null) {
				sb.append("<null>");
			} else {
				sb.append(Day);
			}

			sb.append("|");

			if (Day_Of_Week == null) {
				sb.append("<null>");
			} else {
				sb.append(Day_Of_Week);
			}

			sb.append("|");

			if (Month == null) {
				sb.append("<null>");
			} else {
				sb.append(Month);
			}

			sb.append("|");

			if (Date == null) {
				sb.append("<null>");
			} else {
				sb.append(Date);
			}

			sb.append("|");

			if (DI_CreatedDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreatedDate);
			}

			sb.append("|");

			if (DI_WorkflowFileName == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_WorkflowFileName);
			}

			sb.append("|");

			if (DI_Workflow_ProcessID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Workflow_ProcessID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row8Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class DimDateStruct implements routines.system.IPersistableRow<DimDateStruct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public String Date_SK;

		public String getDate_SK() {
			return this.Date_SK;
		}

		public Boolean Date_SKIsNullable() {
			return true;
		}

		public Boolean Date_SKIsKey() {
			return false;
		}

		public Integer Date_SKLength() {
			return 8;
		}

		public Integer Date_SKPrecision() {
			return null;
		}

		public String Date_SKDefault() {

			return null;

		}

		public String Date_SKComment() {

			return "";

		}

		public String Date_SKPattern() {

			return "";

		}

		public String Date_SKOriginalDbColumnName() {

			return "Date_SK";

		}

		public Integer Year;

		public Integer getYear() {
			return this.Year;
		}

		public Boolean YearIsNullable() {
			return true;
		}

		public Boolean YearIsKey() {
			return false;
		}

		public Integer YearLength() {
			return null;
		}

		public Integer YearPrecision() {
			return null;
		}

		public String YearDefault() {

			return null;

		}

		public String YearComment() {

			return "";

		}

		public String YearPattern() {

			return "";

		}

		public String YearOriginalDbColumnName() {

			return "Year";

		}

		public Integer Day;

		public Integer getDay() {
			return this.Day;
		}

		public Boolean DayIsNullable() {
			return true;
		}

		public Boolean DayIsKey() {
			return false;
		}

		public Integer DayLength() {
			return null;
		}

		public Integer DayPrecision() {
			return null;
		}

		public String DayDefault() {

			return null;

		}

		public String DayComment() {

			return "";

		}

		public String DayPattern() {

			return "";

		}

		public String DayOriginalDbColumnName() {

			return "Day";

		}

		public String Day_Of_Week;

		public String getDay_Of_Week() {
			return this.Day_Of_Week;
		}

		public Boolean Day_Of_WeekIsNullable() {
			return true;
		}

		public Boolean Day_Of_WeekIsKey() {
			return false;
		}

		public Integer Day_Of_WeekLength() {
			return 10;
		}

		public Integer Day_Of_WeekPrecision() {
			return null;
		}

		public String Day_Of_WeekDefault() {

			return null;

		}

		public String Day_Of_WeekComment() {

			return "";

		}

		public String Day_Of_WeekPattern() {

			return "";

		}

		public String Day_Of_WeekOriginalDbColumnName() {

			return "Day_Of_Week";

		}

		public Integer Month;

		public Integer getMonth() {
			return this.Month;
		}

		public Boolean MonthIsNullable() {
			return true;
		}

		public Boolean MonthIsKey() {
			return false;
		}

		public Integer MonthLength() {
			return null;
		}

		public Integer MonthPrecision() {
			return null;
		}

		public String MonthDefault() {

			return null;

		}

		public String MonthComment() {

			return "";

		}

		public String MonthPattern() {

			return "";

		}

		public String MonthOriginalDbColumnName() {

			return "Month";

		}

		public java.util.Date Date;

		public java.util.Date getDate() {
			return this.Date;
		}

		public Boolean DateIsNullable() {
			return true;
		}

		public Boolean DateIsKey() {
			return false;
		}

		public Integer DateLength() {
			return null;
		}

		public Integer DatePrecision() {
			return null;
		}

		public String DateDefault() {

			return null;

		}

		public String DateComment() {

			return "";

		}

		public String DatePattern() {

			return "dd-MM-yyyy";

		}

		public String DateOriginalDbColumnName() {

			return "Date";

		}

		public java.util.Date DI_CreatedDate;

		public java.util.Date getDI_CreatedDate() {
			return this.DI_CreatedDate;
		}

		public Boolean DI_CreatedDateIsNullable() {
			return true;
		}

		public Boolean DI_CreatedDateIsKey() {
			return false;
		}

		public Integer DI_CreatedDateLength() {
			return 19;
		}

		public Integer DI_CreatedDatePrecision() {
			return 0;
		}

		public String DI_CreatedDateDefault() {

			return null;

		}

		public String DI_CreatedDateComment() {

			return "";

		}

		public String DI_CreatedDatePattern() {

			return "dd-MM-yyyy";

		}

		public String DI_CreatedDateOriginalDbColumnName() {

			return "DI_CreatedDate";

		}

		public String DI_WorkflowFileName;

		public String getDI_WorkflowFileName() {
			return this.DI_WorkflowFileName;
		}

		public Boolean DI_WorkflowFileNameIsNullable() {
			return true;
		}

		public Boolean DI_WorkflowFileNameIsKey() {
			return false;
		}

		public Integer DI_WorkflowFileNameLength() {
			return 255;
		}

		public Integer DI_WorkflowFileNamePrecision() {
			return 0;
		}

		public String DI_WorkflowFileNameDefault() {

			return null;

		}

		public String DI_WorkflowFileNameComment() {

			return "";

		}

		public String DI_WorkflowFileNamePattern() {

			return "";

		}

		public String DI_WorkflowFileNameOriginalDbColumnName() {

			return "DI_WorkflowFileName";

		}

		public String DI_Workflow_ProcessID;

		public String getDI_Workflow_ProcessID() {
			return this.DI_Workflow_ProcessID;
		}

		public Boolean DI_Workflow_ProcessIDIsNullable() {
			return true;
		}

		public Boolean DI_Workflow_ProcessIDIsKey() {
			return false;
		}

		public Integer DI_Workflow_ProcessIDLength() {
			return 30;
		}

		public Integer DI_Workflow_ProcessIDPrecision() {
			return 0;
		}

		public String DI_Workflow_ProcessIDDefault() {

			return null;

		}

		public String DI_Workflow_ProcessIDComment() {

			return "";

		}

		public String DI_Workflow_ProcessIDPattern() {

			return "";

		}

		public String DI_Workflow_ProcessIDOriginalDbColumnName() {

			return "DI_Workflow_ProcessID";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Date_SK = readString(dis);

					this.Year = readInteger(dis);

					this.Day = readInteger(dis);

					this.Day_Of_Week = readString(dis);

					this.Month = readInteger(dis);

					this.Date = readDate(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Date_SK = readString(dis);

					this.Year = readInteger(dis);

					this.Day = readInteger(dis);

					this.Day_Of_Week = readString(dis);

					this.Month = readInteger(dis);

					this.Date = readDate(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.Date_SK, dos);

				// Integer

				writeInteger(this.Year, dos);

				// Integer

				writeInteger(this.Day, dos);

				// String

				writeString(this.Day_Of_Week, dos);

				// Integer

				writeInteger(this.Month, dos);

				// java.util.Date

				writeDate(this.Date, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.Date_SK, dos);

				// Integer

				writeInteger(this.Year, dos);

				// Integer

				writeInteger(this.Day, dos);

				// String

				writeString(this.Day_Of_Week, dos);

				// Integer

				writeInteger(this.Month, dos);

				// java.util.Date

				writeDate(this.Date, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Date_SK=" + Date_SK);
			sb.append(",Year=" + String.valueOf(Year));
			sb.append(",Day=" + String.valueOf(Day));
			sb.append(",Day_Of_Week=" + Day_Of_Week);
			sb.append(",Month=" + String.valueOf(Month));
			sb.append(",Date=" + String.valueOf(Date));
			sb.append(",DI_CreatedDate=" + String.valueOf(DI_CreatedDate));
			sb.append(",DI_WorkflowFileName=" + DI_WorkflowFileName);
			sb.append(",DI_Workflow_ProcessID=" + DI_Workflow_ProcessID);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (Date_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Date_SK);
			}

			sb.append("|");

			if (Year == null) {
				sb.append("<null>");
			} else {
				sb.append(Year);
			}

			sb.append("|");

			if (Day == null) {
				sb.append("<null>");
			} else {
				sb.append(Day);
			}

			sb.append("|");

			if (Day_Of_Week == null) {
				sb.append("<null>");
			} else {
				sb.append(Day_Of_Week);
			}

			sb.append("|");

			if (Month == null) {
				sb.append("<null>");
			} else {
				sb.append(Month);
			}

			sb.append("|");

			if (Date == null) {
				sb.append("<null>");
			} else {
				sb.append(Date);
			}

			sb.append("|");

			if (DI_CreatedDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreatedDate);
			}

			sb.append("|");

			if (DI_WorkflowFileName == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_WorkflowFileName);
			}

			sb.append("|");

			if (DI_Workflow_ProcessID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Workflow_ProcessID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(DimDateStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class DimInspectionTypeStruct implements routines.system.IPersistableRow<DimInspectionTypeStruct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public Integer InspectionType_ID;

		public Integer getInspectionType_ID() {
			return this.InspectionType_ID;
		}

		public Boolean InspectionType_IDIsNullable() {
			return true;
		}

		public Boolean InspectionType_IDIsKey() {
			return false;
		}

		public Integer InspectionType_IDLength() {
			return null;
		}

		public Integer InspectionType_IDPrecision() {
			return null;
		}

		public String InspectionType_IDDefault() {

			return null;

		}

		public String InspectionType_IDComment() {

			return "";

		}

		public String InspectionType_IDPattern() {

			return "";

		}

		public String InspectionType_IDOriginalDbColumnName() {

			return "InspectionType_ID";

		}

		public String InspectionType;

		public String getInspectionType() {
			return this.InspectionType;
		}

		public Boolean InspectionTypeIsNullable() {
			return true;
		}

		public Boolean InspectionTypeIsKey() {
			return false;
		}

		public Integer InspectionTypeLength() {
			return 9;
		}

		public Integer InspectionTypePrecision() {
			return null;
		}

		public String InspectionTypeDefault() {

			return null;

		}

		public String InspectionTypeComment() {

			return "";

		}

		public String InspectionTypePattern() {

			return "";

		}

		public String InspectionTypeOriginalDbColumnName() {

			return "InspectionType";

		}

		public java.util.Date DI_CreatedDate;

		public java.util.Date getDI_CreatedDate() {
			return this.DI_CreatedDate;
		}

		public Boolean DI_CreatedDateIsNullable() {
			return true;
		}

		public Boolean DI_CreatedDateIsKey() {
			return false;
		}

		public Integer DI_CreatedDateLength() {
			return 19;
		}

		public Integer DI_CreatedDatePrecision() {
			return 0;
		}

		public String DI_CreatedDateDefault() {

			return null;

		}

		public String DI_CreatedDateComment() {

			return "";

		}

		public String DI_CreatedDatePattern() {

			return "dd-MM-yyyy";

		}

		public String DI_CreatedDateOriginalDbColumnName() {

			return "DI_CreatedDate";

		}

		public String DI_WorkflowFileName;

		public String getDI_WorkflowFileName() {
			return this.DI_WorkflowFileName;
		}

		public Boolean DI_WorkflowFileNameIsNullable() {
			return true;
		}

		public Boolean DI_WorkflowFileNameIsKey() {
			return false;
		}

		public Integer DI_WorkflowFileNameLength() {
			return 255;
		}

		public Integer DI_WorkflowFileNamePrecision() {
			return 0;
		}

		public String DI_WorkflowFileNameDefault() {

			return null;

		}

		public String DI_WorkflowFileNameComment() {

			return "";

		}

		public String DI_WorkflowFileNamePattern() {

			return "";

		}

		public String DI_WorkflowFileNameOriginalDbColumnName() {

			return "DI_WorkflowFileName";

		}

		public String DI_Workflow_ProcessID;

		public String getDI_Workflow_ProcessID() {
			return this.DI_Workflow_ProcessID;
		}

		public Boolean DI_Workflow_ProcessIDIsNullable() {
			return true;
		}

		public Boolean DI_Workflow_ProcessIDIsKey() {
			return false;
		}

		public Integer DI_Workflow_ProcessIDLength() {
			return 30;
		}

		public Integer DI_Workflow_ProcessIDPrecision() {
			return 0;
		}

		public String DI_Workflow_ProcessIDDefault() {

			return null;

		}

		public String DI_Workflow_ProcessIDComment() {

			return "";

		}

		public String DI_Workflow_ProcessIDPattern() {

			return "";

		}

		public String DI_Workflow_ProcessIDOriginalDbColumnName() {

			return "DI_Workflow_ProcessID";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.InspectionType_ID = readInteger(dis);

					this.InspectionType = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.InspectionType_ID = readInteger(dis);

					this.InspectionType = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.InspectionType_ID, dos);

				// String

				writeString(this.InspectionType, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.InspectionType_ID, dos);

				// String

				writeString(this.InspectionType, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("InspectionType_ID=" + String.valueOf(InspectionType_ID));
			sb.append(",InspectionType=" + InspectionType);
			sb.append(",DI_CreatedDate=" + String.valueOf(DI_CreatedDate));
			sb.append(",DI_WorkflowFileName=" + DI_WorkflowFileName);
			sb.append(",DI_Workflow_ProcessID=" + DI_Workflow_ProcessID);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (InspectionType_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionType_ID);
			}

			sb.append("|");

			if (InspectionType == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionType);
			}

			sb.append("|");

			if (DI_CreatedDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreatedDate);
			}

			sb.append("|");

			if (DI_WorkflowFileName == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_WorkflowFileName);
			}

			sb.append("|");

			if (DI_Workflow_ProcessID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Workflow_ProcessID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(DimInspectionTypeStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class DimLocationStruct implements routines.system.IPersistableRow<DimLocationStruct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public Integer Location_SK;

		public Integer getLocation_SK() {
			return this.Location_SK;
		}

		public Boolean Location_SKIsNullable() {
			return true;
		}

		public Boolean Location_SKIsKey() {
			return false;
		}

		public Integer Location_SKLength() {
			return null;
		}

		public Integer Location_SKPrecision() {
			return null;
		}

		public String Location_SKDefault() {

			return null;

		}

		public String Location_SKComment() {

			return "";

		}

		public String Location_SKPattern() {

			return "";

		}

		public String Location_SKOriginalDbColumnName() {

			return "Location_SK";

		}

		public String Address;

		public String getAddress() {
			return this.Address;
		}

		public Boolean AddressIsNullable() {
			return true;
		}

		public Boolean AddressIsKey() {
			return false;
		}

		public Integer AddressLength() {
			return 40;
		}

		public Integer AddressPrecision() {
			return null;
		}

		public String AddressDefault() {

			return null;

		}

		public String AddressComment() {

			return "";

		}

		public String AddressPattern() {

			return "";

		}

		public String AddressOriginalDbColumnName() {

			return "Address";

		}

		public String ZipCode;

		public String getZipCode() {
			return this.ZipCode;
		}

		public Boolean ZipCodeIsNullable() {
			return true;
		}

		public Boolean ZipCodeIsKey() {
			return false;
		}

		public Integer ZipCodeLength() {
			return 10;
		}

		public Integer ZipCodePrecision() {
			return null;
		}

		public String ZipCodeDefault() {

			return null;

		}

		public String ZipCodeComment() {

			return "";

		}

		public String ZipCodePattern() {

			return "";

		}

		public String ZipCodeOriginalDbColumnName() {

			return "ZipCode";

		}

		public String State;

		public String getState() {
			return this.State;
		}

		public Boolean StateIsNullable() {
			return true;
		}

		public Boolean StateIsKey() {
			return false;
		}

		public Integer StateLength() {
			return 2;
		}

		public Integer StatePrecision() {
			return null;
		}

		public String StateDefault() {

			return null;

		}

		public String StateComment() {

			return "";

		}

		public String StatePattern() {

			return "";

		}

		public String StateOriginalDbColumnName() {

			return "State";

		}

		public String City;

		public String getCity() {
			return this.City;
		}

		public Boolean CityIsNullable() {
			return true;
		}

		public Boolean CityIsKey() {
			return false;
		}

		public Integer CityLength() {
			return 20;
		}

		public Integer CityPrecision() {
			return null;
		}

		public String CityDefault() {

			return null;

		}

		public String CityComment() {

			return "";

		}

		public String CityPattern() {

			return "";

		}

		public String CityOriginalDbColumnName() {

			return "City";

		}

		public String Location;

		public String getLocation() {
			return this.Location;
		}

		public Boolean LocationIsNullable() {
			return true;
		}

		public Boolean LocationIsKey() {
			return false;
		}

		public Integer LocationLength() {
			return 100;
		}

		public Integer LocationPrecision() {
			return null;
		}

		public String LocationDefault() {

			return null;

		}

		public String LocationComment() {

			return "";

		}

		public String LocationPattern() {

			return "";

		}

		public String LocationOriginalDbColumnName() {

			return "Location";

		}

		public Double Latitude;

		public Double getLatitude() {
			return this.Latitude;
		}

		public Boolean LatitudeIsNullable() {
			return true;
		}

		public Boolean LatitudeIsKey() {
			return false;
		}

		public Integer LatitudeLength() {
			return null;
		}

		public Integer LatitudePrecision() {
			return null;
		}

		public String LatitudeDefault() {

			return null;

		}

		public String LatitudeComment() {

			return "";

		}

		public String LatitudePattern() {

			return "";

		}

		public String LatitudeOriginalDbColumnName() {

			return "Latitude";

		}

		public Double Longitude;

		public Double getLongitude() {
			return this.Longitude;
		}

		public Boolean LongitudeIsNullable() {
			return true;
		}

		public Boolean LongitudeIsKey() {
			return false;
		}

		public Integer LongitudeLength() {
			return null;
		}

		public Integer LongitudePrecision() {
			return null;
		}

		public String LongitudeDefault() {

			return null;

		}

		public String LongitudeComment() {

			return "";

		}

		public String LongitudePattern() {

			return "";

		}

		public String LongitudeOriginalDbColumnName() {

			return "Longitude";

		}

		public java.util.Date DI_CreatedDate;

		public java.util.Date getDI_CreatedDate() {
			return this.DI_CreatedDate;
		}

		public Boolean DI_CreatedDateIsNullable() {
			return true;
		}

		public Boolean DI_CreatedDateIsKey() {
			return false;
		}

		public Integer DI_CreatedDateLength() {
			return 19;
		}

		public Integer DI_CreatedDatePrecision() {
			return 0;
		}

		public String DI_CreatedDateDefault() {

			return null;

		}

		public String DI_CreatedDateComment() {

			return "";

		}

		public String DI_CreatedDatePattern() {

			return "dd-MM-yyyy";

		}

		public String DI_CreatedDateOriginalDbColumnName() {

			return "DI_CreatedDate";

		}

		public String DI_WorkflowFileName;

		public String getDI_WorkflowFileName() {
			return this.DI_WorkflowFileName;
		}

		public Boolean DI_WorkflowFileNameIsNullable() {
			return true;
		}

		public Boolean DI_WorkflowFileNameIsKey() {
			return false;
		}

		public Integer DI_WorkflowFileNameLength() {
			return 255;
		}

		public Integer DI_WorkflowFileNamePrecision() {
			return 0;
		}

		public String DI_WorkflowFileNameDefault() {

			return null;

		}

		public String DI_WorkflowFileNameComment() {

			return "";

		}

		public String DI_WorkflowFileNamePattern() {

			return "";

		}

		public String DI_WorkflowFileNameOriginalDbColumnName() {

			return "DI_WorkflowFileName";

		}

		public String DI_Workflow_ProcessID;

		public String getDI_Workflow_ProcessID() {
			return this.DI_Workflow_ProcessID;
		}

		public Boolean DI_Workflow_ProcessIDIsNullable() {
			return true;
		}

		public Boolean DI_Workflow_ProcessIDIsKey() {
			return false;
		}

		public Integer DI_Workflow_ProcessIDLength() {
			return 30;
		}

		public Integer DI_Workflow_ProcessIDPrecision() {
			return 0;
		}

		public String DI_Workflow_ProcessIDDefault() {

			return null;

		}

		public String DI_Workflow_ProcessIDComment() {

			return "";

		}

		public String DI_Workflow_ProcessIDPattern() {

			return "";

		}

		public String DI_Workflow_ProcessIDOriginalDbColumnName() {

			return "DI_Workflow_ProcessID";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Location_SK = readInteger(dis);

					this.Address = readString(dis);

					this.ZipCode = readString(dis);

					this.State = readString(dis);

					this.City = readString(dis);

					this.Location = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Latitude = null;
					} else {
						this.Latitude = dis.readDouble();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Longitude = null;
					} else {
						this.Longitude = dis.readDouble();
					}

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Location_SK = readInteger(dis);

					this.Address = readString(dis);

					this.ZipCode = readString(dis);

					this.State = readString(dis);

					this.City = readString(dis);

					this.Location = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Latitude = null;
					} else {
						this.Latitude = dis.readDouble();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Longitude = null;
					} else {
						this.Longitude = dis.readDouble();
					}

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.Location_SK, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.ZipCode, dos);

				// String

				writeString(this.State, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.Location, dos);

				// Double

				if (this.Latitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.Latitude);
				}

				// Double

				if (this.Longitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.Longitude);
				}

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.Location_SK, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.ZipCode, dos);

				// String

				writeString(this.State, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.Location, dos);

				// Double

				if (this.Latitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.Latitude);
				}

				// Double

				if (this.Longitude == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.Longitude);
				}

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Location_SK=" + String.valueOf(Location_SK));
			sb.append(",Address=" + Address);
			sb.append(",ZipCode=" + ZipCode);
			sb.append(",State=" + State);
			sb.append(",City=" + City);
			sb.append(",Location=" + Location);
			sb.append(",Latitude=" + String.valueOf(Latitude));
			sb.append(",Longitude=" + String.valueOf(Longitude));
			sb.append(",DI_CreatedDate=" + String.valueOf(DI_CreatedDate));
			sb.append(",DI_WorkflowFileName=" + DI_WorkflowFileName);
			sb.append(",DI_Workflow_ProcessID=" + DI_Workflow_ProcessID);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (Location_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Location_SK);
			}

			sb.append("|");

			if (Address == null) {
				sb.append("<null>");
			} else {
				sb.append(Address);
			}

			sb.append("|");

			if (ZipCode == null) {
				sb.append("<null>");
			} else {
				sb.append(ZipCode);
			}

			sb.append("|");

			if (State == null) {
				sb.append("<null>");
			} else {
				sb.append(State);
			}

			sb.append("|");

			if (City == null) {
				sb.append("<null>");
			} else {
				sb.append(City);
			}

			sb.append("|");

			if (Location == null) {
				sb.append("<null>");
			} else {
				sb.append(Location);
			}

			sb.append("|");

			if (Latitude == null) {
				sb.append("<null>");
			} else {
				sb.append(Latitude);
			}

			sb.append("|");

			if (Longitude == null) {
				sb.append("<null>");
			} else {
				sb.append(Longitude);
			}

			sb.append("|");

			if (DI_CreatedDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreatedDate);
			}

			sb.append("|");

			if (DI_WorkflowFileName == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_WorkflowFileName);
			}

			sb.append("|");

			if (DI_Workflow_ProcessID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Workflow_ProcessID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(DimLocationStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class DimViolationStruct implements routines.system.IPersistableRow<DimViolationStruct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public Integer Violation_ID;

		public Integer getViolation_ID() {
			return this.Violation_ID;
		}

		public Boolean Violation_IDIsNullable() {
			return true;
		}

		public Boolean Violation_IDIsKey() {
			return false;
		}

		public Integer Violation_IDLength() {
			return null;
		}

		public Integer Violation_IDPrecision() {
			return null;
		}

		public String Violation_IDDefault() {

			return null;

		}

		public String Violation_IDComment() {

			return "";

		}

		public String Violation_IDPattern() {

			return "";

		}

		public String Violation_IDOriginalDbColumnName() {

			return "Violation_ID";

		}

		public String Violation_Code;

		public String getViolation_Code() {
			return this.Violation_Code;
		}

		public Boolean Violation_CodeIsNullable() {
			return true;
		}

		public Boolean Violation_CodeIsKey() {
			return false;
		}

		public Integer Violation_CodeLength() {
			return null;
		}

		public Integer Violation_CodePrecision() {
			return null;
		}

		public String Violation_CodeDefault() {

			return null;

		}

		public String Violation_CodeComment() {

			return "";

		}

		public String Violation_CodePattern() {

			return "";

		}

		public String Violation_CodeOriginalDbColumnName() {

			return "Violation_Code";

		}

		public Integer Code_Score;

		public Integer getCode_Score() {
			return this.Code_Score;
		}

		public Boolean Code_ScoreIsNullable() {
			return true;
		}

		public Boolean Code_ScoreIsKey() {
			return false;
		}

		public Integer Code_ScoreLength() {
			return null;
		}

		public Integer Code_ScorePrecision() {
			return null;
		}

		public String Code_ScoreDefault() {

			return null;

		}

		public String Code_ScoreComment() {

			return "";

		}

		public String Code_ScorePattern() {

			return "";

		}

		public String Code_ScoreOriginalDbColumnName() {

			return "Code_Score";

		}

		public String Violation_Category;

		public String getViolation_Category() {
			return this.Violation_Category;
		}

		public Boolean Violation_CategoryIsNullable() {
			return true;
		}

		public Boolean Violation_CategoryIsKey() {
			return false;
		}

		public Integer Violation_CategoryLength() {
			return null;
		}

		public Integer Violation_CategoryPrecision() {
			return null;
		}

		public String Violation_CategoryDefault() {

			return null;

		}

		public String Violation_CategoryComment() {

			return "";

		}

		public String Violation_CategoryPattern() {

			return "";

		}

		public String Violation_CategoryOriginalDbColumnName() {

			return "Violation_Category";

		}

		public java.util.Date DI_CreatedDate;

		public java.util.Date getDI_CreatedDate() {
			return this.DI_CreatedDate;
		}

		public Boolean DI_CreatedDateIsNullable() {
			return true;
		}

		public Boolean DI_CreatedDateIsKey() {
			return false;
		}

		public Integer DI_CreatedDateLength() {
			return 19;
		}

		public Integer DI_CreatedDatePrecision() {
			return 0;
		}

		public String DI_CreatedDateDefault() {

			return null;

		}

		public String DI_CreatedDateComment() {

			return "";

		}

		public String DI_CreatedDatePattern() {

			return "dd-MM-yyyy";

		}

		public String DI_CreatedDateOriginalDbColumnName() {

			return "DI_CreatedDate";

		}

		public String DI_WorkflowFileName;

		public String getDI_WorkflowFileName() {
			return this.DI_WorkflowFileName;
		}

		public Boolean DI_WorkflowFileNameIsNullable() {
			return true;
		}

		public Boolean DI_WorkflowFileNameIsKey() {
			return false;
		}

		public Integer DI_WorkflowFileNameLength() {
			return 255;
		}

		public Integer DI_WorkflowFileNamePrecision() {
			return 0;
		}

		public String DI_WorkflowFileNameDefault() {

			return null;

		}

		public String DI_WorkflowFileNameComment() {

			return "";

		}

		public String DI_WorkflowFileNamePattern() {

			return "";

		}

		public String DI_WorkflowFileNameOriginalDbColumnName() {

			return "DI_WorkflowFileName";

		}

		public String DI_Workflow_ProcessID;

		public String getDI_Workflow_ProcessID() {
			return this.DI_Workflow_ProcessID;
		}

		public Boolean DI_Workflow_ProcessIDIsNullable() {
			return true;
		}

		public Boolean DI_Workflow_ProcessIDIsKey() {
			return false;
		}

		public Integer DI_Workflow_ProcessIDLength() {
			return 30;
		}

		public Integer DI_Workflow_ProcessIDPrecision() {
			return 0;
		}

		public String DI_Workflow_ProcessIDDefault() {

			return null;

		}

		public String DI_Workflow_ProcessIDComment() {

			return "";

		}

		public String DI_Workflow_ProcessIDPattern() {

			return "";

		}

		public String DI_Workflow_ProcessIDOriginalDbColumnName() {

			return "DI_Workflow_ProcessID";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Violation_ID = readInteger(dis);

					this.Violation_Code = readString(dis);

					this.Code_Score = readInteger(dis);

					this.Violation_Category = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Violation_ID = readInteger(dis);

					this.Violation_Code = readString(dis);

					this.Code_Score = readInteger(dis);

					this.Violation_Category = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.Violation_ID, dos);

				// String

				writeString(this.Violation_Code, dos);

				// Integer

				writeInteger(this.Code_Score, dos);

				// String

				writeString(this.Violation_Category, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.Violation_ID, dos);

				// String

				writeString(this.Violation_Code, dos);

				// Integer

				writeInteger(this.Code_Score, dos);

				// String

				writeString(this.Violation_Category, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Violation_ID=" + String.valueOf(Violation_ID));
			sb.append(",Violation_Code=" + Violation_Code);
			sb.append(",Code_Score=" + String.valueOf(Code_Score));
			sb.append(",Violation_Category=" + Violation_Category);
			sb.append(",DI_CreatedDate=" + String.valueOf(DI_CreatedDate));
			sb.append(",DI_WorkflowFileName=" + DI_WorkflowFileName);
			sb.append(",DI_Workflow_ProcessID=" + DI_Workflow_ProcessID);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (Violation_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(Violation_ID);
			}

			sb.append("|");

			if (Violation_Code == null) {
				sb.append("<null>");
			} else {
				sb.append(Violation_Code);
			}

			sb.append("|");

			if (Code_Score == null) {
				sb.append("<null>");
			} else {
				sb.append(Code_Score);
			}

			sb.append("|");

			if (Violation_Category == null) {
				sb.append("<null>");
			} else {
				sb.append(Violation_Category);
			}

			sb.append("|");

			if (DI_CreatedDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreatedDate);
			}

			sb.append("|");

			if (DI_WorkflowFileName == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_WorkflowFileName);
			}

			sb.append("|");

			if (DI_Workflow_ProcessID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Workflow_ProcessID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(DimViolationStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class DimBusinessStruct implements routines.system.IPersistableRow<DimBusinessStruct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public Integer Business_ID_SK;

		public Integer getBusiness_ID_SK() {
			return this.Business_ID_SK;
		}

		public Boolean Business_ID_SKIsNullable() {
			return true;
		}

		public Boolean Business_ID_SKIsKey() {
			return false;
		}

		public Integer Business_ID_SKLength() {
			return null;
		}

		public Integer Business_ID_SKPrecision() {
			return null;
		}

		public String Business_ID_SKDefault() {

			return null;

		}

		public String Business_ID_SKComment() {

			return "";

		}

		public String Business_ID_SKPattern() {

			return "";

		}

		public String Business_ID_SKOriginalDbColumnName() {

			return "Business_ID_SK";

		}

		public String BusinessId;

		public String getBusinessId() {
			return this.BusinessId;
		}

		public Boolean BusinessIdIsNullable() {
			return true;
		}

		public Boolean BusinessIdIsKey() {
			return false;
		}

		public Integer BusinessIdLength() {
			return 9;
		}

		public Integer BusinessIdPrecision() {
			return null;
		}

		public String BusinessIdDefault() {

			return null;

		}

		public String BusinessIdComment() {

			return "";

		}

		public String BusinessIdPattern() {

			return "";

		}

		public String BusinessIdOriginalDbColumnName() {

			return "BusinessId";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 70;
		}

		public Integer NamePrecision() {
			return null;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public String PhoneNumber;

		public String getPhoneNumber() {
			return this.PhoneNumber;
		}

		public Boolean PhoneNumberIsNullable() {
			return true;
		}

		public Boolean PhoneNumberIsKey() {
			return false;
		}

		public Integer PhoneNumberLength() {
			return 13;
		}

		public Integer PhoneNumberPrecision() {
			return null;
		}

		public String PhoneNumberDefault() {

			return null;

		}

		public String PhoneNumberComment() {

			return "";

		}

		public String PhoneNumberPattern() {

			return "";

		}

		public String PhoneNumberOriginalDbColumnName() {

			return "PhoneNumber";

		}

		public java.util.Date DI_CreatedDate;

		public java.util.Date getDI_CreatedDate() {
			return this.DI_CreatedDate;
		}

		public Boolean DI_CreatedDateIsNullable() {
			return true;
		}

		public Boolean DI_CreatedDateIsKey() {
			return false;
		}

		public Integer DI_CreatedDateLength() {
			return 19;
		}

		public Integer DI_CreatedDatePrecision() {
			return null;
		}

		public String DI_CreatedDateDefault() {

			return null;

		}

		public String DI_CreatedDateComment() {

			return "";

		}

		public String DI_CreatedDatePattern() {

			return "dd-MM-yyyy";

		}

		public String DI_CreatedDateOriginalDbColumnName() {

			return "DI_CreatedDate";

		}

		public String DI_WorkflowFileName;

		public String getDI_WorkflowFileName() {
			return this.DI_WorkflowFileName;
		}

		public Boolean DI_WorkflowFileNameIsNullable() {
			return true;
		}

		public Boolean DI_WorkflowFileNameIsKey() {
			return false;
		}

		public Integer DI_WorkflowFileNameLength() {
			return 255;
		}

		public Integer DI_WorkflowFileNamePrecision() {
			return null;
		}

		public String DI_WorkflowFileNameDefault() {

			return null;

		}

		public String DI_WorkflowFileNameComment() {

			return "";

		}

		public String DI_WorkflowFileNamePattern() {

			return "";

		}

		public String DI_WorkflowFileNameOriginalDbColumnName() {

			return "DI_WorkflowFileName";

		}

		public String DI_Workflow_ProcessID;

		public String getDI_Workflow_ProcessID() {
			return this.DI_Workflow_ProcessID;
		}

		public Boolean DI_Workflow_ProcessIDIsNullable() {
			return true;
		}

		public Boolean DI_Workflow_ProcessIDIsKey() {
			return false;
		}

		public Integer DI_Workflow_ProcessIDLength() {
			return 30;
		}

		public Integer DI_Workflow_ProcessIDPrecision() {
			return null;
		}

		public String DI_Workflow_ProcessIDDefault() {

			return null;

		}

		public String DI_Workflow_ProcessIDComment() {

			return "";

		}

		public String DI_Workflow_ProcessIDPattern() {

			return "";

		}

		public String DI_Workflow_ProcessIDOriginalDbColumnName() {

			return "DI_Workflow_ProcessID";

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Business_ID_SK = readInteger(dis);

					this.BusinessId = readString(dis);

					this.Name = readString(dis);

					this.PhoneNumber = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Business_ID_SK = readInteger(dis);

					this.BusinessId = readString(dis);

					this.Name = readString(dis);

					this.PhoneNumber = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.Business_ID_SK, dos);

				// String

				writeString(this.BusinessId, dos);

				// String

				writeString(this.Name, dos);

				// String

				writeString(this.PhoneNumber, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.Business_ID_SK, dos);

				// String

				writeString(this.BusinessId, dos);

				// String

				writeString(this.Name, dos);

				// String

				writeString(this.PhoneNumber, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Business_ID_SK=" + String.valueOf(Business_ID_SK));
			sb.append(",BusinessId=" + BusinessId);
			sb.append(",Name=" + Name);
			sb.append(",PhoneNumber=" + PhoneNumber);
			sb.append(",DI_CreatedDate=" + String.valueOf(DI_CreatedDate));
			sb.append(",DI_WorkflowFileName=" + DI_WorkflowFileName);
			sb.append(",DI_Workflow_ProcessID=" + DI_Workflow_ProcessID);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (Business_ID_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Business_ID_SK);
			}

			sb.append("|");

			if (BusinessId == null) {
				sb.append("<null>");
			} else {
				sb.append(BusinessId);
			}

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (PhoneNumber == null) {
				sb.append("<null>");
			} else {
				sb.append(PhoneNumber);
			}

			sb.append("|");

			if (DI_CreatedDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreatedDate);
			}

			sb.append("|");

			if (DI_WorkflowFileName == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_WorkflowFileName);
			}

			sb.append("|");

			if (DI_Workflow_ProcessID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Workflow_ProcessID);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(DimBusinessStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row12Struct implements routines.system.IPersistableRow<row12Struct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public String BusinessId;

		public String getBusinessId() {
			return this.BusinessId;
		}

		public Boolean BusinessIdIsNullable() {
			return true;
		}

		public Boolean BusinessIdIsKey() {
			return false;
		}

		public Integer BusinessIdLength() {
			return 9;
		}

		public Integer BusinessIdPrecision() {
			return 0;
		}

		public String BusinessIdDefault() {

			return null;

		}

		public String BusinessIdComment() {

			return "";

		}

		public String BusinessIdPattern() {

			return "";

		}

		public String BusinessIdOriginalDbColumnName() {

			return "BusinessId";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 70;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public String Address;

		public String getAddress() {
			return this.Address;
		}

		public Boolean AddressIsNullable() {
			return true;
		}

		public Boolean AddressIsKey() {
			return false;
		}

		public Integer AddressLength() {
			return 40;
		}

		public Integer AddressPrecision() {
			return 0;
		}

		public String AddressDefault() {

			return null;

		}

		public String AddressComment() {

			return "";

		}

		public String AddressPattern() {

			return "";

		}

		public String AddressOriginalDbColumnName() {

			return "Address";

		}

		public String City;

		public String getCity() {
			return this.City;
		}

		public Boolean CityIsNullable() {
			return true;
		}

		public Boolean CityIsKey() {
			return false;
		}

		public Integer CityLength() {
			return 20;
		}

		public Integer CityPrecision() {
			return 0;
		}

		public String CityDefault() {

			return null;

		}

		public String CityComment() {

			return "";

		}

		public String CityPattern() {

			return "";

		}

		public String CityOriginalDbColumnName() {

			return "City";

		}

		public String State;

		public String getState() {
			return this.State;
		}

		public Boolean StateIsNullable() {
			return true;
		}

		public Boolean StateIsKey() {
			return false;
		}

		public Integer StateLength() {
			return 2;
		}

		public Integer StatePrecision() {
			return 0;
		}

		public String StateDefault() {

			return null;

		}

		public String StateComment() {

			return "";

		}

		public String StatePattern() {

			return "";

		}

		public String StateOriginalDbColumnName() {

			return "State";

		}

		public String ZipCode;

		public String getZipCode() {
			return this.ZipCode;
		}

		public Boolean ZipCodeIsNullable() {
			return true;
		}

		public Boolean ZipCodeIsKey() {
			return false;
		}

		public Integer ZipCodeLength() {
			return 10;
		}

		public Integer ZipCodePrecision() {
			return 0;
		}

		public String ZipCodeDefault() {

			return null;

		}

		public String ZipCodeComment() {

			return "";

		}

		public String ZipCodePattern() {

			return "";

		}

		public String ZipCodeOriginalDbColumnName() {

			return "ZipCode";

		}

		public String PhoneNumber;

		public String getPhoneNumber() {
			return this.PhoneNumber;
		}

		public Boolean PhoneNumberIsNullable() {
			return true;
		}

		public Boolean PhoneNumberIsKey() {
			return false;
		}

		public Integer PhoneNumberLength() {
			return 13;
		}

		public Integer PhoneNumberPrecision() {
			return 0;
		}

		public String PhoneNumberDefault() {

			return null;

		}

		public String PhoneNumberComment() {

			return "";

		}

		public String PhoneNumberPattern() {

			return "";

		}

		public String PhoneNumberOriginalDbColumnName() {

			return "PhoneNumber";

		}

		public String InspectionId;

		public String getInspectionId() {
			return this.InspectionId;
		}

		public Boolean InspectionIdIsNullable() {
			return true;
		}

		public Boolean InspectionIdIsKey() {
			return false;
		}

		public Integer InspectionIdLength() {
			return 9;
		}

		public Integer InspectionIdPrecision() {
			return 0;
		}

		public String InspectionIdDefault() {

			return null;

		}

		public String InspectionIdComment() {

			return "";

		}

		public String InspectionIdPattern() {

			return "";

		}

		public String InspectionIdOriginalDbColumnName() {

			return "InspectionId";

		}

		public java.util.Date Date;

		public java.util.Date getDate() {
			return this.Date;
		}

		public Boolean DateIsNullable() {
			return true;
		}

		public Boolean DateIsKey() {
			return false;
		}

		public Integer DateLength() {
			return 19;
		}

		public Integer DatePrecision() {
			return 0;
		}

		public String DateDefault() {

			return null;

		}

		public String DateComment() {

			return "";

		}

		public String DatePattern() {

			return "dd-MM-yyyy";

		}

		public String DateOriginalDbColumnName() {

			return "Date";

		}

		public String InspectionType;

		public String getInspectionType() {
			return this.InspectionType;
		}

		public Boolean InspectionTypeIsNullable() {
			return true;
		}

		public Boolean InspectionTypeIsKey() {
			return false;
		}

		public Integer InspectionTypeLength() {
			return 9;
		}

		public Integer InspectionTypePrecision() {
			return 0;
		}

		public String InspectionTypeDefault() {

			return null;

		}

		public String InspectionTypeComment() {

			return "";

		}

		public String InspectionTypePattern() {

			return "";

		}

		public String InspectionTypeOriginalDbColumnName() {

			return "InspectionType";

		}

		public String Location;

		public String getLocation() {
			return this.Location;
		}

		public Boolean LocationIsNullable() {
			return true;
		}

		public Boolean LocationIsKey() {
			return false;
		}

		public Integer LocationLength() {
			return 100;
		}

		public Integer LocationPrecision() {
			return 0;
		}

		public String LocationDefault() {

			return null;

		}

		public String LocationComment() {

			return "";

		}

		public String LocationPattern() {

			return "";

		}

		public String LocationOriginalDbColumnName() {

			return "Location";

		}

		public String Latitude;

		public String getLatitude() {
			return this.Latitude;
		}

		public Boolean LatitudeIsNullable() {
			return true;
		}

		public Boolean LatitudeIsKey() {
			return false;
		}

		public Integer LatitudeLength() {
			return 10;
		}

		public Integer LatitudePrecision() {
			return null;
		}

		public String LatitudeDefault() {

			return null;

		}

		public String LatitudeComment() {

			return "";

		}

		public String LatitudePattern() {

			return "";

		}

		public String LatitudeOriginalDbColumnName() {

			return "Latitude";

		}

		public String Longitude;

		public String getLongitude() {
			return this.Longitude;
		}

		public Boolean LongitudeIsNullable() {
			return true;
		}

		public Boolean LongitudeIsKey() {
			return false;
		}

		public Integer LongitudeLength() {
			return 10;
		}

		public Integer LongitudePrecision() {
			return null;
		}

		public String LongitudeDefault() {

			return null;

		}

		public String LongitudeComment() {

			return "";

		}

		public String LongitudePattern() {

			return "";

		}

		public String LongitudeOriginalDbColumnName() {

			return "Longitude";

		}

		public java.util.Date DI_CreatedDate;

		public java.util.Date getDI_CreatedDate() {
			return this.DI_CreatedDate;
		}

		public Boolean DI_CreatedDateIsNullable() {
			return true;
		}

		public Boolean DI_CreatedDateIsKey() {
			return false;
		}

		public Integer DI_CreatedDateLength() {
			return 19;
		}

		public Integer DI_CreatedDatePrecision() {
			return 0;
		}

		public String DI_CreatedDateDefault() {

			return null;

		}

		public String DI_CreatedDateComment() {

			return "";

		}

		public String DI_CreatedDatePattern() {

			return "dd-MM-yyyy";

		}

		public String DI_CreatedDateOriginalDbColumnName() {

			return "DI_CreatedDate";

		}

		public String DI_WorkflowFileName;

		public String getDI_WorkflowFileName() {
			return this.DI_WorkflowFileName;
		}

		public Boolean DI_WorkflowFileNameIsNullable() {
			return true;
		}

		public Boolean DI_WorkflowFileNameIsKey() {
			return false;
		}

		public Integer DI_WorkflowFileNameLength() {
			return 255;
		}

		public Integer DI_WorkflowFileNamePrecision() {
			return 0;
		}

		public String DI_WorkflowFileNameDefault() {

			return null;

		}

		public String DI_WorkflowFileNameComment() {

			return "";

		}

		public String DI_WorkflowFileNamePattern() {

			return "";

		}

		public String DI_WorkflowFileNameOriginalDbColumnName() {

			return "DI_WorkflowFileName";

		}

		public String DI_Workflow_ProcessID;

		public String getDI_Workflow_ProcessID() {
			return this.DI_Workflow_ProcessID;
		}

		public Boolean DI_Workflow_ProcessIDIsNullable() {
			return true;
		}

		public Boolean DI_Workflow_ProcessIDIsKey() {
			return false;
		}

		public Integer DI_Workflow_ProcessIDLength() {
			return 30;
		}

		public Integer DI_Workflow_ProcessIDPrecision() {
			return 0;
		}

		public String DI_Workflow_ProcessIDDefault() {

			return null;

		}

		public String DI_Workflow_ProcessIDComment() {

			return "";

		}

		public String DI_Workflow_ProcessIDPattern() {

			return "";

		}

		public String DI_Workflow_ProcessIDOriginalDbColumnName() {

			return "DI_Workflow_ProcessID";

		}

		public String Date_SK;

		public String getDate_SK() {
			return this.Date_SK;
		}

		public Boolean Date_SKIsNullable() {
			return true;
		}

		public Boolean Date_SKIsKey() {
			return false;
		}

		public Integer Date_SKLength() {
			return null;
		}

		public Integer Date_SKPrecision() {
			return null;
		}

		public String Date_SKDefault() {

			return null;

		}

		public String Date_SKComment() {

			return "";

		}

		public String Date_SKPattern() {

			return "";

		}

		public String Date_SKOriginalDbColumnName() {

			return "Date_SK";

		}

		public Integer InspectionType_ID;

		public Integer getInspectionType_ID() {
			return this.InspectionType_ID;
		}

		public Boolean InspectionType_IDIsNullable() {
			return true;
		}

		public Boolean InspectionType_IDIsKey() {
			return false;
		}

		public Integer InspectionType_IDLength() {
			return null;
		}

		public Integer InspectionType_IDPrecision() {
			return null;
		}

		public String InspectionType_IDDefault() {

			return null;

		}

		public String InspectionType_IDComment() {

			return "";

		}

		public String InspectionType_IDPattern() {

			return "";

		}

		public String InspectionType_IDOriginalDbColumnName() {

			return "InspectionType_ID";

		}

		public Integer Business_ID_SK;

		public Integer getBusiness_ID_SK() {
			return this.Business_ID_SK;
		}

		public Boolean Business_ID_SKIsNullable() {
			return true;
		}

		public Boolean Business_ID_SKIsKey() {
			return false;
		}

		public Integer Business_ID_SKLength() {
			return null;
		}

		public Integer Business_ID_SKPrecision() {
			return null;
		}

		public String Business_ID_SKDefault() {

			return null;

		}

		public String Business_ID_SKComment() {

			return "";

		}

		public String Business_ID_SKPattern() {

			return "";

		}

		public String Business_ID_SKOriginalDbColumnName() {

			return "Business_ID_SK";

		}

		public Integer Location_SK;

		public Integer getLocation_SK() {
			return this.Location_SK;
		}

		public Boolean Location_SKIsNullable() {
			return true;
		}

		public Boolean Location_SKIsKey() {
			return false;
		}

		public Integer Location_SKLength() {
			return null;
		}

		public Integer Location_SKPrecision() {
			return null;
		}

		public String Location_SKDefault() {

			return null;

		}

		public String Location_SKComment() {

			return "";

		}

		public String Location_SKPattern() {

			return "";

		}

		public String Location_SKOriginalDbColumnName() {

			return "Location_SK";

		}

		public Integer Inspection_SK;

		public Integer getInspection_SK() {
			return this.Inspection_SK;
		}

		public Boolean Inspection_SKIsNullable() {
			return true;
		}

		public Boolean Inspection_SKIsKey() {
			return false;
		}

		public Integer Inspection_SKLength() {
			return null;
		}

		public Integer Inspection_SKPrecision() {
			return null;
		}

		public String Inspection_SKDefault() {

			return null;

		}

		public String Inspection_SKComment() {

			return "";

		}

		public String Inspection_SKPattern() {

			return "";

		}

		public String Inspection_SKOriginalDbColumnName() {

			return "Inspection_SK";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.BusinessId = readString(dis);

					this.Name = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.State = readString(dis);

					this.ZipCode = readString(dis);

					this.PhoneNumber = readString(dis);

					this.InspectionId = readString(dis);

					this.Date = readDate(dis);

					this.InspectionType = readString(dis);

					this.Location = readString(dis);

					this.Latitude = readString(dis);

					this.Longitude = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

					this.Date_SK = readString(dis);

					this.InspectionType_ID = readInteger(dis);

					this.Business_ID_SK = readInteger(dis);

					this.Location_SK = readInteger(dis);

					this.Inspection_SK = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.BusinessId = readString(dis);

					this.Name = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.State = readString(dis);

					this.ZipCode = readString(dis);

					this.PhoneNumber = readString(dis);

					this.InspectionId = readString(dis);

					this.Date = readDate(dis);

					this.InspectionType = readString(dis);

					this.Location = readString(dis);

					this.Latitude = readString(dis);

					this.Longitude = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

					this.Date_SK = readString(dis);

					this.InspectionType_ID = readInteger(dis);

					this.Business_ID_SK = readInteger(dis);

					this.Location_SK = readInteger(dis);

					this.Inspection_SK = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.BusinessId, dos);

				// String

				writeString(this.Name, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.State, dos);

				// String

				writeString(this.ZipCode, dos);

				// String

				writeString(this.PhoneNumber, dos);

				// String

				writeString(this.InspectionId, dos);

				// java.util.Date

				writeDate(this.Date, dos);

				// String

				writeString(this.InspectionType, dos);

				// String

				writeString(this.Location, dos);

				// String

				writeString(this.Latitude, dos);

				// String

				writeString(this.Longitude, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

				// String

				writeString(this.Date_SK, dos);

				// Integer

				writeInteger(this.InspectionType_ID, dos);

				// Integer

				writeInteger(this.Business_ID_SK, dos);

				// Integer

				writeInteger(this.Location_SK, dos);

				// Integer

				writeInteger(this.Inspection_SK, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.BusinessId, dos);

				// String

				writeString(this.Name, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.State, dos);

				// String

				writeString(this.ZipCode, dos);

				// String

				writeString(this.PhoneNumber, dos);

				// String

				writeString(this.InspectionId, dos);

				// java.util.Date

				writeDate(this.Date, dos);

				// String

				writeString(this.InspectionType, dos);

				// String

				writeString(this.Location, dos);

				// String

				writeString(this.Latitude, dos);

				// String

				writeString(this.Longitude, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

				// String

				writeString(this.Date_SK, dos);

				// Integer

				writeInteger(this.InspectionType_ID, dos);

				// Integer

				writeInteger(this.Business_ID_SK, dos);

				// Integer

				writeInteger(this.Location_SK, dos);

				// Integer

				writeInteger(this.Inspection_SK, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("BusinessId=" + BusinessId);
			sb.append(",Name=" + Name);
			sb.append(",Address=" + Address);
			sb.append(",City=" + City);
			sb.append(",State=" + State);
			sb.append(",ZipCode=" + ZipCode);
			sb.append(",PhoneNumber=" + PhoneNumber);
			sb.append(",InspectionId=" + InspectionId);
			sb.append(",Date=" + String.valueOf(Date));
			sb.append(",InspectionType=" + InspectionType);
			sb.append(",Location=" + Location);
			sb.append(",Latitude=" + Latitude);
			sb.append(",Longitude=" + Longitude);
			sb.append(",DI_CreatedDate=" + String.valueOf(DI_CreatedDate));
			sb.append(",DI_WorkflowFileName=" + DI_WorkflowFileName);
			sb.append(",DI_Workflow_ProcessID=" + DI_Workflow_ProcessID);
			sb.append(",Date_SK=" + Date_SK);
			sb.append(",InspectionType_ID=" + String.valueOf(InspectionType_ID));
			sb.append(",Business_ID_SK=" + String.valueOf(Business_ID_SK));
			sb.append(",Location_SK=" + String.valueOf(Location_SK));
			sb.append(",Inspection_SK=" + String.valueOf(Inspection_SK));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (BusinessId == null) {
				sb.append("<null>");
			} else {
				sb.append(BusinessId);
			}

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (Address == null) {
				sb.append("<null>");
			} else {
				sb.append(Address);
			}

			sb.append("|");

			if (City == null) {
				sb.append("<null>");
			} else {
				sb.append(City);
			}

			sb.append("|");

			if (State == null) {
				sb.append("<null>");
			} else {
				sb.append(State);
			}

			sb.append("|");

			if (ZipCode == null) {
				sb.append("<null>");
			} else {
				sb.append(ZipCode);
			}

			sb.append("|");

			if (PhoneNumber == null) {
				sb.append("<null>");
			} else {
				sb.append(PhoneNumber);
			}

			sb.append("|");

			if (InspectionId == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionId);
			}

			sb.append("|");

			if (Date == null) {
				sb.append("<null>");
			} else {
				sb.append(Date);
			}

			sb.append("|");

			if (InspectionType == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionType);
			}

			sb.append("|");

			if (Location == null) {
				sb.append("<null>");
			} else {
				sb.append(Location);
			}

			sb.append("|");

			if (Latitude == null) {
				sb.append("<null>");
			} else {
				sb.append(Latitude);
			}

			sb.append("|");

			if (Longitude == null) {
				sb.append("<null>");
			} else {
				sb.append(Longitude);
			}

			sb.append("|");

			if (DI_CreatedDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreatedDate);
			}

			sb.append("|");

			if (DI_WorkflowFileName == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_WorkflowFileName);
			}

			sb.append("|");

			if (DI_Workflow_ProcessID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Workflow_ProcessID);
			}

			sb.append("|");

			if (Date_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Date_SK);
			}

			sb.append("|");

			if (InspectionType_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionType_ID);
			}

			sb.append("|");

			if (Business_ID_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Business_ID_SK);
			}

			sb.append("|");

			if (Location_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Location_SK);
			}

			sb.append("|");

			if (Inspection_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Inspection_SK);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row12Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class after_tHashInput_3Struct implements routines.system.IPersistableRow<after_tHashInput_3Struct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];

		public String BusinessId;

		public String getBusinessId() {
			return this.BusinessId;
		}

		public Boolean BusinessIdIsNullable() {
			return true;
		}

		public Boolean BusinessIdIsKey() {
			return false;
		}

		public Integer BusinessIdLength() {
			return 9;
		}

		public Integer BusinessIdPrecision() {
			return 0;
		}

		public String BusinessIdDefault() {

			return null;

		}

		public String BusinessIdComment() {

			return "";

		}

		public String BusinessIdPattern() {

			return "";

		}

		public String BusinessIdOriginalDbColumnName() {

			return "BusinessId";

		}

		public String Name;

		public String getName() {
			return this.Name;
		}

		public Boolean NameIsNullable() {
			return true;
		}

		public Boolean NameIsKey() {
			return false;
		}

		public Integer NameLength() {
			return 70;
		}

		public Integer NamePrecision() {
			return 0;
		}

		public String NameDefault() {

			return null;

		}

		public String NameComment() {

			return "";

		}

		public String NamePattern() {

			return "";

		}

		public String NameOriginalDbColumnName() {

			return "Name";

		}

		public String Address;

		public String getAddress() {
			return this.Address;
		}

		public Boolean AddressIsNullable() {
			return true;
		}

		public Boolean AddressIsKey() {
			return false;
		}

		public Integer AddressLength() {
			return 40;
		}

		public Integer AddressPrecision() {
			return 0;
		}

		public String AddressDefault() {

			return null;

		}

		public String AddressComment() {

			return "";

		}

		public String AddressPattern() {

			return "";

		}

		public String AddressOriginalDbColumnName() {

			return "Address";

		}

		public String City;

		public String getCity() {
			return this.City;
		}

		public Boolean CityIsNullable() {
			return true;
		}

		public Boolean CityIsKey() {
			return false;
		}

		public Integer CityLength() {
			return 20;
		}

		public Integer CityPrecision() {
			return 0;
		}

		public String CityDefault() {

			return null;

		}

		public String CityComment() {

			return "";

		}

		public String CityPattern() {

			return "";

		}

		public String CityOriginalDbColumnName() {

			return "City";

		}

		public String State;

		public String getState() {
			return this.State;
		}

		public Boolean StateIsNullable() {
			return true;
		}

		public Boolean StateIsKey() {
			return false;
		}

		public Integer StateLength() {
			return 2;
		}

		public Integer StatePrecision() {
			return 0;
		}

		public String StateDefault() {

			return null;

		}

		public String StateComment() {

			return "";

		}

		public String StatePattern() {

			return "";

		}

		public String StateOriginalDbColumnName() {

			return "State";

		}

		public String ZipCode;

		public String getZipCode() {
			return this.ZipCode;
		}

		public Boolean ZipCodeIsNullable() {
			return true;
		}

		public Boolean ZipCodeIsKey() {
			return false;
		}

		public Integer ZipCodeLength() {
			return 10;
		}

		public Integer ZipCodePrecision() {
			return 0;
		}

		public String ZipCodeDefault() {

			return null;

		}

		public String ZipCodeComment() {

			return "";

		}

		public String ZipCodePattern() {

			return "";

		}

		public String ZipCodeOriginalDbColumnName() {

			return "ZipCode";

		}

		public String PhoneNumber;

		public String getPhoneNumber() {
			return this.PhoneNumber;
		}

		public Boolean PhoneNumberIsNullable() {
			return true;
		}

		public Boolean PhoneNumberIsKey() {
			return false;
		}

		public Integer PhoneNumberLength() {
			return 13;
		}

		public Integer PhoneNumberPrecision() {
			return 0;
		}

		public String PhoneNumberDefault() {

			return null;

		}

		public String PhoneNumberComment() {

			return "";

		}

		public String PhoneNumberPattern() {

			return "";

		}

		public String PhoneNumberOriginalDbColumnName() {

			return "PhoneNumber";

		}

		public String InspectionId;

		public String getInspectionId() {
			return this.InspectionId;
		}

		public Boolean InspectionIdIsNullable() {
			return true;
		}

		public Boolean InspectionIdIsKey() {
			return false;
		}

		public Integer InspectionIdLength() {
			return 9;
		}

		public Integer InspectionIdPrecision() {
			return 0;
		}

		public String InspectionIdDefault() {

			return null;

		}

		public String InspectionIdComment() {

			return "";

		}

		public String InspectionIdPattern() {

			return "";

		}

		public String InspectionIdOriginalDbColumnName() {

			return "InspectionId";

		}

		public java.util.Date Date;

		public java.util.Date getDate() {
			return this.Date;
		}

		public Boolean DateIsNullable() {
			return true;
		}

		public Boolean DateIsKey() {
			return false;
		}

		public Integer DateLength() {
			return 19;
		}

		public Integer DatePrecision() {
			return 0;
		}

		public String DateDefault() {

			return null;

		}

		public String DateComment() {

			return "";

		}

		public String DatePattern() {

			return "dd-MM-yyyy";

		}

		public String DateOriginalDbColumnName() {

			return "Date";

		}

		public String InspectionType;

		public String getInspectionType() {
			return this.InspectionType;
		}

		public Boolean InspectionTypeIsNullable() {
			return true;
		}

		public Boolean InspectionTypeIsKey() {
			return false;
		}

		public Integer InspectionTypeLength() {
			return 9;
		}

		public Integer InspectionTypePrecision() {
			return 0;
		}

		public String InspectionTypeDefault() {

			return null;

		}

		public String InspectionTypeComment() {

			return "";

		}

		public String InspectionTypePattern() {

			return "";

		}

		public String InspectionTypeOriginalDbColumnName() {

			return "InspectionType";

		}

		public String Location;

		public String getLocation() {
			return this.Location;
		}

		public Boolean LocationIsNullable() {
			return true;
		}

		public Boolean LocationIsKey() {
			return false;
		}

		public Integer LocationLength() {
			return 100;
		}

		public Integer LocationPrecision() {
			return 0;
		}

		public String LocationDefault() {

			return null;

		}

		public String LocationComment() {

			return "";

		}

		public String LocationPattern() {

			return "";

		}

		public String LocationOriginalDbColumnName() {

			return "Location";

		}

		public String Latitude;

		public String getLatitude() {
			return this.Latitude;
		}

		public Boolean LatitudeIsNullable() {
			return true;
		}

		public Boolean LatitudeIsKey() {
			return false;
		}

		public Integer LatitudeLength() {
			return 10;
		}

		public Integer LatitudePrecision() {
			return null;
		}

		public String LatitudeDefault() {

			return null;

		}

		public String LatitudeComment() {

			return "";

		}

		public String LatitudePattern() {

			return "";

		}

		public String LatitudeOriginalDbColumnName() {

			return "Latitude";

		}

		public String Longitude;

		public String getLongitude() {
			return this.Longitude;
		}

		public Boolean LongitudeIsNullable() {
			return true;
		}

		public Boolean LongitudeIsKey() {
			return false;
		}

		public Integer LongitudeLength() {
			return 10;
		}

		public Integer LongitudePrecision() {
			return null;
		}

		public String LongitudeDefault() {

			return null;

		}

		public String LongitudeComment() {

			return "";

		}

		public String LongitudePattern() {

			return "";

		}

		public String LongitudeOriginalDbColumnName() {

			return "Longitude";

		}

		public java.util.Date DI_CreatedDate;

		public java.util.Date getDI_CreatedDate() {
			return this.DI_CreatedDate;
		}

		public Boolean DI_CreatedDateIsNullable() {
			return true;
		}

		public Boolean DI_CreatedDateIsKey() {
			return false;
		}

		public Integer DI_CreatedDateLength() {
			return 19;
		}

		public Integer DI_CreatedDatePrecision() {
			return 0;
		}

		public String DI_CreatedDateDefault() {

			return null;

		}

		public String DI_CreatedDateComment() {

			return "";

		}

		public String DI_CreatedDatePattern() {

			return "dd-MM-yyyy";

		}

		public String DI_CreatedDateOriginalDbColumnName() {

			return "DI_CreatedDate";

		}

		public String DI_WorkflowFileName;

		public String getDI_WorkflowFileName() {
			return this.DI_WorkflowFileName;
		}

		public Boolean DI_WorkflowFileNameIsNullable() {
			return true;
		}

		public Boolean DI_WorkflowFileNameIsKey() {
			return false;
		}

		public Integer DI_WorkflowFileNameLength() {
			return 255;
		}

		public Integer DI_WorkflowFileNamePrecision() {
			return 0;
		}

		public String DI_WorkflowFileNameDefault() {

			return null;

		}

		public String DI_WorkflowFileNameComment() {

			return "";

		}

		public String DI_WorkflowFileNamePattern() {

			return "";

		}

		public String DI_WorkflowFileNameOriginalDbColumnName() {

			return "DI_WorkflowFileName";

		}

		public String DI_Workflow_ProcessID;

		public String getDI_Workflow_ProcessID() {
			return this.DI_Workflow_ProcessID;
		}

		public Boolean DI_Workflow_ProcessIDIsNullable() {
			return true;
		}

		public Boolean DI_Workflow_ProcessIDIsKey() {
			return false;
		}

		public Integer DI_Workflow_ProcessIDLength() {
			return 30;
		}

		public Integer DI_Workflow_ProcessIDPrecision() {
			return 0;
		}

		public String DI_Workflow_ProcessIDDefault() {

			return null;

		}

		public String DI_Workflow_ProcessIDComment() {

			return "";

		}

		public String DI_Workflow_ProcessIDPattern() {

			return "";

		}

		public String DI_Workflow_ProcessIDOriginalDbColumnName() {

			return "DI_Workflow_ProcessID";

		}

		public String Date_SK;

		public String getDate_SK() {
			return this.Date_SK;
		}

		public Boolean Date_SKIsNullable() {
			return true;
		}

		public Boolean Date_SKIsKey() {
			return false;
		}

		public Integer Date_SKLength() {
			return null;
		}

		public Integer Date_SKPrecision() {
			return null;
		}

		public String Date_SKDefault() {

			return null;

		}

		public String Date_SKComment() {

			return "";

		}

		public String Date_SKPattern() {

			return "";

		}

		public String Date_SKOriginalDbColumnName() {

			return "Date_SK";

		}

		public Integer InspectionType_ID;

		public Integer getInspectionType_ID() {
			return this.InspectionType_ID;
		}

		public Boolean InspectionType_IDIsNullable() {
			return true;
		}

		public Boolean InspectionType_IDIsKey() {
			return false;
		}

		public Integer InspectionType_IDLength() {
			return null;
		}

		public Integer InspectionType_IDPrecision() {
			return null;
		}

		public String InspectionType_IDDefault() {

			return null;

		}

		public String InspectionType_IDComment() {

			return "";

		}

		public String InspectionType_IDPattern() {

			return "";

		}

		public String InspectionType_IDOriginalDbColumnName() {

			return "InspectionType_ID";

		}

		public Integer Business_ID_SK;

		public Integer getBusiness_ID_SK() {
			return this.Business_ID_SK;
		}

		public Boolean Business_ID_SKIsNullable() {
			return true;
		}

		public Boolean Business_ID_SKIsKey() {
			return false;
		}

		public Integer Business_ID_SKLength() {
			return null;
		}

		public Integer Business_ID_SKPrecision() {
			return null;
		}

		public String Business_ID_SKDefault() {

			return null;

		}

		public String Business_ID_SKComment() {

			return "";

		}

		public String Business_ID_SKPattern() {

			return "";

		}

		public String Business_ID_SKOriginalDbColumnName() {

			return "Business_ID_SK";

		}

		public Integer Location_SK;

		public Integer getLocation_SK() {
			return this.Location_SK;
		}

		public Boolean Location_SKIsNullable() {
			return true;
		}

		public Boolean Location_SKIsKey() {
			return false;
		}

		public Integer Location_SKLength() {
			return null;
		}

		public Integer Location_SKPrecision() {
			return null;
		}

		public String Location_SKDefault() {

			return null;

		}

		public String Location_SKComment() {

			return "";

		}

		public String Location_SKPattern() {

			return "";

		}

		public String Location_SKOriginalDbColumnName() {

			return "Location_SK";

		}

		public Integer Inspection_SK;

		public Integer getInspection_SK() {
			return this.Inspection_SK;
		}

		public Boolean Inspection_SKIsNullable() {
			return true;
		}

		public Boolean Inspection_SKIsKey() {
			return false;
		}

		public Integer Inspection_SKLength() {
			return null;
		}

		public Integer Inspection_SKPrecision() {
			return null;
		}

		public String Inspection_SKDefault() {

			return null;

		}

		public String Inspection_SKComment() {

			return "";

		}

		public String Inspection_SKPattern() {

			return "";

		}

		public String Inspection_SKOriginalDbColumnName() {

			return "Inspection_SK";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.BusinessId = readString(dis);

					this.Name = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.State = readString(dis);

					this.ZipCode = readString(dis);

					this.PhoneNumber = readString(dis);

					this.InspectionId = readString(dis);

					this.Date = readDate(dis);

					this.InspectionType = readString(dis);

					this.Location = readString(dis);

					this.Latitude = readString(dis);

					this.Longitude = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

					this.Date_SK = readString(dis);

					this.InspectionType_ID = readInteger(dis);

					this.Business_ID_SK = readInteger(dis);

					this.Location_SK = readInteger(dis);

					this.Inspection_SK = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.BusinessId = readString(dis);

					this.Name = readString(dis);

					this.Address = readString(dis);

					this.City = readString(dis);

					this.State = readString(dis);

					this.ZipCode = readString(dis);

					this.PhoneNumber = readString(dis);

					this.InspectionId = readString(dis);

					this.Date = readDate(dis);

					this.InspectionType = readString(dis);

					this.Location = readString(dis);

					this.Latitude = readString(dis);

					this.Longitude = readString(dis);

					this.DI_CreatedDate = readDate(dis);

					this.DI_WorkflowFileName = readString(dis);

					this.DI_Workflow_ProcessID = readString(dis);

					this.Date_SK = readString(dis);

					this.InspectionType_ID = readInteger(dis);

					this.Business_ID_SK = readInteger(dis);

					this.Location_SK = readInteger(dis);

					this.Inspection_SK = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.BusinessId, dos);

				// String

				writeString(this.Name, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.State, dos);

				// String

				writeString(this.ZipCode, dos);

				// String

				writeString(this.PhoneNumber, dos);

				// String

				writeString(this.InspectionId, dos);

				// java.util.Date

				writeDate(this.Date, dos);

				// String

				writeString(this.InspectionType, dos);

				// String

				writeString(this.Location, dos);

				// String

				writeString(this.Latitude, dos);

				// String

				writeString(this.Longitude, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

				// String

				writeString(this.Date_SK, dos);

				// Integer

				writeInteger(this.InspectionType_ID, dos);

				// Integer

				writeInteger(this.Business_ID_SK, dos);

				// Integer

				writeInteger(this.Location_SK, dos);

				// Integer

				writeInteger(this.Inspection_SK, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.BusinessId, dos);

				// String

				writeString(this.Name, dos);

				// String

				writeString(this.Address, dos);

				// String

				writeString(this.City, dos);

				// String

				writeString(this.State, dos);

				// String

				writeString(this.ZipCode, dos);

				// String

				writeString(this.PhoneNumber, dos);

				// String

				writeString(this.InspectionId, dos);

				// java.util.Date

				writeDate(this.Date, dos);

				// String

				writeString(this.InspectionType, dos);

				// String

				writeString(this.Location, dos);

				// String

				writeString(this.Latitude, dos);

				// String

				writeString(this.Longitude, dos);

				// java.util.Date

				writeDate(this.DI_CreatedDate, dos);

				// String

				writeString(this.DI_WorkflowFileName, dos);

				// String

				writeString(this.DI_Workflow_ProcessID, dos);

				// String

				writeString(this.Date_SK, dos);

				// Integer

				writeInteger(this.InspectionType_ID, dos);

				// Integer

				writeInteger(this.Business_ID_SK, dos);

				// Integer

				writeInteger(this.Location_SK, dos);

				// Integer

				writeInteger(this.Inspection_SK, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("BusinessId=" + BusinessId);
			sb.append(",Name=" + Name);
			sb.append(",Address=" + Address);
			sb.append(",City=" + City);
			sb.append(",State=" + State);
			sb.append(",ZipCode=" + ZipCode);
			sb.append(",PhoneNumber=" + PhoneNumber);
			sb.append(",InspectionId=" + InspectionId);
			sb.append(",Date=" + String.valueOf(Date));
			sb.append(",InspectionType=" + InspectionType);
			sb.append(",Location=" + Location);
			sb.append(",Latitude=" + Latitude);
			sb.append(",Longitude=" + Longitude);
			sb.append(",DI_CreatedDate=" + String.valueOf(DI_CreatedDate));
			sb.append(",DI_WorkflowFileName=" + DI_WorkflowFileName);
			sb.append(",DI_Workflow_ProcessID=" + DI_Workflow_ProcessID);
			sb.append(",Date_SK=" + Date_SK);
			sb.append(",InspectionType_ID=" + String.valueOf(InspectionType_ID));
			sb.append(",Business_ID_SK=" + String.valueOf(Business_ID_SK));
			sb.append(",Location_SK=" + String.valueOf(Location_SK));
			sb.append(",Inspection_SK=" + String.valueOf(Inspection_SK));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (BusinessId == null) {
				sb.append("<null>");
			} else {
				sb.append(BusinessId);
			}

			sb.append("|");

			if (Name == null) {
				sb.append("<null>");
			} else {
				sb.append(Name);
			}

			sb.append("|");

			if (Address == null) {
				sb.append("<null>");
			} else {
				sb.append(Address);
			}

			sb.append("|");

			if (City == null) {
				sb.append("<null>");
			} else {
				sb.append(City);
			}

			sb.append("|");

			if (State == null) {
				sb.append("<null>");
			} else {
				sb.append(State);
			}

			sb.append("|");

			if (ZipCode == null) {
				sb.append("<null>");
			} else {
				sb.append(ZipCode);
			}

			sb.append("|");

			if (PhoneNumber == null) {
				sb.append("<null>");
			} else {
				sb.append(PhoneNumber);
			}

			sb.append("|");

			if (InspectionId == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionId);
			}

			sb.append("|");

			if (Date == null) {
				sb.append("<null>");
			} else {
				sb.append(Date);
			}

			sb.append("|");

			if (InspectionType == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionType);
			}

			sb.append("|");

			if (Location == null) {
				sb.append("<null>");
			} else {
				sb.append(Location);
			}

			sb.append("|");

			if (Latitude == null) {
				sb.append("<null>");
			} else {
				sb.append(Latitude);
			}

			sb.append("|");

			if (Longitude == null) {
				sb.append("<null>");
			} else {
				sb.append(Longitude);
			}

			sb.append("|");

			if (DI_CreatedDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreatedDate);
			}

			sb.append("|");

			if (DI_WorkflowFileName == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_WorkflowFileName);
			}

			sb.append("|");

			if (DI_Workflow_ProcessID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_Workflow_ProcessID);
			}

			sb.append("|");

			if (Date_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Date_SK);
			}

			sb.append("|");

			if (InspectionType_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionType_ID);
			}

			sb.append("|");

			if (Business_ID_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Business_ID_SK);
			}

			sb.append("|");

			if (Location_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Location_SK);
			}

			sb.append("|");

			if (Inspection_SK == null) {
				sb.append("<null>");
			} else {
				sb.append(Inspection_SK);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(after_tHashInput_3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tHashInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tHashInput_3_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tHashInput_3");
		org.slf4j.MDC.put("_subJobPid", "8sjj7C_" + subJobPidCounter.getAndIncrement());

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				tHashInput_4Process(globalMap);

				row12Struct row12 = new row12Struct();
				DimDateStruct DimDate = new DimDateStruct();
				row8Struct row8 = new row8Struct();
				DimInspectionTypeStruct DimInspectionType = new DimInspectionTypeStruct();
				row7Struct row7 = new row7Struct();
				DimLocationStruct DimLocation = new DimLocationStruct();
				row6Struct row6 = new row6Struct();
				DimViolationStruct DimViolation = new DimViolationStruct();
				row14Struct row14 = new row14Struct();
				DimBusinessStruct DimBusiness = new DimBusinessStruct();
				row5Struct row5 = new row5Struct();

				/**
				 * [tDBOutput_1 begin ] start
				 */

				ok_Hash.put("tDBOutput_1", false);
				start_Hash.put("tDBOutput_1", System.currentTimeMillis());

				currentComponent = "tDBOutput_1";

				cLabel = "ProcessingMySQL";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row8");

				int tos_count_tDBOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
							log4jParamters_tDBOutput_1.append("Parameters:");
							log4jParamters_tDBOutput_1.append("DB_VERSION" + " = " + "MYSQL_8");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("HOST" + " = " + "\"127.0.0.1\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PORT" + " = " + "\"3306\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DBNAME" + " = " + "\"food_inspections\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USER" + " = " + "\"user2\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:zPsRt4Ew8fc44bwPY2xDg6N98USP5hvKbeOgDXqhbuOOaNL7")
									.substring(0, 4) + "...");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"dim_date\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "DROP_IF_EXISTS_AND_CREATE");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PROPERTIES" + " = "
									+ "\"noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("EXTENDINSERT" + " = " + "true");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("NB_ROWS_PER_INSERT" + " = " + "100");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_HINT_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ON_DUPLICATE_KEY_UPDATE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
							log4jParamters_tDBOutput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_1 - " + (log4jParamters_tDBOutput_1));
						}
					}
					new BytesLimit65535_tDBOutput_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_1", "ProcessingMySQL", "tMysqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_1 = 0;
				int nb_line_update_tDBOutput_1 = 0;
				int nb_line_inserted_tDBOutput_1 = 0;
				int nb_line_deleted_tDBOutput_1 = 0;
				int nb_line_rejected_tDBOutput_1 = 0;

				int deletedCount_tDBOutput_1 = 0;
				int updatedCount_tDBOutput_1 = 0;
				int insertedCount_tDBOutput_1 = 0;
				int rowsToCommitCount_tDBOutput_1 = 0;
				int rejectedCount_tDBOutput_1 = 0;

				String tableName_tDBOutput_1 = "dim_date";
				boolean whetherReject_tDBOutput_1 = false;

				java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
				calendar_tDBOutput_1.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
				calendar_tDBOutput_1.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
				long date_tDBOutput_1;

				java.sql.Connection conn_tDBOutput_1 = null;

				String properties_tDBOutput_1 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBOutput_1 == null || properties_tDBOutput_1.trim().length() == 0) {
					properties_tDBOutput_1 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
				} else {
					if (!properties_tDBOutput_1.contains("rewriteBatchedStatements=")) {
						properties_tDBOutput_1 += "&rewriteBatchedStatements=true";
					}

					if (!properties_tDBOutput_1.contains("allowLoadLocalInfile=")) {
						properties_tDBOutput_1 += "&allowLoadLocalInfile=true";
					}
				}

				String url_tDBOutput_1 = "jdbc:mysql://" + "127.0.0.1" + ":" + "3306" + "/" + "food_inspections" + "?"
						+ properties_tDBOutput_1;

				String driverClass_tDBOutput_1 = "com.mysql.cj.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_1) + ("."));
				String dbUser_tDBOutput_1 = "user2";

				final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:kvS3cSAprAq5SQb04uy9NLcnioo3l1ndeIoFaaoujLxm5Ij4");

				String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;
				java.lang.Class.forName(driverClass_tDBOutput_1);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection attempts to '") + (url_tDBOutput_1)
							+ ("' with the username '") + (dbUser_tDBOutput_1) + ("'."));
				conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1, dbUser_tDBOutput_1,
						dbPwd_tDBOutput_1);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection to '") + (url_tDBOutput_1) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);

				conn_tDBOutput_1.setAutoCommit(false);
				int commitEvery_tDBOutput_1 = 10000;
				int commitCounter_tDBOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_1.getAutoCommit()) + ("'."));

				int count_tDBOutput_1 = 0;

				java.sql.DatabaseMetaData dbMetaData_tDBOutput_1 = conn_tDBOutput_1.getMetaData();
				java.sql.ResultSet rsTable_tDBOutput_1 = dbMetaData_tDBOutput_1.getTables("food_inspections", null,
						null, new String[] { "TABLE" });
				boolean whetherExist_tDBOutput_1 = false;
				while (rsTable_tDBOutput_1.next()) {
					String table_tDBOutput_1 = rsTable_tDBOutput_1.getString("TABLE_NAME");
					if (table_tDBOutput_1.equalsIgnoreCase("dim_date")) {
						whetherExist_tDBOutput_1 = true;
						break;
					}
				}
				if (whetherExist_tDBOutput_1) {
					try (java.sql.Statement stmtDrop_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
						if (log.isDebugEnabled())
							log.debug(
									"tDBOutput_1 - " + ("Dropping") + (" table '") + (tableName_tDBOutput_1) + ("'."));
						stmtDrop_tDBOutput_1.execute("DROP TABLE `" + tableName_tDBOutput_1 + "`");
						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("Drop") + (" table '") + (tableName_tDBOutput_1)
									+ ("' has succeeded."));
					}
				}
				try (java.sql.Statement stmtCreate_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Creating") + (" table '") + (tableName_tDBOutput_1) + ("'."));
					stmtCreate_tDBOutput_1.execute("CREATE TABLE `" + tableName_tDBOutput_1
							+ "`(`Date_SK` VARCHAR(8)  ,`Year` INT(0)  ,`Day` INT(0)  ,`Day_Of_Week` VARCHAR(10)  ,`Month` INT(0)  ,`Date` DATETIME ,`DI_CreatedDate` DATETIME ,`DI_WorkflowFileName` VARCHAR(255)  ,`DI_Workflow_ProcessID` VARCHAR(30)  )");
					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Create") + (" table '") + (tableName_tDBOutput_1)
								+ ("' has succeeded."));
				}

				String insert_tDBOutput_1 = "INSERT INTO `" + "dim_date"
						+ "` (`Date_SK`,`Year`,`Day`,`Day_Of_Week`,`Month`,`Date`,`DI_CreatedDate`,`DI_WorkflowFileName`,`DI_Workflow_ProcessID`) VALUES (?,?,?,?,?,?,?,?,?)";

				int batchSize_tDBOutput_1 = 100;
				int batchSizeCounter_tDBOutput_1 = 0;

				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);

				/**
				 * [tDBOutput_1 begin ] stop
				 */

				/**
				 * [tUniqRow_4 begin ] start
				 */

				ok_Hash.put("tUniqRow_4", false);
				start_Hash.put("tUniqRow_4", System.currentTimeMillis());

				currentComponent = "tUniqRow_4";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "DimDate");

				int tos_count_tUniqRow_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_4 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_4 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_4 = new StringBuilder();
							log4jParamters_tUniqRow_4.append("Parameters:");
							log4jParamters_tUniqRow_4.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("true") + ", SCHEMA_COLUMN=" + ("Date_SK")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Year") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("Day")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Day_Of_Week") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("Month")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Date") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("DI_CreatedDate")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("DI_WorkflowFileName") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("DI_Workflow_ProcessID")
									+ "}]");
							log4jParamters_tUniqRow_4.append(" | ");
							log4jParamters_tUniqRow_4.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_4.append(" | ");
							log4jParamters_tUniqRow_4.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_4.append(" | ");
							log4jParamters_tUniqRow_4.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_4.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_4 - " + (log4jParamters_tUniqRow_4));
						}
					}
					new BytesLimit65535_tUniqRow_4().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_4", "tUniqRow_4", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_4 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String Date_SK;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + ((this.Date_SK == null) ? 0 : this.Date_SK.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_4 other = (KeyStruct_tUniqRow_4) obj;

						if (this.Date_SK == null) {
							if (other.Date_SK != null)
								return false;

						} else if (!this.Date_SK.equals(other.Date_SK))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_4 = 0;
				int nb_duplicates_tUniqRow_4 = 0;
				log.debug("tUniqRow_4 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_4 finder_tUniqRow_4 = new KeyStruct_tUniqRow_4();
				java.util.Set<KeyStruct_tUniqRow_4> keystUniqRow_4 = new java.util.HashSet<KeyStruct_tUniqRow_4>();

				/**
				 * [tUniqRow_4 begin ] stop
				 */

				/**
				 * [tDBOutput_2 begin ] start
				 */

				ok_Hash.put("tDBOutput_2", false);
				start_Hash.put("tDBOutput_2", System.currentTimeMillis());

				currentComponent = "tDBOutput_2";

				cLabel = "ProcessingMySQL";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row7");

				int tos_count_tDBOutput_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_2 = new StringBuilder();
							log4jParamters_tDBOutput_2.append("Parameters:");
							log4jParamters_tDBOutput_2.append("DB_VERSION" + " = " + "MYSQL_8");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("HOST" + " = " + "\"127.0.0.1\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("PORT" + " = " + "\"3306\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DBNAME" + " = " + "\"food_inspections\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("USER" + " = " + "\"user2\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:2T7gIakPZgQjoTC+NMhrFoK90V+sjtfOfM6Q7nlSlRA5zUPb")
									.substring(0, 4) + "...");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("TABLE" + " = " + "\"dim_inspection_type\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("TABLE_ACTION" + " = " + "DROP_IF_EXISTS_AND_CREATE");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("PROPERTIES" + " = "
									+ "\"noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1\"");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("EXTENDINSERT" + " = " + "true");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("NB_ROWS_PER_INSERT" + " = " + "100");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("USE_HINT_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("ON_DUPLICATE_KEY_UPDATE" + " = " + "false");
							log4jParamters_tDBOutput_2.append(" | ");
							log4jParamters_tDBOutput_2.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
							log4jParamters_tDBOutput_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_2 - " + (log4jParamters_tDBOutput_2));
						}
					}
					new BytesLimit65535_tDBOutput_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_2", "ProcessingMySQL", "tMysqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_2 = 0;
				int nb_line_update_tDBOutput_2 = 0;
				int nb_line_inserted_tDBOutput_2 = 0;
				int nb_line_deleted_tDBOutput_2 = 0;
				int nb_line_rejected_tDBOutput_2 = 0;

				int deletedCount_tDBOutput_2 = 0;
				int updatedCount_tDBOutput_2 = 0;
				int insertedCount_tDBOutput_2 = 0;
				int rowsToCommitCount_tDBOutput_2 = 0;
				int rejectedCount_tDBOutput_2 = 0;

				String tableName_tDBOutput_2 = "dim_inspection_type";
				boolean whetherReject_tDBOutput_2 = false;

				java.util.Calendar calendar_tDBOutput_2 = java.util.Calendar.getInstance();
				calendar_tDBOutput_2.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_2 = calendar_tDBOutput_2.getTime().getTime();
				calendar_tDBOutput_2.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_2 = calendar_tDBOutput_2.getTime().getTime();
				long date_tDBOutput_2;

				java.sql.Connection conn_tDBOutput_2 = null;

				String properties_tDBOutput_2 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBOutput_2 == null || properties_tDBOutput_2.trim().length() == 0) {
					properties_tDBOutput_2 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
				} else {
					if (!properties_tDBOutput_2.contains("rewriteBatchedStatements=")) {
						properties_tDBOutput_2 += "&rewriteBatchedStatements=true";
					}

					if (!properties_tDBOutput_2.contains("allowLoadLocalInfile=")) {
						properties_tDBOutput_2 += "&allowLoadLocalInfile=true";
					}
				}

				String url_tDBOutput_2 = "jdbc:mysql://" + "127.0.0.1" + ":" + "3306" + "/" + "food_inspections" + "?"
						+ properties_tDBOutput_2;

				String driverClass_tDBOutput_2 = "com.mysql.cj.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_2) + ("."));
				String dbUser_tDBOutput_2 = "user2";

				final String decryptedPassword_tDBOutput_2 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:gFJhR0yTlxjdsYxGXxKaE9HgZtxl6RilRHbYSAa4UvbeigPZ");

				String dbPwd_tDBOutput_2 = decryptedPassword_tDBOutput_2;
				java.lang.Class.forName(driverClass_tDBOutput_2);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Connection attempts to '") + (url_tDBOutput_2)
							+ ("' with the username '") + (dbUser_tDBOutput_2) + ("'."));
				conn_tDBOutput_2 = java.sql.DriverManager.getConnection(url_tDBOutput_2, dbUser_tDBOutput_2,
						dbPwd_tDBOutput_2);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Connection to '") + (url_tDBOutput_2) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_2", conn_tDBOutput_2);

				conn_tDBOutput_2.setAutoCommit(false);
				int commitEvery_tDBOutput_2 = 10000;
				int commitCounter_tDBOutput_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_2.getAutoCommit()) + ("'."));

				int count_tDBOutput_2 = 0;

				java.sql.DatabaseMetaData dbMetaData_tDBOutput_2 = conn_tDBOutput_2.getMetaData();
				java.sql.ResultSet rsTable_tDBOutput_2 = dbMetaData_tDBOutput_2.getTables("food_inspections", null,
						null, new String[] { "TABLE" });
				boolean whetherExist_tDBOutput_2 = false;
				while (rsTable_tDBOutput_2.next()) {
					String table_tDBOutput_2 = rsTable_tDBOutput_2.getString("TABLE_NAME");
					if (table_tDBOutput_2.equalsIgnoreCase("dim_inspection_type")) {
						whetherExist_tDBOutput_2 = true;
						break;
					}
				}
				if (whetherExist_tDBOutput_2) {
					try (java.sql.Statement stmtDrop_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
						if (log.isDebugEnabled())
							log.debug(
									"tDBOutput_2 - " + ("Dropping") + (" table '") + (tableName_tDBOutput_2) + ("'."));
						stmtDrop_tDBOutput_2.execute("DROP TABLE `" + tableName_tDBOutput_2 + "`");
						if (log.isDebugEnabled())
							log.debug("tDBOutput_2 - " + ("Drop") + (" table '") + (tableName_tDBOutput_2)
									+ ("' has succeeded."));
					}
				}
				try (java.sql.Statement stmtCreate_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
					if (log.isDebugEnabled())
						log.debug("tDBOutput_2 - " + ("Creating") + (" table '") + (tableName_tDBOutput_2) + ("'."));
					stmtCreate_tDBOutput_2.execute("CREATE TABLE `" + tableName_tDBOutput_2
							+ "`(`InspectionType_ID` INT(0)  ,`InspectionType` VARCHAR(9)  ,`DI_CreatedDate` DATETIME ,`DI_WorkflowFileName` VARCHAR(255)  ,`DI_Workflow_ProcessID` VARCHAR(30)  )");
					if (log.isDebugEnabled())
						log.debug("tDBOutput_2 - " + ("Create") + (" table '") + (tableName_tDBOutput_2)
								+ ("' has succeeded."));
				}

				String insert_tDBOutput_2 = "INSERT INTO `" + "dim_inspection_type"
						+ "` (`InspectionType_ID`,`InspectionType`,`DI_CreatedDate`,`DI_WorkflowFileName`,`DI_Workflow_ProcessID`) VALUES (?,?,?,?,?)";

				int batchSize_tDBOutput_2 = 100;
				int batchSizeCounter_tDBOutput_2 = 0;

				java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
				resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);

				/**
				 * [tDBOutput_2 begin ] stop
				 */

				/**
				 * [tUniqRow_3 begin ] start
				 */

				ok_Hash.put("tUniqRow_3", false);
				start_Hash.put("tUniqRow_3", System.currentTimeMillis());

				currentComponent = "tUniqRow_3";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "DimInspectionType");

				int tos_count_tUniqRow_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_3 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_3 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_3 = new StringBuilder();
							log4jParamters_tUniqRow_3.append("Parameters:");
							log4jParamters_tUniqRow_3.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("InspectionType_ID")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("true")
									+ ", SCHEMA_COLUMN=" + ("InspectionType") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("DI_CreatedDate")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("DI_WorkflowFileName") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("DI_Workflow_ProcessID")
									+ "}]");
							log4jParamters_tUniqRow_3.append(" | ");
							log4jParamters_tUniqRow_3.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_3.append(" | ");
							log4jParamters_tUniqRow_3.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_3.append(" | ");
							log4jParamters_tUniqRow_3.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_3.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_3 - " + (log4jParamters_tUniqRow_3));
						}
					}
					new BytesLimit65535_tUniqRow_3().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_3", "tUniqRow_3", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_3 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String InspectionType;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result
									+ ((this.InspectionType == null) ? 0 : this.InspectionType.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_3 other = (KeyStruct_tUniqRow_3) obj;

						if (this.InspectionType == null) {
							if (other.InspectionType != null)
								return false;

						} else if (!this.InspectionType.equals(other.InspectionType))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_3 = 0;
				int nb_duplicates_tUniqRow_3 = 0;
				log.debug("tUniqRow_3 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_3 finder_tUniqRow_3 = new KeyStruct_tUniqRow_3();
				java.util.Set<KeyStruct_tUniqRow_3> keystUniqRow_3 = new java.util.HashSet<KeyStruct_tUniqRow_3>();

				/**
				 * [tUniqRow_3 begin ] stop
				 */

				/**
				 * [tDBOutput_3 begin ] start
				 */

				ok_Hash.put("tDBOutput_3", false);
				start_Hash.put("tDBOutput_3", System.currentTimeMillis());

				currentComponent = "tDBOutput_3";

				cLabel = "ProcessingMySQL";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row6");

				int tos_count_tDBOutput_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_3 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_3 = new StringBuilder();
							log4jParamters_tDBOutput_3.append("Parameters:");
							log4jParamters_tDBOutput_3.append("DB_VERSION" + " = " + "MYSQL_8");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("HOST" + " = " + "\"127.0.0.1\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("PORT" + " = " + "\"3306\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("DBNAME" + " = " + "\"food_inspections\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("USER" + " = " + "\"user2\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:nmKkJxG+LKKG/X3RvIKhv3g1LBfTmyQlF4DVG09pUADgmC+x")
									.substring(0, 4) + "...");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("TABLE" + " = " + "\"dim_location\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("TABLE_ACTION" + " = " + "DROP_IF_EXISTS_AND_CREATE");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("PROPERTIES" + " = "
									+ "\"noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1\"");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("EXTENDINSERT" + " = " + "true");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("NB_ROWS_PER_INSERT" + " = " + "100");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("USE_HINT_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("ON_DUPLICATE_KEY_UPDATE" + " = " + "false");
							log4jParamters_tDBOutput_3.append(" | ");
							log4jParamters_tDBOutput_3.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
							log4jParamters_tDBOutput_3.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_3 - " + (log4jParamters_tDBOutput_3));
						}
					}
					new BytesLimit65535_tDBOutput_3().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_3", "ProcessingMySQL", "tMysqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_3 = 0;
				int nb_line_update_tDBOutput_3 = 0;
				int nb_line_inserted_tDBOutput_3 = 0;
				int nb_line_deleted_tDBOutput_3 = 0;
				int nb_line_rejected_tDBOutput_3 = 0;

				int deletedCount_tDBOutput_3 = 0;
				int updatedCount_tDBOutput_3 = 0;
				int insertedCount_tDBOutput_3 = 0;
				int rowsToCommitCount_tDBOutput_3 = 0;
				int rejectedCount_tDBOutput_3 = 0;

				String tableName_tDBOutput_3 = "dim_location";
				boolean whetherReject_tDBOutput_3 = false;

				java.util.Calendar calendar_tDBOutput_3 = java.util.Calendar.getInstance();
				calendar_tDBOutput_3.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_3 = calendar_tDBOutput_3.getTime().getTime();
				calendar_tDBOutput_3.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_3 = calendar_tDBOutput_3.getTime().getTime();
				long date_tDBOutput_3;

				java.sql.Connection conn_tDBOutput_3 = null;

				String properties_tDBOutput_3 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBOutput_3 == null || properties_tDBOutput_3.trim().length() == 0) {
					properties_tDBOutput_3 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
				} else {
					if (!properties_tDBOutput_3.contains("rewriteBatchedStatements=")) {
						properties_tDBOutput_3 += "&rewriteBatchedStatements=true";
					}

					if (!properties_tDBOutput_3.contains("allowLoadLocalInfile=")) {
						properties_tDBOutput_3 += "&allowLoadLocalInfile=true";
					}
				}

				String url_tDBOutput_3 = "jdbc:mysql://" + "127.0.0.1" + ":" + "3306" + "/" + "food_inspections" + "?"
						+ properties_tDBOutput_3;

				String driverClass_tDBOutput_3 = "com.mysql.cj.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_3) + ("."));
				String dbUser_tDBOutput_3 = "user2";

				final String decryptedPassword_tDBOutput_3 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:+mWfGA/v8BWmthKeMLXw+fehukMY8og3niedJKud4sg0/YQG");

				String dbPwd_tDBOutput_3 = decryptedPassword_tDBOutput_3;
				java.lang.Class.forName(driverClass_tDBOutput_3);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Connection attempts to '") + (url_tDBOutput_3)
							+ ("' with the username '") + (dbUser_tDBOutput_3) + ("'."));
				conn_tDBOutput_3 = java.sql.DriverManager.getConnection(url_tDBOutput_3, dbUser_tDBOutput_3,
						dbPwd_tDBOutput_3);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Connection to '") + (url_tDBOutput_3) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_3", conn_tDBOutput_3);

				conn_tDBOutput_3.setAutoCommit(false);
				int commitEvery_tDBOutput_3 = 10000;
				int commitCounter_tDBOutput_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_3.getAutoCommit()) + ("'."));

				int count_tDBOutput_3 = 0;

				java.sql.DatabaseMetaData dbMetaData_tDBOutput_3 = conn_tDBOutput_3.getMetaData();
				java.sql.ResultSet rsTable_tDBOutput_3 = dbMetaData_tDBOutput_3.getTables("food_inspections", null,
						null, new String[] { "TABLE" });
				boolean whetherExist_tDBOutput_3 = false;
				while (rsTable_tDBOutput_3.next()) {
					String table_tDBOutput_3 = rsTable_tDBOutput_3.getString("TABLE_NAME");
					if (table_tDBOutput_3.equalsIgnoreCase("dim_location")) {
						whetherExist_tDBOutput_3 = true;
						break;
					}
				}
				if (whetherExist_tDBOutput_3) {
					try (java.sql.Statement stmtDrop_tDBOutput_3 = conn_tDBOutput_3.createStatement()) {
						if (log.isDebugEnabled())
							log.debug(
									"tDBOutput_3 - " + ("Dropping") + (" table '") + (tableName_tDBOutput_3) + ("'."));
						stmtDrop_tDBOutput_3.execute("DROP TABLE `" + tableName_tDBOutput_3 + "`");
						if (log.isDebugEnabled())
							log.debug("tDBOutput_3 - " + ("Drop") + (" table '") + (tableName_tDBOutput_3)
									+ ("' has succeeded."));
					}
				}
				try (java.sql.Statement stmtCreate_tDBOutput_3 = conn_tDBOutput_3.createStatement()) {
					if (log.isDebugEnabled())
						log.debug("tDBOutput_3 - " + ("Creating") + (" table '") + (tableName_tDBOutput_3) + ("'."));
					stmtCreate_tDBOutput_3.execute("CREATE TABLE `" + tableName_tDBOutput_3
							+ "`(`Location_SK` INT(0)  ,`Address` VARCHAR(40)  ,`ZipCode` VARCHAR(10)  ,`State` VARCHAR(2)  ,`City` VARCHAR(20)  ,`Location` VARCHAR(100)  ,`Latitude` DOUBLE ,`Longitude` DOUBLE ,`DI_CreatedDate` DATETIME ,`DI_WorkflowFileName` VARCHAR(255)  ,`DI_Workflow_ProcessID` VARCHAR(30)  )");
					if (log.isDebugEnabled())
						log.debug("tDBOutput_3 - " + ("Create") + (" table '") + (tableName_tDBOutput_3)
								+ ("' has succeeded."));
				}

				String insert_tDBOutput_3 = "INSERT INTO `" + "dim_location"
						+ "` (`Location_SK`,`Address`,`ZipCode`,`State`,`City`,`Location`,`Latitude`,`Longitude`,`DI_CreatedDate`,`DI_WorkflowFileName`,`DI_Workflow_ProcessID`) VALUES (?,?,?,?,?,?,?,?,?,?,?)";

				int batchSize_tDBOutput_3 = 100;
				int batchSizeCounter_tDBOutput_3 = 0;

				java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
				resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);

				/**
				 * [tDBOutput_3 begin ] stop
				 */

				/**
				 * [tUniqRow_2 begin ] start
				 */

				ok_Hash.put("tUniqRow_2", false);
				start_Hash.put("tUniqRow_2", System.currentTimeMillis());

				currentComponent = "tUniqRow_2";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "DimLocation");

				int tos_count_tUniqRow_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_2 = new StringBuilder();
							log4jParamters_tUniqRow_2.append("Parameters:");
							log4jParamters_tUniqRow_2.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("Location_SK")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Address") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("ZipCode")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("State") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("City")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("true")
									+ ", SCHEMA_COLUMN=" + ("Location") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("Latitude")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Longitude") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("DI_CreatedDate")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("DI_WorkflowFileName") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("DI_Workflow_ProcessID")
									+ "}]");
							log4jParamters_tUniqRow_2.append(" | ");
							log4jParamters_tUniqRow_2.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_2.append(" | ");
							log4jParamters_tUniqRow_2.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_2.append(" | ");
							log4jParamters_tUniqRow_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_2 - " + (log4jParamters_tUniqRow_2));
						}
					}
					new BytesLimit65535_tUniqRow_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_2", "tUniqRow_2", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_2 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String Location;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + ((this.Location == null) ? 0 : this.Location.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_2 other = (KeyStruct_tUniqRow_2) obj;

						if (this.Location == null) {
							if (other.Location != null)
								return false;

						} else if (!this.Location.equals(other.Location))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_2 = 0;
				int nb_duplicates_tUniqRow_2 = 0;
				log.debug("tUniqRow_2 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_2 finder_tUniqRow_2 = new KeyStruct_tUniqRow_2();
				java.util.Set<KeyStruct_tUniqRow_2> keystUniqRow_2 = new java.util.HashSet<KeyStruct_tUniqRow_2>();

				/**
				 * [tUniqRow_2 begin ] stop
				 */

				/**
				 * [tDBOutput_5 begin ] start
				 */

				ok_Hash.put("tDBOutput_5", false);
				start_Hash.put("tDBOutput_5", System.currentTimeMillis());

				currentComponent = "tDBOutput_5";

				cLabel = "ProcessingMySQL";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row14");

				int tos_count_tDBOutput_5 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_5 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_5 = new StringBuilder();
							log4jParamters_tDBOutput_5.append("Parameters:");
							log4jParamters_tDBOutput_5.append("DB_VERSION" + " = " + "MYSQL_8");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("HOST" + " = " + "\"127.0.0.1\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("PORT" + " = " + "\"3306\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("DBNAME" + " = " + "\"food_inspections\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("USER" + " = " + "\"user2\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:1t9yNOjWA5/8kscgM+9tC2sFIu9E9sYwips1mWl3fj9QAwO3")
									.substring(0, 4) + "...");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("TABLE" + " = " + "\"dim_violation\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("TABLE_ACTION" + " = " + "DROP_IF_EXISTS_AND_CREATE");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("PROPERTIES" + " = "
									+ "\"noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1\"");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("EXTENDINSERT" + " = " + "true");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("NB_ROWS_PER_INSERT" + " = " + "100");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("USE_HINT_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("ON_DUPLICATE_KEY_UPDATE" + " = " + "false");
							log4jParamters_tDBOutput_5.append(" | ");
							log4jParamters_tDBOutput_5.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
							log4jParamters_tDBOutput_5.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_5 - " + (log4jParamters_tDBOutput_5));
						}
					}
					new BytesLimit65535_tDBOutput_5().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_5", "ProcessingMySQL", "tMysqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_5 = 0;
				int nb_line_update_tDBOutput_5 = 0;
				int nb_line_inserted_tDBOutput_5 = 0;
				int nb_line_deleted_tDBOutput_5 = 0;
				int nb_line_rejected_tDBOutput_5 = 0;

				int deletedCount_tDBOutput_5 = 0;
				int updatedCount_tDBOutput_5 = 0;
				int insertedCount_tDBOutput_5 = 0;
				int rowsToCommitCount_tDBOutput_5 = 0;
				int rejectedCount_tDBOutput_5 = 0;

				String tableName_tDBOutput_5 = "dim_violation";
				boolean whetherReject_tDBOutput_5 = false;

				java.util.Calendar calendar_tDBOutput_5 = java.util.Calendar.getInstance();
				calendar_tDBOutput_5.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_5 = calendar_tDBOutput_5.getTime().getTime();
				calendar_tDBOutput_5.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_5 = calendar_tDBOutput_5.getTime().getTime();
				long date_tDBOutput_5;

				java.sql.Connection conn_tDBOutput_5 = null;

				String properties_tDBOutput_5 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBOutput_5 == null || properties_tDBOutput_5.trim().length() == 0) {
					properties_tDBOutput_5 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
				} else {
					if (!properties_tDBOutput_5.contains("rewriteBatchedStatements=")) {
						properties_tDBOutput_5 += "&rewriteBatchedStatements=true";
					}

					if (!properties_tDBOutput_5.contains("allowLoadLocalInfile=")) {
						properties_tDBOutput_5 += "&allowLoadLocalInfile=true";
					}
				}

				String url_tDBOutput_5 = "jdbc:mysql://" + "127.0.0.1" + ":" + "3306" + "/" + "food_inspections" + "?"
						+ properties_tDBOutput_5;

				String driverClass_tDBOutput_5 = "com.mysql.cj.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_5) + ("."));
				String dbUser_tDBOutput_5 = "user2";

				final String decryptedPassword_tDBOutput_5 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:86o6enpHFRwoqy7xpIfCkJFmKyI/tpCAys4TmdKQLqFw99Rn");

				String dbPwd_tDBOutput_5 = decryptedPassword_tDBOutput_5;
				java.lang.Class.forName(driverClass_tDBOutput_5);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Connection attempts to '") + (url_tDBOutput_5)
							+ ("' with the username '") + (dbUser_tDBOutput_5) + ("'."));
				conn_tDBOutput_5 = java.sql.DriverManager.getConnection(url_tDBOutput_5, dbUser_tDBOutput_5,
						dbPwd_tDBOutput_5);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Connection to '") + (url_tDBOutput_5) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_5", conn_tDBOutput_5);

				conn_tDBOutput_5.setAutoCommit(false);
				int commitEvery_tDBOutput_5 = 10000;
				int commitCounter_tDBOutput_5 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_5.getAutoCommit()) + ("'."));

				int count_tDBOutput_5 = 0;

				java.sql.DatabaseMetaData dbMetaData_tDBOutput_5 = conn_tDBOutput_5.getMetaData();
				java.sql.ResultSet rsTable_tDBOutput_5 = dbMetaData_tDBOutput_5.getTables("food_inspections", null,
						null, new String[] { "TABLE" });
				boolean whetherExist_tDBOutput_5 = false;
				while (rsTable_tDBOutput_5.next()) {
					String table_tDBOutput_5 = rsTable_tDBOutput_5.getString("TABLE_NAME");
					if (table_tDBOutput_5.equalsIgnoreCase("dim_violation")) {
						whetherExist_tDBOutput_5 = true;
						break;
					}
				}
				if (whetherExist_tDBOutput_5) {
					try (java.sql.Statement stmtDrop_tDBOutput_5 = conn_tDBOutput_5.createStatement()) {
						if (log.isDebugEnabled())
							log.debug(
									"tDBOutput_5 - " + ("Dropping") + (" table '") + (tableName_tDBOutput_5) + ("'."));
						stmtDrop_tDBOutput_5.execute("DROP TABLE `" + tableName_tDBOutput_5 + "`");
						if (log.isDebugEnabled())
							log.debug("tDBOutput_5 - " + ("Drop") + (" table '") + (tableName_tDBOutput_5)
									+ ("' has succeeded."));
					}
				}
				try (java.sql.Statement stmtCreate_tDBOutput_5 = conn_tDBOutput_5.createStatement()) {
					if (log.isDebugEnabled())
						log.debug("tDBOutput_5 - " + ("Creating") + (" table '") + (tableName_tDBOutput_5) + ("'."));
					stmtCreate_tDBOutput_5.execute("CREATE TABLE `" + tableName_tDBOutput_5
							+ "`(`Violation_ID` INT(0)  ,`Violation_Code` VARCHAR(10)  ,`Code_Score` INT(0)  ,`Violation_Category` VARCHAR(8)  ,`DI_CreatedDate` DATETIME ,`DI_WorkflowFileName` VARCHAR(255)  ,`DI_Workflow_ProcessID` VARCHAR(30)  )");
					if (log.isDebugEnabled())
						log.debug("tDBOutput_5 - " + ("Create") + (" table '") + (tableName_tDBOutput_5)
								+ ("' has succeeded."));
				}

				String insert_tDBOutput_5 = "INSERT INTO `" + "dim_violation"
						+ "` (`Violation_ID`,`Violation_Code`,`Code_Score`,`Violation_Category`,`DI_CreatedDate`,`DI_WorkflowFileName`,`DI_Workflow_ProcessID`) VALUES (?,?,?,?,?,?,?)";

				int batchSize_tDBOutput_5 = 100;
				int batchSizeCounter_tDBOutput_5 = 0;

				java.sql.PreparedStatement pstmt_tDBOutput_5 = conn_tDBOutput_5.prepareStatement(insert_tDBOutput_5);
				resourceMap.put("pstmt_tDBOutput_5", pstmt_tDBOutput_5);

				/**
				 * [tDBOutput_5 begin ] stop
				 */

				/**
				 * [tUniqRow_5 begin ] start
				 */

				ok_Hash.put("tUniqRow_5", false);
				start_Hash.put("tUniqRow_5", System.currentTimeMillis());

				currentComponent = "tUniqRow_5";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "DimViolation");

				int tos_count_tUniqRow_5 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_5 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_5 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_5 = new StringBuilder();
							log4jParamters_tUniqRow_5.append("Parameters:");
							log4jParamters_tUniqRow_5.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("Violation_ID")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("true")
									+ ", SCHEMA_COLUMN=" + ("Violation_Code") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("Code_Score")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Violation_Category") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("DI_CreatedDate")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("DI_WorkflowFileName") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("DI_Workflow_ProcessID")
									+ "}]");
							log4jParamters_tUniqRow_5.append(" | ");
							log4jParamters_tUniqRow_5.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_5.append(" | ");
							log4jParamters_tUniqRow_5.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_5.append(" | ");
							log4jParamters_tUniqRow_5.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_5.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_5 - " + (log4jParamters_tUniqRow_5));
						}
					}
					new BytesLimit65535_tUniqRow_5().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_5", "tUniqRow_5", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_5 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String Violation_Code;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result
									+ ((this.Violation_Code == null) ? 0 : this.Violation_Code.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_5 other = (KeyStruct_tUniqRow_5) obj;

						if (this.Violation_Code == null) {
							if (other.Violation_Code != null)
								return false;

						} else if (!this.Violation_Code.equals(other.Violation_Code))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_5 = 0;
				int nb_duplicates_tUniqRow_5 = 0;
				log.debug("tUniqRow_5 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_5 finder_tUniqRow_5 = new KeyStruct_tUniqRow_5();
				java.util.Set<KeyStruct_tUniqRow_5> keystUniqRow_5 = new java.util.HashSet<KeyStruct_tUniqRow_5>();

				/**
				 * [tUniqRow_5 begin ] stop
				 */

				/**
				 * [tDBOutput_4 begin ] start
				 */

				ok_Hash.put("tDBOutput_4", false);
				start_Hash.put("tDBOutput_4", System.currentTimeMillis());

				currentComponent = "tDBOutput_4";

				cLabel = "ProcessingMySQL";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row5");

				int tos_count_tDBOutput_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_4 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_4 = new StringBuilder();
							log4jParamters_tDBOutput_4.append("Parameters:");
							log4jParamters_tDBOutput_4.append("DB_VERSION" + " = " + "MYSQL_8");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("HOST" + " = " + "\"127.0.0.1\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("PORT" + " = " + "\"3306\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("DBNAME" + " = " + "\"food_inspections\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("USER" + " = " + "\"user2\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:rd2xwWZtCA+iUMREclT980IiNuwrHRexdXR7V0TR9qfcMssg")
									.substring(0, 4) + "...");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("TABLE" + " = " + "\"dim_business\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("TABLE_ACTION" + " = " + "DROP_IF_EXISTS_AND_CREATE");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("PROPERTIES" + " = "
									+ "\"noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1\"");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("EXTENDINSERT" + " = " + "true");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("NB_ROWS_PER_INSERT" + " = " + "100");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("USE_HINT_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("ON_DUPLICATE_KEY_UPDATE" + " = " + "false");
							log4jParamters_tDBOutput_4.append(" | ");
							log4jParamters_tDBOutput_4.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
							log4jParamters_tDBOutput_4.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_4 - " + (log4jParamters_tDBOutput_4));
						}
					}
					new BytesLimit65535_tDBOutput_4().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_4", "ProcessingMySQL", "tMysqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_4 = 0;
				int nb_line_update_tDBOutput_4 = 0;
				int nb_line_inserted_tDBOutput_4 = 0;
				int nb_line_deleted_tDBOutput_4 = 0;
				int nb_line_rejected_tDBOutput_4 = 0;

				int deletedCount_tDBOutput_4 = 0;
				int updatedCount_tDBOutput_4 = 0;
				int insertedCount_tDBOutput_4 = 0;
				int rowsToCommitCount_tDBOutput_4 = 0;
				int rejectedCount_tDBOutput_4 = 0;

				String tableName_tDBOutput_4 = "dim_business";
				boolean whetherReject_tDBOutput_4 = false;

				java.util.Calendar calendar_tDBOutput_4 = java.util.Calendar.getInstance();
				calendar_tDBOutput_4.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_4 = calendar_tDBOutput_4.getTime().getTime();
				calendar_tDBOutput_4.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_4 = calendar_tDBOutput_4.getTime().getTime();
				long date_tDBOutput_4;

				java.sql.Connection conn_tDBOutput_4 = null;

				String properties_tDBOutput_4 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
				if (properties_tDBOutput_4 == null || properties_tDBOutput_4.trim().length() == 0) {
					properties_tDBOutput_4 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
				} else {
					if (!properties_tDBOutput_4.contains("rewriteBatchedStatements=")) {
						properties_tDBOutput_4 += "&rewriteBatchedStatements=true";
					}

					if (!properties_tDBOutput_4.contains("allowLoadLocalInfile=")) {
						properties_tDBOutput_4 += "&allowLoadLocalInfile=true";
					}
				}

				String url_tDBOutput_4 = "jdbc:mysql://" + "127.0.0.1" + ":" + "3306" + "/" + "food_inspections" + "?"
						+ properties_tDBOutput_4;

				String driverClass_tDBOutput_4 = "com.mysql.cj.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_4) + ("."));
				String dbUser_tDBOutput_4 = "user2";

				final String decryptedPassword_tDBOutput_4 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:jsjbwNT0fE5WpCXTQXVtsLBzNFItxRYbKe5Qsg4QqkypgfSd");

				String dbPwd_tDBOutput_4 = decryptedPassword_tDBOutput_4;
				java.lang.Class.forName(driverClass_tDBOutput_4);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Connection attempts to '") + (url_tDBOutput_4)
							+ ("' with the username '") + (dbUser_tDBOutput_4) + ("'."));
				conn_tDBOutput_4 = java.sql.DriverManager.getConnection(url_tDBOutput_4, dbUser_tDBOutput_4,
						dbPwd_tDBOutput_4);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Connection to '") + (url_tDBOutput_4) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_4", conn_tDBOutput_4);

				conn_tDBOutput_4.setAutoCommit(false);
				int commitEvery_tDBOutput_4 = 10000;
				int commitCounter_tDBOutput_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_4.getAutoCommit()) + ("'."));

				int count_tDBOutput_4 = 0;

				java.sql.DatabaseMetaData dbMetaData_tDBOutput_4 = conn_tDBOutput_4.getMetaData();
				java.sql.ResultSet rsTable_tDBOutput_4 = dbMetaData_tDBOutput_4.getTables("food_inspections", null,
						null, new String[] { "TABLE" });
				boolean whetherExist_tDBOutput_4 = false;
				while (rsTable_tDBOutput_4.next()) {
					String table_tDBOutput_4 = rsTable_tDBOutput_4.getString("TABLE_NAME");
					if (table_tDBOutput_4.equalsIgnoreCase("dim_business")) {
						whetherExist_tDBOutput_4 = true;
						break;
					}
				}
				if (whetherExist_tDBOutput_4) {
					try (java.sql.Statement stmtDrop_tDBOutput_4 = conn_tDBOutput_4.createStatement()) {
						if (log.isDebugEnabled())
							log.debug(
									"tDBOutput_4 - " + ("Dropping") + (" table '") + (tableName_tDBOutput_4) + ("'."));
						stmtDrop_tDBOutput_4.execute("DROP TABLE `" + tableName_tDBOutput_4 + "`");
						if (log.isDebugEnabled())
							log.debug("tDBOutput_4 - " + ("Drop") + (" table '") + (tableName_tDBOutput_4)
									+ ("' has succeeded."));
					}
				}
				try (java.sql.Statement stmtCreate_tDBOutput_4 = conn_tDBOutput_4.createStatement()) {
					if (log.isDebugEnabled())
						log.debug("tDBOutput_4 - " + ("Creating") + (" table '") + (tableName_tDBOutput_4) + ("'."));
					stmtCreate_tDBOutput_4.execute("CREATE TABLE `" + tableName_tDBOutput_4
							+ "`(`Business_ID_SK` INT(0)  ,`BusinessId` VARCHAR(9)  ,`Name` VARCHAR(70)  ,`PhoneNumber` VARCHAR(13)  ,`DI_CreatedDate` DATETIME ,`DI_WorkflowFileName` VARCHAR(255)  ,`DI_Workflow_ProcessID` VARCHAR(30)  )");
					if (log.isDebugEnabled())
						log.debug("tDBOutput_4 - " + ("Create") + (" table '") + (tableName_tDBOutput_4)
								+ ("' has succeeded."));
				}

				String insert_tDBOutput_4 = "INSERT INTO `" + "dim_business"
						+ "` (`Business_ID_SK`,`BusinessId`,`Name`,`PhoneNumber`,`DI_CreatedDate`,`DI_WorkflowFileName`,`DI_Workflow_ProcessID`) VALUES (?,?,?,?,?,?,?)";

				int batchSize_tDBOutput_4 = 100;
				int batchSizeCounter_tDBOutput_4 = 0;

				java.sql.PreparedStatement pstmt_tDBOutput_4 = conn_tDBOutput_4.prepareStatement(insert_tDBOutput_4);
				resourceMap.put("pstmt_tDBOutput_4", pstmt_tDBOutput_4);

				/**
				 * [tDBOutput_4 begin ] stop
				 */

				/**
				 * [tUniqRow_1 begin ] start
				 */

				ok_Hash.put("tUniqRow_1", false);
				start_Hash.put("tUniqRow_1", System.currentTimeMillis());

				currentComponent = "tUniqRow_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "DimBusiness");

				int tos_count_tUniqRow_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tUniqRow_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tUniqRow_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tUniqRow_1 = new StringBuilder();
							log4jParamters_tUniqRow_1.append("Parameters:");
							log4jParamters_tUniqRow_1.append("UNIQUE_KEY" + " = " + "[{CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("Business_ID_SK")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("true")
									+ ", SCHEMA_COLUMN=" + ("BusinessId") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("Name")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("PhoneNumber") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("DI_CreatedDate")
									+ "}, {CASE_SENSITIVE=" + ("false") + ", KEY_ATTRIBUTE=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("DI_WorkflowFileName") + "}, {CASE_SENSITIVE=" + ("false")
									+ ", KEY_ATTRIBUTE=" + ("false") + ", SCHEMA_COLUMN=" + ("DI_Workflow_ProcessID")
									+ "}]");
							log4jParamters_tUniqRow_1.append(" | ");
							log4jParamters_tUniqRow_1.append("ONLY_ONCE_EACH_DUPLICATED_KEY" + " = " + "false");
							log4jParamters_tUniqRow_1.append(" | ");
							log4jParamters_tUniqRow_1.append("IS_VIRTUAL_COMPONENT" + " = " + "false");
							log4jParamters_tUniqRow_1.append(" | ");
							log4jParamters_tUniqRow_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
							log4jParamters_tUniqRow_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tUniqRow_1 - " + (log4jParamters_tUniqRow_1));
						}
					}
					new BytesLimit65535_tUniqRow_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tUniqRow_1", "tUniqRow_1", "tUniqRow");
					talendJobLogProcess(globalMap);
				}

				class KeyStruct_tUniqRow_1 {

					private static final int DEFAULT_HASHCODE = 1;
					private static final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					String BusinessId;

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							result = prime * result + ((this.BusinessId == null) ? 0 : this.BusinessId.hashCode());

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final KeyStruct_tUniqRow_1 other = (KeyStruct_tUniqRow_1) obj;

						if (this.BusinessId == null) {
							if (other.BusinessId != null)
								return false;

						} else if (!this.BusinessId.equals(other.BusinessId))

							return false;

						return true;
					}

				}

				int nb_uniques_tUniqRow_1 = 0;
				int nb_duplicates_tUniqRow_1 = 0;
				log.debug("tUniqRow_1 - Start to process the data from datasource.");
				KeyStruct_tUniqRow_1 finder_tUniqRow_1 = new KeyStruct_tUniqRow_1();
				java.util.Set<KeyStruct_tUniqRow_1> keystUniqRow_1 = new java.util.HashSet<KeyStruct_tUniqRow_1>();

				/**
				 * [tUniqRow_1 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row12");

				int tos_count_tMap_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_1 = new StringBuilder();
							log4jParamters_tMap_1.append("Parameters:");
							log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_1 - " + (log4jParamters_tMap_1));
						}
					}
					new BytesLimit65535_tMap_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_1", "tMap_1", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row12_tMap_1 = 0;

				int count_row13_tMap_1 = 0;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row13Struct> tHash_Lookup_row13 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row13Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row13Struct>) globalMap
						.get("tHash_Lookup_row13"));

				row13Struct row13HashKey = new row13Struct();
				row13Struct row13Default = new row13Struct();
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
					String violation_score;
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_DimDate_tMap_1 = 0;

				DimDateStruct DimDate_tmp = new DimDateStruct();
				int count_DimInspectionType_tMap_1 = 0;

				DimInspectionTypeStruct DimInspectionType_tmp = new DimInspectionTypeStruct();
				int count_DimLocation_tMap_1 = 0;

				DimLocationStruct DimLocation_tmp = new DimLocationStruct();
				int count_DimViolation_tMap_1 = 0;

				DimViolationStruct DimViolation_tmp = new DimViolationStruct();
				int count_DimBusiness_tMap_1 = 0;

				DimBusinessStruct DimBusiness_tmp = new DimBusinessStruct();
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tHashInput_3 begin ] start
				 */

				ok_Hash.put("tHashInput_3", false);
				start_Hash.put("tHashInput_3", System.currentTimeMillis());

				currentComponent = "tHashInput_3";

				int tos_count_tHashInput_3 = 0;

				if (enableLogStash) {
					talendJobLog.addCM("tHashInput_3", "tHashInput_3", "tHashInput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tHashInput_3 = 0;

				org.talend.designer.components.hashfile.common.MapHashFile mf_tHashInput_3 = org.talend.designer.components.hashfile.common.MapHashFile
						.getMapHashFile();
				org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<Facts_DimensionsStruct> tHashFile_tHashInput_3 = mf_tHashInput_3
						.getAdvancedMemoryHashFile("tHashFile_DataPreparation_" + pid + "_tHashOutput_3");
				if (tHashFile_tHashInput_3 == null) {
					throw new RuntimeException(
							"The hash is not initialized : The hash must exist before you read from it");
				}
				java.util.Iterator<Facts_DimensionsStruct> iterator_tHashInput_3 = tHashFile_tHashInput_3.iterator();
				while (iterator_tHashInput_3.hasNext()) {
					Facts_DimensionsStruct next_tHashInput_3 = iterator_tHashInput_3.next();

					row12.BusinessId = next_tHashInput_3.BusinessId;
					row12.Name = next_tHashInput_3.Name;
					row12.Address = next_tHashInput_3.Address;
					row12.City = next_tHashInput_3.City;
					row12.State = next_tHashInput_3.State;
					row12.ZipCode = next_tHashInput_3.ZipCode;
					row12.PhoneNumber = next_tHashInput_3.PhoneNumber;
					row12.InspectionId = next_tHashInput_3.InspectionId;
					row12.Date = next_tHashInput_3.Date;
					row12.InspectionType = next_tHashInput_3.InspectionType;
					row12.Location = next_tHashInput_3.Location;
					row12.Latitude = next_tHashInput_3.Latitude;
					row12.Longitude = next_tHashInput_3.Longitude;
					row12.DI_CreatedDate = next_tHashInput_3.DI_CreatedDate;
					row12.DI_WorkflowFileName = next_tHashInput_3.DI_WorkflowFileName;
					row12.DI_Workflow_ProcessID = next_tHashInput_3.DI_Workflow_ProcessID;
					row12.Date_SK = next_tHashInput_3.Date_SK;
					row12.InspectionType_ID = next_tHashInput_3.InspectionType_ID;
					row12.Business_ID_SK = next_tHashInput_3.Business_ID_SK;
					row12.Location_SK = next_tHashInput_3.Location_SK;
					row12.Inspection_SK = next_tHashInput_3.Inspection_SK;

					/**
					 * [tHashInput_3 begin ] stop
					 */

					/**
					 * [tHashInput_3 main ] start
					 */

					currentComponent = "tHashInput_3";

					tos_count_tHashInput_3++;

					/**
					 * [tHashInput_3 main ] stop
					 */

					/**
					 * [tHashInput_3 process_data_begin ] start
					 */

					currentComponent = "tHashInput_3";

					/**
					 * [tHashInput_3 process_data_begin ] stop
					 */

					/**
					 * [tMap_1 main ] start
					 */

					currentComponent = "tMap_1";

					if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

							, "row12", "tHashInput_3", "tHashInput_3", "tHashInput", "tMap_1", "tMap_1", "tMap"

					)) {
						talendJobLogProcess(globalMap);
					}

					if (log.isTraceEnabled()) {
						log.trace("row12 - " + (row12 == null ? "" : row12.toLogString()));
					}

					boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

					row13Struct row13 = null;

					// ###############################
					// # Input tables (lookups)

					boolean rejectedInnerJoin_tMap_1 = false;
					boolean mainRowRejected_tMap_1 = false;

					///////////////////////////////////////////////
					// Starting Lookup Table "row13"
					///////////////////////////////////////////////

					boolean forceLooprow13 = false;

					row13Struct row13ObjectFromLookup = null;

					if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

						hasCasePrimitiveKeyWithNull_tMap_1 = false;

						row13HashKey.InspectionId = row12.InspectionId;

						row13HashKey.hashCodeDirty = true;

						tHash_Lookup_row13.lookup(row13HashKey);

						if (!tHash_Lookup_row13.hasNext()) { // G_TM_M_090

							rejectedInnerJoin_tMap_1 = true;

						} // G_TM_M_090

					} // G_TM_M_020

					if (tHash_Lookup_row13 != null && tHash_Lookup_row13.getCount(row13HashKey) > 1) { // G 071

						// System.out.println("WARNING: UNIQUE MATCH is configured for the lookup
						// 'row13' and it contains more one result from keys : row13.InspectionId = '" +
						// row13HashKey.InspectionId + "'");
					} // G 071

					row13Struct fromLookup_row13 = null;
					row13 = row13Default;

					if (tHash_Lookup_row13 != null && tHash_Lookup_row13.hasNext()) { // G 099

						fromLookup_row13 = tHash_Lookup_row13.next();

					} // G 099

					if (fromLookup_row13 != null) {
						row13 = fromLookup_row13;
					}

					// ###############################
					{ // start of Var scope

						// ###############################
						// # Vars tables

						Var__tMap_1__Struct Var = Var__tMap_1;
						Var.violation_score = null;// ###############################
						// ###############################
						// # Output tables

						DimDate = null;
						DimInspectionType = null;
						DimLocation = null;
						DimViolation = null;
						DimBusiness = null;

						if (!rejectedInnerJoin_tMap_1) {

// # Output table : 'DimDate'
							count_DimDate_tMap_1++;

							DimDate_tmp.Date_SK = row12.Date_SK;
							DimDate_tmp.Year = TalendDate.getPartOfDate("YEAR", row12.Date);
							DimDate_tmp.Day = TalendDate.getPartOfDate("DAY_OF_MONTH", row12.Date);
							DimDate_tmp.Day_Of_Week = (TalendDate.getPartOfDate("DAY_OF_WEEK", row12.Date) == 0)
									|| (TalendDate.getPartOfDate("DAY_OF_WEEK", row12.Date) == 6) ? "Weekend"
											: "Weekday";
							;
							DimDate_tmp.Month = TalendDate.getPartOfDate("MONTH", row12.Date) + 1;
							DimDate_tmp.Date = row12.Date;
							DimDate_tmp.DI_CreatedDate = TalendDate.getCurrentDate();
							DimDate_tmp.DI_WorkflowFileName = row12.DI_WorkflowFileName;
							DimDate_tmp.DI_Workflow_ProcessID = pid;
							DimDate = DimDate_tmp;
							log.debug("tMap_1 - Outputting the record " + count_DimDate_tMap_1
									+ " of the output table 'DimDate'.");

// # Output table : 'DimInspectionType'
							count_DimInspectionType_tMap_1++;

							DimInspectionType_tmp.InspectionType_ID = row12.InspectionType_ID;
							DimInspectionType_tmp.InspectionType = row12.InspectionType;
							DimInspectionType_tmp.DI_CreatedDate = TalendDate.getCurrentDate();
							DimInspectionType_tmp.DI_WorkflowFileName = row12.DI_WorkflowFileName;
							DimInspectionType_tmp.DI_Workflow_ProcessID = pid;
							DimInspectionType = DimInspectionType_tmp;
							log.debug("tMap_1 - Outputting the record " + count_DimInspectionType_tMap_1
									+ " of the output table 'DimInspectionType'.");

// # Output table : 'DimLocation'
							count_DimLocation_tMap_1++;

							DimLocation_tmp.Location_SK = row12.Location_SK;
							DimLocation_tmp.Address = row12.Address;
							DimLocation_tmp.ZipCode = row12.ZipCode;
							DimLocation_tmp.State = row12.State;
							DimLocation_tmp.City = row12.City;
							DimLocation_tmp.Location = row12.Location;
							DimLocation_tmp.Latitude = Double.parseDouble(row12.Latitude);
							DimLocation_tmp.Longitude = Double.parseDouble(row12.Longitude);
							DimLocation_tmp.DI_CreatedDate = TalendDate.getCurrentDate();
							DimLocation_tmp.DI_WorkflowFileName = row12.DI_WorkflowFileName;
							DimLocation_tmp.DI_Workflow_ProcessID = pid;
							DimLocation = DimLocation_tmp;
							log.debug("tMap_1 - Outputting the record " + count_DimLocation_tMap_1
									+ " of the output table 'DimLocation'.");

// # Output table : 'DimViolation'
							count_DimViolation_tMap_1++;

							DimViolation_tmp.Violation_ID = row13.Violation_ID;
							DimViolation_tmp.Violation_Code = row13.ViolationCodes;
							DimViolation_tmp.Code_Score = row13.CodeScore;
							DimViolation_tmp.Violation_Category = row13.ViolationCategory;
							DimViolation_tmp.DI_CreatedDate = TalendDate.getCurrentDate();
							DimViolation_tmp.DI_WorkflowFileName = row12.DI_WorkflowFileName;
							DimViolation_tmp.DI_Workflow_ProcessID = pid;
							DimViolation = DimViolation_tmp;
							log.debug("tMap_1 - Outputting the record " + count_DimViolation_tMap_1
									+ " of the output table 'DimViolation'.");

// # Output table : 'DimBusiness'
							count_DimBusiness_tMap_1++;

							DimBusiness_tmp.Business_ID_SK = row12.Business_ID_SK;
							DimBusiness_tmp.BusinessId = row12.BusinessId;
							DimBusiness_tmp.Name = row12.Name;
							DimBusiness_tmp.PhoneNumber = row12.PhoneNumber;
							DimBusiness_tmp.DI_CreatedDate = TalendDate.getCurrentDate();
							DimBusiness_tmp.DI_WorkflowFileName = row12.DI_WorkflowFileName;
							DimBusiness_tmp.DI_Workflow_ProcessID = pid;
							DimBusiness = DimBusiness_tmp;
							log.debug("tMap_1 - Outputting the record " + count_DimBusiness_tMap_1
									+ " of the output table 'DimBusiness'.");

						} // closing inner join bracket (2)
// ###############################

					} // end of Var scope

					rejectedInnerJoin_tMap_1 = false;

					tos_count_tMap_1++;

					/**
					 * [tMap_1 main ] stop
					 */

					/**
					 * [tMap_1 process_data_begin ] start
					 */

					currentComponent = "tMap_1";

					/**
					 * [tMap_1 process_data_begin ] stop
					 */
// Start of branch "DimDate"
					if (DimDate != null) {

						/**
						 * [tUniqRow_4 main ] start
						 */

						currentComponent = "tUniqRow_4";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "DimDate", "tMap_1", "tMap_1", "tMap", "tUniqRow_4", "tUniqRow_4", "tUniqRow"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("DimDate - " + (DimDate == null ? "" : DimDate.toLogString()));
						}

						row8 = null;
						if (DimDate.Date_SK == null) {
							finder_tUniqRow_4.Date_SK = null;
						} else {
							finder_tUniqRow_4.Date_SK = DimDate.Date_SK.toLowerCase();
						}
						finder_tUniqRow_4.hashCodeDirty = true;
						if (!keystUniqRow_4.contains(finder_tUniqRow_4)) {
							KeyStruct_tUniqRow_4 new_tUniqRow_4 = new KeyStruct_tUniqRow_4();

							if (DimDate.Date_SK == null) {
								new_tUniqRow_4.Date_SK = null;
							} else {
								new_tUniqRow_4.Date_SK = DimDate.Date_SK.toLowerCase();
							}

							keystUniqRow_4.add(new_tUniqRow_4);
							if (row8 == null) {

								log.trace("tUniqRow_4 - Writing the unique record " + (nb_uniques_tUniqRow_4 + 1)
										+ " into row8.");

								row8 = new row8Struct();
							}
							row8.Date_SK = DimDate.Date_SK;
							row8.Year = DimDate.Year;
							row8.Day = DimDate.Day;
							row8.Day_Of_Week = DimDate.Day_Of_Week;
							row8.Month = DimDate.Month;
							row8.Date = DimDate.Date;
							row8.DI_CreatedDate = DimDate.DI_CreatedDate;
							row8.DI_WorkflowFileName = DimDate.DI_WorkflowFileName;
							row8.DI_Workflow_ProcessID = DimDate.DI_Workflow_ProcessID;
							nb_uniques_tUniqRow_4++;
						} else {
							nb_duplicates_tUniqRow_4++;
						}

						tos_count_tUniqRow_4++;

						/**
						 * [tUniqRow_4 main ] stop
						 */

						/**
						 * [tUniqRow_4 process_data_begin ] start
						 */

						currentComponent = "tUniqRow_4";

						/**
						 * [tUniqRow_4 process_data_begin ] stop
						 */
// Start of branch "row8"
						if (row8 != null) {

							/**
							 * [tDBOutput_1 main ] start
							 */

							currentComponent = "tDBOutput_1";

							cLabel = "ProcessingMySQL";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "row8", "tUniqRow_4", "tUniqRow_4", "tUniqRow", "tDBOutput_1", "ProcessingMySQL",
									"tMysqlOutput"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("row8 - " + (row8 == null ? "" : row8.toLogString()));
							}

							whetherReject_tDBOutput_1 = false;
							if (row8.Date_SK == null) {
								pstmt_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_1.setString(1, row8.Date_SK);
							}

							if (row8.Year == null) {
								pstmt_tDBOutput_1.setNull(2, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_1.setInt(2, row8.Year);
							}

							if (row8.Day == null) {
								pstmt_tDBOutput_1.setNull(3, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_1.setInt(3, row8.Day);
							}

							if (row8.Day_Of_Week == null) {
								pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_1.setString(4, row8.Day_Of_Week);
							}

							if (row8.Month == null) {
								pstmt_tDBOutput_1.setNull(5, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_1.setInt(5, row8.Month);
							}

							if (row8.Date != null) {
								date_tDBOutput_1 = row8.Date.getTime();
								if (date_tDBOutput_1 < year1_tDBOutput_1 || date_tDBOutput_1 >= year10000_tDBOutput_1) {
									pstmt_tDBOutput_1.setString(6, "0000-00-00 00:00:00");
								} else {
									pstmt_tDBOutput_1.setTimestamp(6, new java.sql.Timestamp(date_tDBOutput_1));
								}
							} else {
								pstmt_tDBOutput_1.setNull(6, java.sql.Types.DATE);
							}

							if (row8.DI_CreatedDate != null) {
								date_tDBOutput_1 = row8.DI_CreatedDate.getTime();
								if (date_tDBOutput_1 < year1_tDBOutput_1 || date_tDBOutput_1 >= year10000_tDBOutput_1) {
									pstmt_tDBOutput_1.setString(7, "0000-00-00 00:00:00");
								} else {
									pstmt_tDBOutput_1.setTimestamp(7, new java.sql.Timestamp(date_tDBOutput_1));
								}
							} else {
								pstmt_tDBOutput_1.setNull(7, java.sql.Types.DATE);
							}

							if (row8.DI_WorkflowFileName == null) {
								pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_1.setString(8, row8.DI_WorkflowFileName);
							}

							if (row8.DI_Workflow_ProcessID == null) {
								pstmt_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_1.setString(9, row8.DI_Workflow_ProcessID);
							}

							pstmt_tDBOutput_1.addBatch();
							nb_line_tDBOutput_1++;

							if (log.isDebugEnabled())
								log.debug("tDBOutput_1 - " + ("Adding the record ") + (nb_line_tDBOutput_1)
										+ (" to the ") + ("INSERT") + (" batch."));
							batchSizeCounter_tDBOutput_1++;
							if (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1) {
								try {
									int countSum_tDBOutput_1 = 0;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT") + (" batch."));
									for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
										countSum_tDBOutput_1 += (countEach_tDBOutput_1 == java.sql.Statement.EXECUTE_FAILED
												? 0
												: 1);
									}
									rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_1 - " + ("The ") + ("INSERT")
												+ (" batch execution has succeeded."));
									insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
								} catch (java.sql.BatchUpdateException e) {
									globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());
									int countSum_tDBOutput_1 = 0;
									for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
										countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
									}
									rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
									insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
									System.err.println(e.getMessage());
									log.error("tDBOutput_1 - " + (e.getMessage()));
								}

								batchSizeCounter_tDBOutput_1 = 0;
							}
							commitCounter_tDBOutput_1++;

							if (commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {

								try {
									int countSum_tDBOutput_1 = 0;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT") + (" batch."));
									for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
										countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : 1);
									}
									rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_1 - " + ("The ") + ("INSERT")
												+ (" batch execution has succeeded."));
									insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
								} catch (java.sql.BatchUpdateException e) {
									globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());
									int countSum_tDBOutput_1 = 0;
									for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
										countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
									}
									rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
									insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
									System.err.println(e.getMessage());
									log.error("tDBOutput_1 - " + (e.getMessage()));

								}
								if (rowsToCommitCount_tDBOutput_1 != 0) {
									if (log.isDebugEnabled())
										log.debug("tDBOutput_1 - " + ("Connection starting to commit ")
												+ (rowsToCommitCount_tDBOutput_1) + (" record(s)."));
								}
								conn_tDBOutput_1.commit();
								if (rowsToCommitCount_tDBOutput_1 != 0) {
									if (log.isDebugEnabled())
										log.debug("tDBOutput_1 - " + ("Connection commit has succeeded."));
									rowsToCommitCount_tDBOutput_1 = 0;
								}
								commitCounter_tDBOutput_1 = 0;
							}

							tos_count_tDBOutput_1++;

							/**
							 * [tDBOutput_1 main ] stop
							 */

							/**
							 * [tDBOutput_1 process_data_begin ] start
							 */

							currentComponent = "tDBOutput_1";

							cLabel = "ProcessingMySQL";

							/**
							 * [tDBOutput_1 process_data_begin ] stop
							 */

							/**
							 * [tDBOutput_1 process_data_end ] start
							 */

							currentComponent = "tDBOutput_1";

							cLabel = "ProcessingMySQL";

							/**
							 * [tDBOutput_1 process_data_end ] stop
							 */

						} // End of branch "row8"

						/**
						 * [tUniqRow_4 process_data_end ] start
						 */

						currentComponent = "tUniqRow_4";

						/**
						 * [tUniqRow_4 process_data_end ] stop
						 */

					} // End of branch "DimDate"

// Start of branch "DimInspectionType"
					if (DimInspectionType != null) {

						/**
						 * [tUniqRow_3 main ] start
						 */

						currentComponent = "tUniqRow_3";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "DimInspectionType", "tMap_1", "tMap_1", "tMap", "tUniqRow_3", "tUniqRow_3",
								"tUniqRow"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("DimInspectionType - "
									+ (DimInspectionType == null ? "" : DimInspectionType.toLogString()));
						}

						row7 = null;
						if (DimInspectionType.InspectionType == null) {
							finder_tUniqRow_3.InspectionType = null;
						} else {
							finder_tUniqRow_3.InspectionType = DimInspectionType.InspectionType.toLowerCase();
						}
						finder_tUniqRow_3.hashCodeDirty = true;
						if (!keystUniqRow_3.contains(finder_tUniqRow_3)) {
							KeyStruct_tUniqRow_3 new_tUniqRow_3 = new KeyStruct_tUniqRow_3();

							if (DimInspectionType.InspectionType == null) {
								new_tUniqRow_3.InspectionType = null;
							} else {
								new_tUniqRow_3.InspectionType = DimInspectionType.InspectionType.toLowerCase();
							}

							keystUniqRow_3.add(new_tUniqRow_3);
							if (row7 == null) {

								log.trace("tUniqRow_3 - Writing the unique record " + (nb_uniques_tUniqRow_3 + 1)
										+ " into row7.");

								row7 = new row7Struct();
							}
							row7.InspectionType_ID = DimInspectionType.InspectionType_ID;
							row7.InspectionType = DimInspectionType.InspectionType;
							row7.DI_CreatedDate = DimInspectionType.DI_CreatedDate;
							row7.DI_WorkflowFileName = DimInspectionType.DI_WorkflowFileName;
							row7.DI_Workflow_ProcessID = DimInspectionType.DI_Workflow_ProcessID;
							nb_uniques_tUniqRow_3++;
						} else {
							nb_duplicates_tUniqRow_3++;
						}

						tos_count_tUniqRow_3++;

						/**
						 * [tUniqRow_3 main ] stop
						 */

						/**
						 * [tUniqRow_3 process_data_begin ] start
						 */

						currentComponent = "tUniqRow_3";

						/**
						 * [tUniqRow_3 process_data_begin ] stop
						 */
// Start of branch "row7"
						if (row7 != null) {

							/**
							 * [tDBOutput_2 main ] start
							 */

							currentComponent = "tDBOutput_2";

							cLabel = "ProcessingMySQL";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "row7", "tUniqRow_3", "tUniqRow_3", "tUniqRow", "tDBOutput_2", "ProcessingMySQL",
									"tMysqlOutput"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("row7 - " + (row7 == null ? "" : row7.toLogString()));
							}

							whetherReject_tDBOutput_2 = false;
							if (row7.InspectionType_ID == null) {
								pstmt_tDBOutput_2.setNull(1, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_2.setInt(1, row7.InspectionType_ID);
							}

							if (row7.InspectionType == null) {
								pstmt_tDBOutput_2.setNull(2, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(2, row7.InspectionType);
							}

							if (row7.DI_CreatedDate != null) {
								date_tDBOutput_2 = row7.DI_CreatedDate.getTime();
								if (date_tDBOutput_2 < year1_tDBOutput_2 || date_tDBOutput_2 >= year10000_tDBOutput_2) {
									pstmt_tDBOutput_2.setString(3, "0000-00-00 00:00:00");
								} else {
									pstmt_tDBOutput_2.setTimestamp(3, new java.sql.Timestamp(date_tDBOutput_2));
								}
							} else {
								pstmt_tDBOutput_2.setNull(3, java.sql.Types.DATE);
							}

							if (row7.DI_WorkflowFileName == null) {
								pstmt_tDBOutput_2.setNull(4, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(4, row7.DI_WorkflowFileName);
							}

							if (row7.DI_Workflow_ProcessID == null) {
								pstmt_tDBOutput_2.setNull(5, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_2.setString(5, row7.DI_Workflow_ProcessID);
							}

							pstmt_tDBOutput_2.addBatch();
							nb_line_tDBOutput_2++;

							if (log.isDebugEnabled())
								log.debug("tDBOutput_2 - " + ("Adding the record ") + (nb_line_tDBOutput_2)
										+ (" to the ") + ("INSERT") + (" batch."));
							batchSizeCounter_tDBOutput_2++;
							if (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2) {
								try {
									int countSum_tDBOutput_2 = 0;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_2 - " + ("Executing the ") + ("INSERT") + (" batch."));
									for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2.executeBatch()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 == java.sql.Statement.EXECUTE_FAILED
												? 0
												: 1);
									}
									rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_2 - " + ("The ") + ("INSERT")
												+ (" batch execution has succeeded."));
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
								} catch (java.sql.BatchUpdateException e) {
									globalMap.put("tDBOutput_2_ERROR_MESSAGE", e.getMessage());
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : e.getUpdateCounts()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
									}
									rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
									System.err.println(e.getMessage());
									log.error("tDBOutput_2 - " + (e.getMessage()));
								}

								batchSizeCounter_tDBOutput_2 = 0;
							}
							commitCounter_tDBOutput_2++;

							if (commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {

								try {
									int countSum_tDBOutput_2 = 0;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_2 - " + ("Executing the ") + ("INSERT") + (" batch."));
									for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2.executeBatch()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : 1);
									}
									rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_2 - " + ("The ") + ("INSERT")
												+ (" batch execution has succeeded."));
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
								} catch (java.sql.BatchUpdateException e) {
									globalMap.put("tDBOutput_2_ERROR_MESSAGE", e.getMessage());
									int countSum_tDBOutput_2 = 0;
									for (int countEach_tDBOutput_2 : e.getUpdateCounts()) {
										countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
									}
									rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
									insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
									System.err.println(e.getMessage());
									log.error("tDBOutput_2 - " + (e.getMessage()));

								}
								if (rowsToCommitCount_tDBOutput_2 != 0) {
									if (log.isDebugEnabled())
										log.debug("tDBOutput_2 - " + ("Connection starting to commit ")
												+ (rowsToCommitCount_tDBOutput_2) + (" record(s)."));
								}
								conn_tDBOutput_2.commit();
								if (rowsToCommitCount_tDBOutput_2 != 0) {
									if (log.isDebugEnabled())
										log.debug("tDBOutput_2 - " + ("Connection commit has succeeded."));
									rowsToCommitCount_tDBOutput_2 = 0;
								}
								commitCounter_tDBOutput_2 = 0;
							}

							tos_count_tDBOutput_2++;

							/**
							 * [tDBOutput_2 main ] stop
							 */

							/**
							 * [tDBOutput_2 process_data_begin ] start
							 */

							currentComponent = "tDBOutput_2";

							cLabel = "ProcessingMySQL";

							/**
							 * [tDBOutput_2 process_data_begin ] stop
							 */

							/**
							 * [tDBOutput_2 process_data_end ] start
							 */

							currentComponent = "tDBOutput_2";

							cLabel = "ProcessingMySQL";

							/**
							 * [tDBOutput_2 process_data_end ] stop
							 */

						} // End of branch "row7"

						/**
						 * [tUniqRow_3 process_data_end ] start
						 */

						currentComponent = "tUniqRow_3";

						/**
						 * [tUniqRow_3 process_data_end ] stop
						 */

					} // End of branch "DimInspectionType"

// Start of branch "DimLocation"
					if (DimLocation != null) {

						/**
						 * [tUniqRow_2 main ] start
						 */

						currentComponent = "tUniqRow_2";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "DimLocation", "tMap_1", "tMap_1", "tMap", "tUniqRow_2", "tUniqRow_2", "tUniqRow"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("DimLocation - " + (DimLocation == null ? "" : DimLocation.toLogString()));
						}

						row6 = null;
						if (DimLocation.Location == null) {
							finder_tUniqRow_2.Location = null;
						} else {
							finder_tUniqRow_2.Location = DimLocation.Location.toLowerCase();
						}
						finder_tUniqRow_2.hashCodeDirty = true;
						if (!keystUniqRow_2.contains(finder_tUniqRow_2)) {
							KeyStruct_tUniqRow_2 new_tUniqRow_2 = new KeyStruct_tUniqRow_2();

							if (DimLocation.Location == null) {
								new_tUniqRow_2.Location = null;
							} else {
								new_tUniqRow_2.Location = DimLocation.Location.toLowerCase();
							}

							keystUniqRow_2.add(new_tUniqRow_2);
							if (row6 == null) {

								log.trace("tUniqRow_2 - Writing the unique record " + (nb_uniques_tUniqRow_2 + 1)
										+ " into row6.");

								row6 = new row6Struct();
							}
							row6.Location_SK = DimLocation.Location_SK;
							row6.Address = DimLocation.Address;
							row6.ZipCode = DimLocation.ZipCode;
							row6.State = DimLocation.State;
							row6.City = DimLocation.City;
							row6.Location = DimLocation.Location;
							row6.Latitude = DimLocation.Latitude;
							row6.Longitude = DimLocation.Longitude;
							row6.DI_CreatedDate = DimLocation.DI_CreatedDate;
							row6.DI_WorkflowFileName = DimLocation.DI_WorkflowFileName;
							row6.DI_Workflow_ProcessID = DimLocation.DI_Workflow_ProcessID;
							nb_uniques_tUniqRow_2++;
						} else {
							nb_duplicates_tUniqRow_2++;
						}

						tos_count_tUniqRow_2++;

						/**
						 * [tUniqRow_2 main ] stop
						 */

						/**
						 * [tUniqRow_2 process_data_begin ] start
						 */

						currentComponent = "tUniqRow_2";

						/**
						 * [tUniqRow_2 process_data_begin ] stop
						 */
// Start of branch "row6"
						if (row6 != null) {

							/**
							 * [tDBOutput_3 main ] start
							 */

							currentComponent = "tDBOutput_3";

							cLabel = "ProcessingMySQL";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "row6", "tUniqRow_2", "tUniqRow_2", "tUniqRow", "tDBOutput_3", "ProcessingMySQL",
									"tMysqlOutput"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("row6 - " + (row6 == null ? "" : row6.toLogString()));
							}

							whetherReject_tDBOutput_3 = false;
							if (row6.Location_SK == null) {
								pstmt_tDBOutput_3.setNull(1, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_3.setInt(1, row6.Location_SK);
							}

							if (row6.Address == null) {
								pstmt_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_3.setString(2, row6.Address);
							}

							if (row6.ZipCode == null) {
								pstmt_tDBOutput_3.setNull(3, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_3.setString(3, row6.ZipCode);
							}

							if (row6.State == null) {
								pstmt_tDBOutput_3.setNull(4, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_3.setString(4, row6.State);
							}

							if (row6.City == null) {
								pstmt_tDBOutput_3.setNull(5, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_3.setString(5, row6.City);
							}

							if (row6.Location == null) {
								pstmt_tDBOutput_3.setNull(6, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_3.setString(6, row6.Location);
							}

							if (row6.Latitude == null) {
								pstmt_tDBOutput_3.setNull(7, java.sql.Types.DOUBLE);
							} else {
								pstmt_tDBOutput_3.setDouble(7, row6.Latitude);
							}

							if (row6.Longitude == null) {
								pstmt_tDBOutput_3.setNull(8, java.sql.Types.DOUBLE);
							} else {
								pstmt_tDBOutput_3.setDouble(8, row6.Longitude);
							}

							if (row6.DI_CreatedDate != null) {
								date_tDBOutput_3 = row6.DI_CreatedDate.getTime();
								if (date_tDBOutput_3 < year1_tDBOutput_3 || date_tDBOutput_3 >= year10000_tDBOutput_3) {
									pstmt_tDBOutput_3.setString(9, "0000-00-00 00:00:00");
								} else {
									pstmt_tDBOutput_3.setTimestamp(9, new java.sql.Timestamp(date_tDBOutput_3));
								}
							} else {
								pstmt_tDBOutput_3.setNull(9, java.sql.Types.DATE);
							}

							if (row6.DI_WorkflowFileName == null) {
								pstmt_tDBOutput_3.setNull(10, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_3.setString(10, row6.DI_WorkflowFileName);
							}

							if (row6.DI_Workflow_ProcessID == null) {
								pstmt_tDBOutput_3.setNull(11, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_3.setString(11, row6.DI_Workflow_ProcessID);
							}

							pstmt_tDBOutput_3.addBatch();
							nb_line_tDBOutput_3++;

							if (log.isDebugEnabled())
								log.debug("tDBOutput_3 - " + ("Adding the record ") + (nb_line_tDBOutput_3)
										+ (" to the ") + ("INSERT") + (" batch."));
							batchSizeCounter_tDBOutput_3++;
							if (batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3) {
								try {
									int countSum_tDBOutput_3 = 0;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_3 - " + ("Executing the ") + ("INSERT") + (" batch."));
									for (int countEach_tDBOutput_3 : pstmt_tDBOutput_3.executeBatch()) {
										countSum_tDBOutput_3 += (countEach_tDBOutput_3 == java.sql.Statement.EXECUTE_FAILED
												? 0
												: 1);
									}
									rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_3 - " + ("The ") + ("INSERT")
												+ (" batch execution has succeeded."));
									insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
								} catch (java.sql.BatchUpdateException e) {
									globalMap.put("tDBOutput_3_ERROR_MESSAGE", e.getMessage());
									int countSum_tDBOutput_3 = 0;
									for (int countEach_tDBOutput_3 : e.getUpdateCounts()) {
										countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
									}
									rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
									insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
									System.err.println(e.getMessage());
									log.error("tDBOutput_3 - " + (e.getMessage()));
								}

								batchSizeCounter_tDBOutput_3 = 0;
							}
							commitCounter_tDBOutput_3++;

							if (commitEvery_tDBOutput_3 <= commitCounter_tDBOutput_3) {

								try {
									int countSum_tDBOutput_3 = 0;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_3 - " + ("Executing the ") + ("INSERT") + (" batch."));
									for (int countEach_tDBOutput_3 : pstmt_tDBOutput_3.executeBatch()) {
										countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : 1);
									}
									rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_3 - " + ("The ") + ("INSERT")
												+ (" batch execution has succeeded."));
									insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
								} catch (java.sql.BatchUpdateException e) {
									globalMap.put("tDBOutput_3_ERROR_MESSAGE", e.getMessage());
									int countSum_tDBOutput_3 = 0;
									for (int countEach_tDBOutput_3 : e.getUpdateCounts()) {
										countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
									}
									rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
									insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
									System.err.println(e.getMessage());
									log.error("tDBOutput_3 - " + (e.getMessage()));

								}
								if (rowsToCommitCount_tDBOutput_3 != 0) {
									if (log.isDebugEnabled())
										log.debug("tDBOutput_3 - " + ("Connection starting to commit ")
												+ (rowsToCommitCount_tDBOutput_3) + (" record(s)."));
								}
								conn_tDBOutput_3.commit();
								if (rowsToCommitCount_tDBOutput_3 != 0) {
									if (log.isDebugEnabled())
										log.debug("tDBOutput_3 - " + ("Connection commit has succeeded."));
									rowsToCommitCount_tDBOutput_3 = 0;
								}
								commitCounter_tDBOutput_3 = 0;
							}

							tos_count_tDBOutput_3++;

							/**
							 * [tDBOutput_3 main ] stop
							 */

							/**
							 * [tDBOutput_3 process_data_begin ] start
							 */

							currentComponent = "tDBOutput_3";

							cLabel = "ProcessingMySQL";

							/**
							 * [tDBOutput_3 process_data_begin ] stop
							 */

							/**
							 * [tDBOutput_3 process_data_end ] start
							 */

							currentComponent = "tDBOutput_3";

							cLabel = "ProcessingMySQL";

							/**
							 * [tDBOutput_3 process_data_end ] stop
							 */

						} // End of branch "row6"

						/**
						 * [tUniqRow_2 process_data_end ] start
						 */

						currentComponent = "tUniqRow_2";

						/**
						 * [tUniqRow_2 process_data_end ] stop
						 */

					} // End of branch "DimLocation"

// Start of branch "DimViolation"
					if (DimViolation != null) {

						/**
						 * [tUniqRow_5 main ] start
						 */

						currentComponent = "tUniqRow_5";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "DimViolation", "tMap_1", "tMap_1", "tMap", "tUniqRow_5", "tUniqRow_5", "tUniqRow"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("DimViolation - " + (DimViolation == null ? "" : DimViolation.toLogString()));
						}

						row14 = null;
						if (DimViolation.Violation_Code == null) {
							finder_tUniqRow_5.Violation_Code = null;
						} else {
							finder_tUniqRow_5.Violation_Code = DimViolation.Violation_Code.toLowerCase();
						}
						finder_tUniqRow_5.hashCodeDirty = true;
						if (!keystUniqRow_5.contains(finder_tUniqRow_5)) {
							KeyStruct_tUniqRow_5 new_tUniqRow_5 = new KeyStruct_tUniqRow_5();

							if (DimViolation.Violation_Code == null) {
								new_tUniqRow_5.Violation_Code = null;
							} else {
								new_tUniqRow_5.Violation_Code = DimViolation.Violation_Code.toLowerCase();
							}

							keystUniqRow_5.add(new_tUniqRow_5);
							if (row14 == null) {

								log.trace("tUniqRow_5 - Writing the unique record " + (nb_uniques_tUniqRow_5 + 1)
										+ " into row14.");

								row14 = new row14Struct();
							}
							row14.Violation_ID = DimViolation.Violation_ID;
							row14.Violation_Code = DimViolation.Violation_Code;
							row14.Code_Score = DimViolation.Code_Score;
							row14.Violation_Category = DimViolation.Violation_Category;
							row14.DI_CreatedDate = DimViolation.DI_CreatedDate;
							row14.DI_WorkflowFileName = DimViolation.DI_WorkflowFileName;
							row14.DI_Workflow_ProcessID = DimViolation.DI_Workflow_ProcessID;
							nb_uniques_tUniqRow_5++;
						} else {
							nb_duplicates_tUniqRow_5++;
						}

						tos_count_tUniqRow_5++;

						/**
						 * [tUniqRow_5 main ] stop
						 */

						/**
						 * [tUniqRow_5 process_data_begin ] start
						 */

						currentComponent = "tUniqRow_5";

						/**
						 * [tUniqRow_5 process_data_begin ] stop
						 */
// Start of branch "row14"
						if (row14 != null) {

							/**
							 * [tDBOutput_5 main ] start
							 */

							currentComponent = "tDBOutput_5";

							cLabel = "ProcessingMySQL";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "row14", "tUniqRow_5", "tUniqRow_5", "tUniqRow", "tDBOutput_5", "ProcessingMySQL",
									"tMysqlOutput"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("row14 - " + (row14 == null ? "" : row14.toLogString()));
							}

							whetherReject_tDBOutput_5 = false;
							if (row14.Violation_ID == null) {
								pstmt_tDBOutput_5.setNull(1, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_5.setInt(1, row14.Violation_ID);
							}

							if (row14.Violation_Code == null) {
								pstmt_tDBOutput_5.setNull(2, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_5.setString(2, row14.Violation_Code);
							}

							if (row14.Code_Score == null) {
								pstmt_tDBOutput_5.setNull(3, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_5.setInt(3, row14.Code_Score);
							}

							if (row14.Violation_Category == null) {
								pstmt_tDBOutput_5.setNull(4, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_5.setString(4, row14.Violation_Category);
							}

							if (row14.DI_CreatedDate != null) {
								date_tDBOutput_5 = row14.DI_CreatedDate.getTime();
								if (date_tDBOutput_5 < year1_tDBOutput_5 || date_tDBOutput_5 >= year10000_tDBOutput_5) {
									pstmt_tDBOutput_5.setString(5, "0000-00-00 00:00:00");
								} else {
									pstmt_tDBOutput_5.setTimestamp(5, new java.sql.Timestamp(date_tDBOutput_5));
								}
							} else {
								pstmt_tDBOutput_5.setNull(5, java.sql.Types.DATE);
							}

							if (row14.DI_WorkflowFileName == null) {
								pstmt_tDBOutput_5.setNull(6, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_5.setString(6, row14.DI_WorkflowFileName);
							}

							if (row14.DI_Workflow_ProcessID == null) {
								pstmt_tDBOutput_5.setNull(7, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_5.setString(7, row14.DI_Workflow_ProcessID);
							}

							pstmt_tDBOutput_5.addBatch();
							nb_line_tDBOutput_5++;

							if (log.isDebugEnabled())
								log.debug("tDBOutput_5 - " + ("Adding the record ") + (nb_line_tDBOutput_5)
										+ (" to the ") + ("INSERT") + (" batch."));
							batchSizeCounter_tDBOutput_5++;
							if (batchSize_tDBOutput_5 <= batchSizeCounter_tDBOutput_5) {
								try {
									int countSum_tDBOutput_5 = 0;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_5 - " + ("Executing the ") + ("INSERT") + (" batch."));
									for (int countEach_tDBOutput_5 : pstmt_tDBOutput_5.executeBatch()) {
										countSum_tDBOutput_5 += (countEach_tDBOutput_5 == java.sql.Statement.EXECUTE_FAILED
												? 0
												: 1);
									}
									rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_5 - " + ("The ") + ("INSERT")
												+ (" batch execution has succeeded."));
									insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
								} catch (java.sql.BatchUpdateException e) {
									globalMap.put("tDBOutput_5_ERROR_MESSAGE", e.getMessage());
									int countSum_tDBOutput_5 = 0;
									for (int countEach_tDBOutput_5 : e.getUpdateCounts()) {
										countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
									}
									rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
									insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
									System.err.println(e.getMessage());
									log.error("tDBOutput_5 - " + (e.getMessage()));
								}

								batchSizeCounter_tDBOutput_5 = 0;
							}
							commitCounter_tDBOutput_5++;

							if (commitEvery_tDBOutput_5 <= commitCounter_tDBOutput_5) {

								try {
									int countSum_tDBOutput_5 = 0;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_5 - " + ("Executing the ") + ("INSERT") + (" batch."));
									for (int countEach_tDBOutput_5 : pstmt_tDBOutput_5.executeBatch()) {
										countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : 1);
									}
									rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_5 - " + ("The ") + ("INSERT")
												+ (" batch execution has succeeded."));
									insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
								} catch (java.sql.BatchUpdateException e) {
									globalMap.put("tDBOutput_5_ERROR_MESSAGE", e.getMessage());
									int countSum_tDBOutput_5 = 0;
									for (int countEach_tDBOutput_5 : e.getUpdateCounts()) {
										countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
									}
									rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
									insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
									System.err.println(e.getMessage());
									log.error("tDBOutput_5 - " + (e.getMessage()));

								}
								if (rowsToCommitCount_tDBOutput_5 != 0) {
									if (log.isDebugEnabled())
										log.debug("tDBOutput_5 - " + ("Connection starting to commit ")
												+ (rowsToCommitCount_tDBOutput_5) + (" record(s)."));
								}
								conn_tDBOutput_5.commit();
								if (rowsToCommitCount_tDBOutput_5 != 0) {
									if (log.isDebugEnabled())
										log.debug("tDBOutput_5 - " + ("Connection commit has succeeded."));
									rowsToCommitCount_tDBOutput_5 = 0;
								}
								commitCounter_tDBOutput_5 = 0;
							}

							tos_count_tDBOutput_5++;

							/**
							 * [tDBOutput_5 main ] stop
							 */

							/**
							 * [tDBOutput_5 process_data_begin ] start
							 */

							currentComponent = "tDBOutput_5";

							cLabel = "ProcessingMySQL";

							/**
							 * [tDBOutput_5 process_data_begin ] stop
							 */

							/**
							 * [tDBOutput_5 process_data_end ] start
							 */

							currentComponent = "tDBOutput_5";

							cLabel = "ProcessingMySQL";

							/**
							 * [tDBOutput_5 process_data_end ] stop
							 */

						} // End of branch "row14"

						/**
						 * [tUniqRow_5 process_data_end ] start
						 */

						currentComponent = "tUniqRow_5";

						/**
						 * [tUniqRow_5 process_data_end ] stop
						 */

					} // End of branch "DimViolation"

// Start of branch "DimBusiness"
					if (DimBusiness != null) {

						/**
						 * [tUniqRow_1 main ] start
						 */

						currentComponent = "tUniqRow_1";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "DimBusiness", "tMap_1", "tMap_1", "tMap", "tUniqRow_1", "tUniqRow_1", "tUniqRow"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("DimBusiness - " + (DimBusiness == null ? "" : DimBusiness.toLogString()));
						}

						row5 = null;
						if (DimBusiness.BusinessId == null) {
							finder_tUniqRow_1.BusinessId = null;
						} else {
							finder_tUniqRow_1.BusinessId = DimBusiness.BusinessId.toLowerCase();
						}
						finder_tUniqRow_1.hashCodeDirty = true;
						if (!keystUniqRow_1.contains(finder_tUniqRow_1)) {
							KeyStruct_tUniqRow_1 new_tUniqRow_1 = new KeyStruct_tUniqRow_1();

							if (DimBusiness.BusinessId == null) {
								new_tUniqRow_1.BusinessId = null;
							} else {
								new_tUniqRow_1.BusinessId = DimBusiness.BusinessId.toLowerCase();
							}

							keystUniqRow_1.add(new_tUniqRow_1);
							if (row5 == null) {

								log.trace("tUniqRow_1 - Writing the unique record " + (nb_uniques_tUniqRow_1 + 1)
										+ " into row5.");

								row5 = new row5Struct();
							}
							row5.Business_ID_SK = DimBusiness.Business_ID_SK;
							row5.BusinessId = DimBusiness.BusinessId;
							row5.Name = DimBusiness.Name;
							row5.PhoneNumber = DimBusiness.PhoneNumber;
							row5.DI_CreatedDate = DimBusiness.DI_CreatedDate;
							row5.DI_WorkflowFileName = DimBusiness.DI_WorkflowFileName;
							row5.DI_Workflow_ProcessID = DimBusiness.DI_Workflow_ProcessID;
							nb_uniques_tUniqRow_1++;
						} else {
							nb_duplicates_tUniqRow_1++;
						}

						tos_count_tUniqRow_1++;

						/**
						 * [tUniqRow_1 main ] stop
						 */

						/**
						 * [tUniqRow_1 process_data_begin ] start
						 */

						currentComponent = "tUniqRow_1";

						/**
						 * [tUniqRow_1 process_data_begin ] stop
						 */
// Start of branch "row5"
						if (row5 != null) {

							/**
							 * [tDBOutput_4 main ] start
							 */

							currentComponent = "tDBOutput_4";

							cLabel = "ProcessingMySQL";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "row5", "tUniqRow_1", "tUniqRow_1", "tUniqRow", "tDBOutput_4", "ProcessingMySQL",
									"tMysqlOutput"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("row5 - " + (row5 == null ? "" : row5.toLogString()));
							}

							whetherReject_tDBOutput_4 = false;
							if (row5.Business_ID_SK == null) {
								pstmt_tDBOutput_4.setNull(1, java.sql.Types.INTEGER);
							} else {
								pstmt_tDBOutput_4.setInt(1, row5.Business_ID_SK);
							}

							if (row5.BusinessId == null) {
								pstmt_tDBOutput_4.setNull(2, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_4.setString(2, row5.BusinessId);
							}

							if (row5.Name == null) {
								pstmt_tDBOutput_4.setNull(3, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_4.setString(3, row5.Name);
							}

							if (row5.PhoneNumber == null) {
								pstmt_tDBOutput_4.setNull(4, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_4.setString(4, row5.PhoneNumber);
							}

							if (row5.DI_CreatedDate != null) {
								date_tDBOutput_4 = row5.DI_CreatedDate.getTime();
								if (date_tDBOutput_4 < year1_tDBOutput_4 || date_tDBOutput_4 >= year10000_tDBOutput_4) {
									pstmt_tDBOutput_4.setString(5, "0000-00-00 00:00:00");
								} else {
									pstmt_tDBOutput_4.setTimestamp(5, new java.sql.Timestamp(date_tDBOutput_4));
								}
							} else {
								pstmt_tDBOutput_4.setNull(5, java.sql.Types.DATE);
							}

							if (row5.DI_WorkflowFileName == null) {
								pstmt_tDBOutput_4.setNull(6, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_4.setString(6, row5.DI_WorkflowFileName);
							}

							if (row5.DI_Workflow_ProcessID == null) {
								pstmt_tDBOutput_4.setNull(7, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_4.setString(7, row5.DI_Workflow_ProcessID);
							}

							pstmt_tDBOutput_4.addBatch();
							nb_line_tDBOutput_4++;

							if (log.isDebugEnabled())
								log.debug("tDBOutput_4 - " + ("Adding the record ") + (nb_line_tDBOutput_4)
										+ (" to the ") + ("INSERT") + (" batch."));
							batchSizeCounter_tDBOutput_4++;
							if (batchSize_tDBOutput_4 <= batchSizeCounter_tDBOutput_4) {
								try {
									int countSum_tDBOutput_4 = 0;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_4 - " + ("Executing the ") + ("INSERT") + (" batch."));
									for (int countEach_tDBOutput_4 : pstmt_tDBOutput_4.executeBatch()) {
										countSum_tDBOutput_4 += (countEach_tDBOutput_4 == java.sql.Statement.EXECUTE_FAILED
												? 0
												: 1);
									}
									rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_4 - " + ("The ") + ("INSERT")
												+ (" batch execution has succeeded."));
									insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
								} catch (java.sql.BatchUpdateException e) {
									globalMap.put("tDBOutput_4_ERROR_MESSAGE", e.getMessage());
									int countSum_tDBOutput_4 = 0;
									for (int countEach_tDBOutput_4 : e.getUpdateCounts()) {
										countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
									}
									rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
									insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
									System.err.println(e.getMessage());
									log.error("tDBOutput_4 - " + (e.getMessage()));
								}

								batchSizeCounter_tDBOutput_4 = 0;
							}
							commitCounter_tDBOutput_4++;

							if (commitEvery_tDBOutput_4 <= commitCounter_tDBOutput_4) {

								try {
									int countSum_tDBOutput_4 = 0;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_4 - " + ("Executing the ") + ("INSERT") + (" batch."));
									for (int countEach_tDBOutput_4 : pstmt_tDBOutput_4.executeBatch()) {
										countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : 1);
									}
									rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_4 - " + ("The ") + ("INSERT")
												+ (" batch execution has succeeded."));
									insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
								} catch (java.sql.BatchUpdateException e) {
									globalMap.put("tDBOutput_4_ERROR_MESSAGE", e.getMessage());
									int countSum_tDBOutput_4 = 0;
									for (int countEach_tDBOutput_4 : e.getUpdateCounts()) {
										countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
									}
									rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
									insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
									System.err.println(e.getMessage());
									log.error("tDBOutput_4 - " + (e.getMessage()));

								}
								if (rowsToCommitCount_tDBOutput_4 != 0) {
									if (log.isDebugEnabled())
										log.debug("tDBOutput_4 - " + ("Connection starting to commit ")
												+ (rowsToCommitCount_tDBOutput_4) + (" record(s)."));
								}
								conn_tDBOutput_4.commit();
								if (rowsToCommitCount_tDBOutput_4 != 0) {
									if (log.isDebugEnabled())
										log.debug("tDBOutput_4 - " + ("Connection commit has succeeded."));
									rowsToCommitCount_tDBOutput_4 = 0;
								}
								commitCounter_tDBOutput_4 = 0;
							}

							tos_count_tDBOutput_4++;

							/**
							 * [tDBOutput_4 main ] stop
							 */

							/**
							 * [tDBOutput_4 process_data_begin ] start
							 */

							currentComponent = "tDBOutput_4";

							cLabel = "ProcessingMySQL";

							/**
							 * [tDBOutput_4 process_data_begin ] stop
							 */

							/**
							 * [tDBOutput_4 process_data_end ] start
							 */

							currentComponent = "tDBOutput_4";

							cLabel = "ProcessingMySQL";

							/**
							 * [tDBOutput_4 process_data_end ] stop
							 */

						} // End of branch "row5"

						/**
						 * [tUniqRow_1 process_data_end ] start
						 */

						currentComponent = "tUniqRow_1";

						/**
						 * [tUniqRow_1 process_data_end ] stop
						 */

					} // End of branch "DimBusiness"

					/**
					 * [tMap_1 process_data_end ] start
					 */

					currentComponent = "tMap_1";

					/**
					 * [tMap_1 process_data_end ] stop
					 */

					/**
					 * [tHashInput_3 process_data_end ] start
					 */

					currentComponent = "tHashInput_3";

					/**
					 * [tHashInput_3 process_data_end ] stop
					 */

					/**
					 * [tHashInput_3 end ] start
					 */

					currentComponent = "tHashInput_3";

					nb_line_tHashInput_3++;
				}

				org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap
						.remove("tHashFile_DataPreparation_" + pid + "_tHashOutput_3");

				globalMap.put("tHashInput_3_NB_LINE", nb_line_tHashInput_3);

				ok_Hash.put("tHashInput_3", true);
				end_Hash.put("tHashInput_3", System.currentTimeMillis());

				/**
				 * [tHashInput_3 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
				if (tHash_Lookup_row13 != null) {
					tHash_Lookup_row13.endGet();
				}
				globalMap.remove("tHash_Lookup_row13");

// ###############################      
				log.debug("tMap_1 - Written records count in the table 'DimDate': " + count_DimDate_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'DimInspectionType': "
						+ count_DimInspectionType_tMap_1 + ".");
				log.debug(
						"tMap_1 - Written records count in the table 'DimLocation': " + count_DimLocation_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'DimViolation': " + count_DimViolation_tMap_1
						+ ".");
				log.debug(
						"tMap_1 - Written records count in the table 'DimBusiness': " + count_DimBusiness_tMap_1 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row12", 2, 0,
						"tHashInput_3", "tHashInput_3", "tHashInput", "tMap_1", "tMap_1", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Done."));

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tUniqRow_4 end ] start
				 */

				currentComponent = "tUniqRow_4";

				globalMap.put("tUniqRow_4_NB_UNIQUES", nb_uniques_tUniqRow_4);
				globalMap.put("tUniqRow_4_NB_DUPLICATES", nb_duplicates_tUniqRow_4);
				log.info("tUniqRow_4 - Unique records count: " + (nb_uniques_tUniqRow_4) + " .");
				log.info("tUniqRow_4 - Duplicate records count: " + (nb_duplicates_tUniqRow_4) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "DimDate", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_4", "tUniqRow_4", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_4 - " + ("Done."));

				ok_Hash.put("tUniqRow_4", true);
				end_Hash.put("tUniqRow_4", System.currentTimeMillis());

				/**
				 * [tUniqRow_4 end ] stop
				 */

				/**
				 * [tDBOutput_1 end ] start
				 */

				currentComponent = "tDBOutput_1";

				cLabel = "ProcessingMySQL";

				try {
					if (batchSizeCounter_tDBOutput_1 != 0) {
						int countSum_tDBOutput_1 = 0;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 == java.sql.Statement.EXECUTE_FAILED ? 0
									: 1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));

						insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

					}
				} catch (java.sql.BatchUpdateException e) {
					globalMap.put(currentComponent + "_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_1 = 0;
					for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

					log.error("tDBOutput_1 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				batchSizeCounter_tDBOutput_1 = 0;

				if (pstmt_tDBOutput_1 != null) {

					pstmt_tDBOutput_1.close();
					resourceMap.remove("pstmt_tDBOutput_1");

				}

				resourceMap.put("statementClosed_tDBOutput_1", true);

				if (commitCounter_tDBOutput_1 > 0 && rowsToCommitCount_tDBOutput_1 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_1) + (" record(s)."));
				}
				conn_tDBOutput_1.commit();
				if (commitCounter_tDBOutput_1 > 0 && rowsToCommitCount_tDBOutput_1 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_1 = 0;
				}
				commitCounter_tDBOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Closing the connection to the database."));
				conn_tDBOutput_1.close();

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_1", true);

				nb_line_deleted_tDBOutput_1 = nb_line_deleted_tDBOutput_1 + deletedCount_tDBOutput_1;
				nb_line_update_tDBOutput_1 = nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
				nb_line_inserted_tDBOutput_1 = nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
				nb_line_rejected_tDBOutput_1 = nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;

				globalMap.put("tDBOutput_1_NB_LINE", nb_line_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_UPDATED", nb_line_update_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_DELETED", nb_line_deleted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_1)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row8", 2, 0,
						"tUniqRow_4", "tUniqRow_4", "tUniqRow", "tDBOutput_1", "ProcessingMySQL", "tMysqlOutput",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Done."));

				ok_Hash.put("tDBOutput_1", true);
				end_Hash.put("tDBOutput_1", System.currentTimeMillis());

				/**
				 * [tDBOutput_1 end ] stop
				 */

				/**
				 * [tUniqRow_3 end ] start
				 */

				currentComponent = "tUniqRow_3";

				globalMap.put("tUniqRow_3_NB_UNIQUES", nb_uniques_tUniqRow_3);
				globalMap.put("tUniqRow_3_NB_DUPLICATES", nb_duplicates_tUniqRow_3);
				log.info("tUniqRow_3 - Unique records count: " + (nb_uniques_tUniqRow_3) + " .");
				log.info("tUniqRow_3 - Duplicate records count: " + (nb_duplicates_tUniqRow_3) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "DimInspectionType", 2,
						0, "tMap_1", "tMap_1", "tMap", "tUniqRow_3", "tUniqRow_3", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_3 - " + ("Done."));

				ok_Hash.put("tUniqRow_3", true);
				end_Hash.put("tUniqRow_3", System.currentTimeMillis());

				/**
				 * [tUniqRow_3 end ] stop
				 */

				/**
				 * [tDBOutput_2 end ] start
				 */

				currentComponent = "tDBOutput_2";

				cLabel = "ProcessingMySQL";

				try {
					if (batchSizeCounter_tDBOutput_2 != 0) {
						int countSum_tDBOutput_2 = 0;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_2 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_2 : pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 == java.sql.Statement.EXECUTE_FAILED ? 0
									: 1);
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_2 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));

						insertedCount_tDBOutput_2 += countSum_tDBOutput_2;

					}
				} catch (java.sql.BatchUpdateException e) {
					globalMap.put(currentComponent + "_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_2 = 0;
					for (int countEach_tDBOutput_2 : e.getUpdateCounts()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;

					insertedCount_tDBOutput_2 += countSum_tDBOutput_2;

					log.error("tDBOutput_2 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				batchSizeCounter_tDBOutput_2 = 0;

				if (pstmt_tDBOutput_2 != null) {

					pstmt_tDBOutput_2.close();
					resourceMap.remove("pstmt_tDBOutput_2");

				}

				resourceMap.put("statementClosed_tDBOutput_2", true);

				if (commitCounter_tDBOutput_2 > 0 && rowsToCommitCount_tDBOutput_2 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_2 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_2) + (" record(s)."));
				}
				conn_tDBOutput_2.commit();
				if (commitCounter_tDBOutput_2 > 0 && rowsToCommitCount_tDBOutput_2 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_2 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_2 = 0;
				}
				commitCounter_tDBOutput_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Closing the connection to the database."));
				conn_tDBOutput_2.close();

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_2", true);

				nb_line_deleted_tDBOutput_2 = nb_line_deleted_tDBOutput_2 + deletedCount_tDBOutput_2;
				nb_line_update_tDBOutput_2 = nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
				nb_line_inserted_tDBOutput_2 = nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
				nb_line_rejected_tDBOutput_2 = nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;

				globalMap.put("tDBOutput_2_NB_LINE", nb_line_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_UPDATED", nb_line_update_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_DELETED", nb_line_deleted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_2)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row7", 2, 0,
						"tUniqRow_3", "tUniqRow_3", "tUniqRow", "tDBOutput_2", "ProcessingMySQL", "tMysqlOutput",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_2 - " + ("Done."));

				ok_Hash.put("tDBOutput_2", true);
				end_Hash.put("tDBOutput_2", System.currentTimeMillis());

				/**
				 * [tDBOutput_2 end ] stop
				 */

				/**
				 * [tUniqRow_2 end ] start
				 */

				currentComponent = "tUniqRow_2";

				globalMap.put("tUniqRow_2_NB_UNIQUES", nb_uniques_tUniqRow_2);
				globalMap.put("tUniqRow_2_NB_DUPLICATES", nb_duplicates_tUniqRow_2);
				log.info("tUniqRow_2 - Unique records count: " + (nb_uniques_tUniqRow_2) + " .");
				log.info("tUniqRow_2 - Duplicate records count: " + (nb_duplicates_tUniqRow_2) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "DimLocation", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_2", "tUniqRow_2", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_2 - " + ("Done."));

				ok_Hash.put("tUniqRow_2", true);
				end_Hash.put("tUniqRow_2", System.currentTimeMillis());

				/**
				 * [tUniqRow_2 end ] stop
				 */

				/**
				 * [tDBOutput_3 end ] start
				 */

				currentComponent = "tDBOutput_3";

				cLabel = "ProcessingMySQL";

				try {
					if (batchSizeCounter_tDBOutput_3 != 0) {
						int countSum_tDBOutput_3 = 0;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_3 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_3 : pstmt_tDBOutput_3.executeBatch()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 == java.sql.Statement.EXECUTE_FAILED ? 0
									: 1);
						}
						rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_3 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));

						insertedCount_tDBOutput_3 += countSum_tDBOutput_3;

					}
				} catch (java.sql.BatchUpdateException e) {
					globalMap.put(currentComponent + "_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_3 = 0;
					for (int countEach_tDBOutput_3 : e.getUpdateCounts()) {
						countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
					}
					rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;

					insertedCount_tDBOutput_3 += countSum_tDBOutput_3;

					log.error("tDBOutput_3 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				batchSizeCounter_tDBOutput_3 = 0;

				if (pstmt_tDBOutput_3 != null) {

					pstmt_tDBOutput_3.close();
					resourceMap.remove("pstmt_tDBOutput_3");

				}

				resourceMap.put("statementClosed_tDBOutput_3", true);

				if (commitCounter_tDBOutput_3 > 0 && rowsToCommitCount_tDBOutput_3 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_3 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_3) + (" record(s)."));
				}
				conn_tDBOutput_3.commit();
				if (commitCounter_tDBOutput_3 > 0 && rowsToCommitCount_tDBOutput_3 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_3 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_3 = 0;
				}
				commitCounter_tDBOutput_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Closing the connection to the database."));
				conn_tDBOutput_3.close();

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_3", true);

				nb_line_deleted_tDBOutput_3 = nb_line_deleted_tDBOutput_3 + deletedCount_tDBOutput_3;
				nb_line_update_tDBOutput_3 = nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
				nb_line_inserted_tDBOutput_3 = nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
				nb_line_rejected_tDBOutput_3 = nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;

				globalMap.put("tDBOutput_3_NB_LINE", nb_line_tDBOutput_3);
				globalMap.put("tDBOutput_3_NB_LINE_UPDATED", nb_line_update_tDBOutput_3);
				globalMap.put("tDBOutput_3_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_3);
				globalMap.put("tDBOutput_3_NB_LINE_DELETED", nb_line_deleted_tDBOutput_3);
				globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_3)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row6", 2, 0,
						"tUniqRow_2", "tUniqRow_2", "tUniqRow", "tDBOutput_3", "ProcessingMySQL", "tMysqlOutput",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_3 - " + ("Done."));

				ok_Hash.put("tDBOutput_3", true);
				end_Hash.put("tDBOutput_3", System.currentTimeMillis());

				/**
				 * [tDBOutput_3 end ] stop
				 */

				/**
				 * [tUniqRow_5 end ] start
				 */

				currentComponent = "tUniqRow_5";

				globalMap.put("tUniqRow_5_NB_UNIQUES", nb_uniques_tUniqRow_5);
				globalMap.put("tUniqRow_5_NB_DUPLICATES", nb_duplicates_tUniqRow_5);
				log.info("tUniqRow_5 - Unique records count: " + (nb_uniques_tUniqRow_5) + " .");
				log.info("tUniqRow_5 - Duplicate records count: " + (nb_duplicates_tUniqRow_5) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "DimViolation", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_5", "tUniqRow_5", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_5 - " + ("Done."));

				ok_Hash.put("tUniqRow_5", true);
				end_Hash.put("tUniqRow_5", System.currentTimeMillis());

				/**
				 * [tUniqRow_5 end ] stop
				 */

				/**
				 * [tDBOutput_5 end ] start
				 */

				currentComponent = "tDBOutput_5";

				cLabel = "ProcessingMySQL";

				try {
					if (batchSizeCounter_tDBOutput_5 != 0) {
						int countSum_tDBOutput_5 = 0;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_5 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_5 : pstmt_tDBOutput_5.executeBatch()) {
							countSum_tDBOutput_5 += (countEach_tDBOutput_5 == java.sql.Statement.EXECUTE_FAILED ? 0
									: 1);
						}
						rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_5 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));

						insertedCount_tDBOutput_5 += countSum_tDBOutput_5;

					}
				} catch (java.sql.BatchUpdateException e) {
					globalMap.put(currentComponent + "_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_5 = 0;
					for (int countEach_tDBOutput_5 : e.getUpdateCounts()) {
						countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
					}
					rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;

					insertedCount_tDBOutput_5 += countSum_tDBOutput_5;

					log.error("tDBOutput_5 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				batchSizeCounter_tDBOutput_5 = 0;

				if (pstmt_tDBOutput_5 != null) {

					pstmt_tDBOutput_5.close();
					resourceMap.remove("pstmt_tDBOutput_5");

				}

				resourceMap.put("statementClosed_tDBOutput_5", true);

				if (commitCounter_tDBOutput_5 > 0 && rowsToCommitCount_tDBOutput_5 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_5 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_5) + (" record(s)."));
				}
				conn_tDBOutput_5.commit();
				if (commitCounter_tDBOutput_5 > 0 && rowsToCommitCount_tDBOutput_5 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_5 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_5 = 0;
				}
				commitCounter_tDBOutput_5 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Closing the connection to the database."));
				conn_tDBOutput_5.close();

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_5", true);

				nb_line_deleted_tDBOutput_5 = nb_line_deleted_tDBOutput_5 + deletedCount_tDBOutput_5;
				nb_line_update_tDBOutput_5 = nb_line_update_tDBOutput_5 + updatedCount_tDBOutput_5;
				nb_line_inserted_tDBOutput_5 = nb_line_inserted_tDBOutput_5 + insertedCount_tDBOutput_5;
				nb_line_rejected_tDBOutput_5 = nb_line_rejected_tDBOutput_5 + rejectedCount_tDBOutput_5;

				globalMap.put("tDBOutput_5_NB_LINE", nb_line_tDBOutput_5);
				globalMap.put("tDBOutput_5_NB_LINE_UPDATED", nb_line_update_tDBOutput_5);
				globalMap.put("tDBOutput_5_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_5);
				globalMap.put("tDBOutput_5_NB_LINE_DELETED", nb_line_deleted_tDBOutput_5);
				globalMap.put("tDBOutput_5_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_5);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_5)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row14", 2, 0,
						"tUniqRow_5", "tUniqRow_5", "tUniqRow", "tDBOutput_5", "ProcessingMySQL", "tMysqlOutput",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_5 - " + ("Done."));

				ok_Hash.put("tDBOutput_5", true);
				end_Hash.put("tDBOutput_5", System.currentTimeMillis());

				/**
				 * [tDBOutput_5 end ] stop
				 */

				/**
				 * [tUniqRow_1 end ] start
				 */

				currentComponent = "tUniqRow_1";

				globalMap.put("tUniqRow_1_NB_UNIQUES", nb_uniques_tUniqRow_1);
				globalMap.put("tUniqRow_1_NB_DUPLICATES", nb_duplicates_tUniqRow_1);
				log.info("tUniqRow_1 - Unique records count: " + (nb_uniques_tUniqRow_1) + " .");
				log.info("tUniqRow_1 - Duplicate records count: " + (nb_duplicates_tUniqRow_1) + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "DimBusiness", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tUniqRow_1", "tUniqRow_1", "tUniqRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tUniqRow_1 - " + ("Done."));

				ok_Hash.put("tUniqRow_1", true);
				end_Hash.put("tUniqRow_1", System.currentTimeMillis());

				/**
				 * [tUniqRow_1 end ] stop
				 */

				/**
				 * [tDBOutput_4 end ] start
				 */

				currentComponent = "tDBOutput_4";

				cLabel = "ProcessingMySQL";

				try {
					if (batchSizeCounter_tDBOutput_4 != 0) {
						int countSum_tDBOutput_4 = 0;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_4 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_4 : pstmt_tDBOutput_4.executeBatch()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 == java.sql.Statement.EXECUTE_FAILED ? 0
									: 1);
						}
						rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_4 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));

						insertedCount_tDBOutput_4 += countSum_tDBOutput_4;

					}
				} catch (java.sql.BatchUpdateException e) {
					globalMap.put(currentComponent + "_ERROR_MESSAGE", e.getMessage());

					int countSum_tDBOutput_4 = 0;
					for (int countEach_tDBOutput_4 : e.getUpdateCounts()) {
						countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
					}
					rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;

					insertedCount_tDBOutput_4 += countSum_tDBOutput_4;

					log.error("tDBOutput_4 - " + (e.getMessage()));
					System.err.println(e.getMessage());

				}
				batchSizeCounter_tDBOutput_4 = 0;

				if (pstmt_tDBOutput_4 != null) {

					pstmt_tDBOutput_4.close();
					resourceMap.remove("pstmt_tDBOutput_4");

				}

				resourceMap.put("statementClosed_tDBOutput_4", true);

				if (commitCounter_tDBOutput_4 > 0 && rowsToCommitCount_tDBOutput_4 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_4 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_4) + (" record(s)."));
				}
				conn_tDBOutput_4.commit();
				if (commitCounter_tDBOutput_4 > 0 && rowsToCommitCount_tDBOutput_4 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_4 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_4 = 0;
				}
				commitCounter_tDBOutput_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Closing the connection to the database."));
				conn_tDBOutput_4.close();

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_4", true);

				nb_line_deleted_tDBOutput_4 = nb_line_deleted_tDBOutput_4 + deletedCount_tDBOutput_4;
				nb_line_update_tDBOutput_4 = nb_line_update_tDBOutput_4 + updatedCount_tDBOutput_4;
				nb_line_inserted_tDBOutput_4 = nb_line_inserted_tDBOutput_4 + insertedCount_tDBOutput_4;
				nb_line_rejected_tDBOutput_4 = nb_line_rejected_tDBOutput_4 + rejectedCount_tDBOutput_4;

				globalMap.put("tDBOutput_4_NB_LINE", nb_line_tDBOutput_4);
				globalMap.put("tDBOutput_4_NB_LINE_UPDATED", nb_line_update_tDBOutput_4);
				globalMap.put("tDBOutput_4_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_4);
				globalMap.put("tDBOutput_4_NB_LINE_DELETED", nb_line_deleted_tDBOutput_4);
				globalMap.put("tDBOutput_4_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_4);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_4)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row5", 2, 0,
						"tUniqRow_1", "tUniqRow_1", "tUniqRow", "tDBOutput_4", "ProcessingMySQL", "tMysqlOutput",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_4 - " + ("Done."));

				ok_Hash.put("tDBOutput_4", true);
				end_Hash.put("tDBOutput_4", System.currentTimeMillis());

				/**
				 * [tDBOutput_4 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_row13");

			try {

				/**
				 * [tHashInput_3 finally ] start
				 */

				currentComponent = "tHashInput_3";

				/**
				 * [tHashInput_3 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tUniqRow_4 finally ] start
				 */

				currentComponent = "tUniqRow_4";

				/**
				 * [tUniqRow_4 finally ] stop
				 */

				/**
				 * [tDBOutput_1 finally ] start
				 */

				currentComponent = "tDBOutput_1";

				cLabel = "ProcessingMySQL";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
						if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_1")) != null) {
							pstmtToClose_tDBOutput_1.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_1") == null) {
						java.sql.Connection ctn_tDBOutput_1 = null;
						if ((ctn_tDBOutput_1 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_1")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_1.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_1) {
								String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :"
										+ sqlEx_tDBOutput_1.getMessage();
								log.error("tDBOutput_1 - " + (errorMessage_tDBOutput_1));
								System.err.println(errorMessage_tDBOutput_1);
							}
						}
					}
				}

				/**
				 * [tDBOutput_1 finally ] stop
				 */

				/**
				 * [tUniqRow_3 finally ] start
				 */

				currentComponent = "tUniqRow_3";

				/**
				 * [tUniqRow_3 finally ] stop
				 */

				/**
				 * [tDBOutput_2 finally ] start
				 */

				currentComponent = "tDBOutput_2";

				cLabel = "ProcessingMySQL";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
						if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_2")) != null) {
							pstmtToClose_tDBOutput_2.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_2") == null) {
						java.sql.Connection ctn_tDBOutput_2 = null;
						if ((ctn_tDBOutput_2 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_2")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_2 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_2.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_2 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_2) {
								String errorMessage_tDBOutput_2 = "failed to close the connection in tDBOutput_2 :"
										+ sqlEx_tDBOutput_2.getMessage();
								log.error("tDBOutput_2 - " + (errorMessage_tDBOutput_2));
								System.err.println(errorMessage_tDBOutput_2);
							}
						}
					}
				}

				/**
				 * [tDBOutput_2 finally ] stop
				 */

				/**
				 * [tUniqRow_2 finally ] start
				 */

				currentComponent = "tUniqRow_2";

				/**
				 * [tUniqRow_2 finally ] stop
				 */

				/**
				 * [tDBOutput_3 finally ] start
				 */

				currentComponent = "tDBOutput_3";

				cLabel = "ProcessingMySQL";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
						if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_3")) != null) {
							pstmtToClose_tDBOutput_3.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_3") == null) {
						java.sql.Connection ctn_tDBOutput_3 = null;
						if ((ctn_tDBOutput_3 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_3")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_3 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_3.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_3 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_3) {
								String errorMessage_tDBOutput_3 = "failed to close the connection in tDBOutput_3 :"
										+ sqlEx_tDBOutput_3.getMessage();
								log.error("tDBOutput_3 - " + (errorMessage_tDBOutput_3));
								System.err.println(errorMessage_tDBOutput_3);
							}
						}
					}
				}

				/**
				 * [tDBOutput_3 finally ] stop
				 */

				/**
				 * [tUniqRow_5 finally ] start
				 */

				currentComponent = "tUniqRow_5";

				/**
				 * [tUniqRow_5 finally ] stop
				 */

				/**
				 * [tDBOutput_5 finally ] start
				 */

				currentComponent = "tDBOutput_5";

				cLabel = "ProcessingMySQL";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_5") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_5 = null;
						if ((pstmtToClose_tDBOutput_5 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_5")) != null) {
							pstmtToClose_tDBOutput_5.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_5") == null) {
						java.sql.Connection ctn_tDBOutput_5 = null;
						if ((ctn_tDBOutput_5 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_5")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_5 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_5.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_5 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_5) {
								String errorMessage_tDBOutput_5 = "failed to close the connection in tDBOutput_5 :"
										+ sqlEx_tDBOutput_5.getMessage();
								log.error("tDBOutput_5 - " + (errorMessage_tDBOutput_5));
								System.err.println(errorMessage_tDBOutput_5);
							}
						}
					}
				}

				/**
				 * [tDBOutput_5 finally ] stop
				 */

				/**
				 * [tUniqRow_1 finally ] start
				 */

				currentComponent = "tUniqRow_1";

				/**
				 * [tUniqRow_1 finally ] stop
				 */

				/**
				 * [tDBOutput_4 finally ] start
				 */

				currentComponent = "tDBOutput_4";

				cLabel = "ProcessingMySQL";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_4") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_4 = null;
						if ((pstmtToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_4")) != null) {
							pstmtToClose_tDBOutput_4.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_4") == null) {
						java.sql.Connection ctn_tDBOutput_4 = null;
						if ((ctn_tDBOutput_4 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_4")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_4 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_4.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_4 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_4) {
								String errorMessage_tDBOutput_4 = "failed to close the connection in tDBOutput_4 :"
										+ sqlEx_tDBOutput_4.getMessage();
								log.error("tDBOutput_4 - " + (errorMessage_tDBOutput_4));
								System.err.println(errorMessage_tDBOutput_4);
							}
						}
					}
				}

				/**
				 * [tDBOutput_4 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tHashInput_3_SUBPROCESS_STATE", 1);
	}

	public static class row10Struct implements routines.system.IPersistableComparableLookupRow<row10Struct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public String ViolationCodes;

		public String getViolationCodes() {
			return this.ViolationCodes;
		}

		public Boolean ViolationCodesIsNullable() {
			return true;
		}

		public Boolean ViolationCodesIsKey() {
			return false;
		}

		public Integer ViolationCodesLength() {
			return 150;
		}

		public Integer ViolationCodesPrecision() {
			return 0;
		}

		public String ViolationCodesDefault() {

			return null;

		}

		public String ViolationCodesComment() {

			return "";

		}

		public String ViolationCodesPattern() {

			return "";

		}

		public String ViolationCodesOriginalDbColumnName() {

			return "ViolationCodes";

		}

		public Integer Violation_ID;

		public Integer getViolation_ID() {
			return this.Violation_ID;
		}

		public Boolean Violation_IDIsNullable() {
			return true;
		}

		public Boolean Violation_IDIsKey() {
			return false;
		}

		public Integer Violation_IDLength() {
			return null;
		}

		public Integer Violation_IDPrecision() {
			return null;
		}

		public String Violation_IDDefault() {

			return null;

		}

		public String Violation_IDComment() {

			return "";

		}

		public String Violation_IDPattern() {

			return "";

		}

		public String Violation_IDOriginalDbColumnName() {

			return "Violation_ID";

		}

		public String InspectionId;

		public String getInspectionId() {
			return this.InspectionId;
		}

		public Boolean InspectionIdIsNullable() {
			return true;
		}

		public Boolean InspectionIdIsKey() {
			return false;
		}

		public Integer InspectionIdLength() {
			return 9;
		}

		public Integer InspectionIdPrecision() {
			return 0;
		}

		public String InspectionIdDefault() {

			return null;

		}

		public String InspectionIdComment() {

			return "";

		}

		public String InspectionIdPattern() {

			return "";

		}

		public String InspectionIdOriginalDbColumnName() {

			return "InspectionId";

		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.Violation_ID == null) ? 0 : this.Violation_ID.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row10Struct other = (row10Struct) obj;

			if (this.Violation_ID == null) {
				if (other.Violation_ID != null)
					return false;

			} else if (!this.Violation_ID.equals(other.Violation_ID))

				return false;

			return true;
		}

		public void copyDataTo(row10Struct other) {

			other.ViolationCodes = this.ViolationCodes;
			other.Violation_ID = this.Violation_ID;
			other.InspectionId = this.InspectionId;

		}

		public void copyKeysDataTo(row10Struct other) {

			other.Violation_ID = this.Violation_ID;

		}

		private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				dis.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				unmarshaller.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Violation_ID = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.Violation_ID = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.Violation_ID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.Violation_ID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				this.ViolationCodes = readString(dis, ois);

				this.InspectionId = readString(dis, ois);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
			try {
				int length = 0;

				this.ViolationCodes = readString(dis, objectIn);

				this.InspectionId = readString(dis, objectIn);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				writeString(this.ViolationCodes, dos, oos);

				writeString(this.InspectionId, dos, oos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut) {
			try {

				writeString(this.ViolationCodes, dos, objectOut);

				writeString(this.InspectionId, dos, objectOut);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		public boolean supportMarshaller() {
			return true;
		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("ViolationCodes=" + ViolationCodes);
			sb.append(",Violation_ID=" + String.valueOf(Violation_ID));
			sb.append(",InspectionId=" + InspectionId);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (ViolationCodes == null) {
				sb.append("<null>");
			} else {
				sb.append(ViolationCodes);
			}

			sb.append("|");

			if (Violation_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(Violation_ID);
			}

			sb.append("|");

			if (InspectionId == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionId);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row10Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.Violation_ID, other.Violation_ID);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tHashInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tHashInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tHashInput_1");
		org.slf4j.MDC.put("_subJobPid", "JFSjAF_" + subJobPidCounter.getAndIncrement());

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row10Struct row10 = new row10Struct();

				/**
				 * [tAdvancedHash_row10 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row10", false);
				start_Hash.put("tAdvancedHash_row10", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row10";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row10");

				int tos_count_tAdvancedHash_row10 = 0;

				if (enableLogStash) {
					talendJobLog.addCM("tAdvancedHash_row10", "tAdvancedHash_row10", "tAdvancedHash");
					talendJobLogProcess(globalMap);
				}

				// connection name:row10
				// source node:tHashInput_1 - inputs:(after_tHashInput_2) outputs:(row10,row10)
				// | target node:tAdvancedHash_row10 - inputs:(row10) outputs:()
				// linked node: tMap_3 - inputs:(row9,row10) outputs:(ViolationCode_Desc)

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row10 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row10Struct> tHash_Lookup_row10 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row10Struct>getLookup(matchingModeEnum_row10);

				globalMap.put("tHash_Lookup_row10", tHash_Lookup_row10);

				/**
				 * [tAdvancedHash_row10 begin ] stop
				 */

				/**
				 * [tHashInput_1 begin ] start
				 */

				ok_Hash.put("tHashInput_1", false);
				start_Hash.put("tHashInput_1", System.currentTimeMillis());

				currentComponent = "tHashInput_1";

				int tos_count_tHashInput_1 = 0;

				if (enableLogStash) {
					talendJobLog.addCM("tHashInput_1", "tHashInput_1", "tHashInput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tHashInput_1 = 0;

				org.talend.designer.components.hashfile.common.MapHashFile mf_tHashInput_1 = org.talend.designer.components.hashfile.common.MapHashFile
						.getMapHashFile();
				org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row4Struct> tHashFile_tHashInput_1 = mf_tHashInput_1
						.getAdvancedMemoryHashFile("tHashFile_DataPreparation_" + pid + "_tHashOutput_1");
				if (tHashFile_tHashInput_1 == null) {
					throw new RuntimeException(
							"The hash is not initialized : The hash must exist before you read from it");
				}
				java.util.Iterator<row4Struct> iterator_tHashInput_1 = tHashFile_tHashInput_1.iterator();
				while (iterator_tHashInput_1.hasNext()) {
					row4Struct next_tHashInput_1 = iterator_tHashInput_1.next();

					row10.ViolationCodes = next_tHashInput_1.ViolationCodes;
					row10.Violation_ID = next_tHashInput_1.Violation_ID;
					row10.InspectionId = next_tHashInput_1.InspectionId;

					/**
					 * [tHashInput_1 begin ] stop
					 */

					/**
					 * [tHashInput_1 main ] start
					 */

					currentComponent = "tHashInput_1";

					tos_count_tHashInput_1++;

					/**
					 * [tHashInput_1 main ] stop
					 */

					/**
					 * [tHashInput_1 process_data_begin ] start
					 */

					currentComponent = "tHashInput_1";

					/**
					 * [tHashInput_1 process_data_begin ] stop
					 */

					/**
					 * [tAdvancedHash_row10 main ] start
					 */

					currentComponent = "tAdvancedHash_row10";

					if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

							, "row10", "tHashInput_1", "tHashInput_1", "tHashInput", "tAdvancedHash_row10",
							"tAdvancedHash_row10", "tAdvancedHash"

					)) {
						talendJobLogProcess(globalMap);
					}

					if (log.isTraceEnabled()) {
						log.trace("row10 - " + (row10 == null ? "" : row10.toLogString()));
					}

					row10Struct row10_HashRow = new row10Struct();

					row10_HashRow.ViolationCodes = row10.ViolationCodes;

					row10_HashRow.Violation_ID = row10.Violation_ID;

					row10_HashRow.InspectionId = row10.InspectionId;

					tHash_Lookup_row10.put(row10_HashRow);

					tos_count_tAdvancedHash_row10++;

					/**
					 * [tAdvancedHash_row10 main ] stop
					 */

					/**
					 * [tAdvancedHash_row10 process_data_begin ] start
					 */

					currentComponent = "tAdvancedHash_row10";

					/**
					 * [tAdvancedHash_row10 process_data_begin ] stop
					 */

					/**
					 * [tAdvancedHash_row10 process_data_end ] start
					 */

					currentComponent = "tAdvancedHash_row10";

					/**
					 * [tAdvancedHash_row10 process_data_end ] stop
					 */

					/**
					 * [tHashInput_1 process_data_end ] start
					 */

					currentComponent = "tHashInput_1";

					/**
					 * [tHashInput_1 process_data_end ] stop
					 */

					/**
					 * [tHashInput_1 end ] start
					 */

					currentComponent = "tHashInput_1";

					nb_line_tHashInput_1++;
				}

				mf_tHashInput_1.clearCache("tHashFile_DataPreparation_" + pid + "_tHashOutput_1");

				org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap
						.remove("tHashFile_DataPreparation_" + pid + "_tHashOutput_1");

				globalMap.put("tHashInput_1_NB_LINE", nb_line_tHashInput_1);

				ok_Hash.put("tHashInput_1", true);
				end_Hash.put("tHashInput_1", System.currentTimeMillis());

				/**
				 * [tHashInput_1 end ] stop
				 */

				/**
				 * [tAdvancedHash_row10 end ] start
				 */

				currentComponent = "tAdvancedHash_row10";

				tHash_Lookup_row10.endPut();

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row10", 2, 0,
						"tHashInput_1", "tHashInput_1", "tHashInput", "tAdvancedHash_row10", "tAdvancedHash_row10",
						"tAdvancedHash", "output")) {
					talendJobLogProcess(globalMap);
				}

				ok_Hash.put("tAdvancedHash_row10", true);
				end_Hash.put("tAdvancedHash_row10", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row10 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tHashInput_1 finally ] start
				 */

				currentComponent = "tHashInput_1";

				/**
				 * [tHashInput_1 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row10 finally ] start
				 */

				currentComponent = "tAdvancedHash_row10";

				/**
				 * [tAdvancedHash_row10 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tHashInput_1_SUBPROCESS_STATE", 1);
	}

	public static class row13Struct implements routines.system.IPersistableComparableLookupRow<row13Struct> {
		final static byte[] commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		static byte[] commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer Violation_ID;

		public Integer getViolation_ID() {
			return this.Violation_ID;
		}

		public Boolean Violation_IDIsNullable() {
			return true;
		}

		public Boolean Violation_IDIsKey() {
			return false;
		}

		public Integer Violation_IDLength() {
			return null;
		}

		public Integer Violation_IDPrecision() {
			return null;
		}

		public String Violation_IDDefault() {

			return null;

		}

		public String Violation_IDComment() {

			return "";

		}

		public String Violation_IDPattern() {

			return "";

		}

		public String Violation_IDOriginalDbColumnName() {

			return "Violation_ID";

		}

		public String InspectionId;

		public String getInspectionId() {
			return this.InspectionId;
		}

		public Boolean InspectionIdIsNullable() {
			return true;
		}

		public Boolean InspectionIdIsKey() {
			return false;
		}

		public Integer InspectionIdLength() {
			return 9;
		}

		public Integer InspectionIdPrecision() {
			return 0;
		}

		public String InspectionIdDefault() {

			return null;

		}

		public String InspectionIdComment() {

			return "";

		}

		public String InspectionIdPattern() {

			return "";

		}

		public String InspectionIdOriginalDbColumnName() {

			return "InspectionId";

		}

		public String ViolationCodes;

		public String getViolationCodes() {
			return this.ViolationCodes;
		}

		public Boolean ViolationCodesIsNullable() {
			return true;
		}

		public Boolean ViolationCodesIsKey() {
			return false;
		}

		public Integer ViolationCodesLength() {
			return 150;
		}

		public Integer ViolationCodesPrecision() {
			return 0;
		}

		public String ViolationCodesDefault() {

			return null;

		}

		public String ViolationCodesComment() {

			return "";

		}

		public String ViolationCodesPattern() {

			return "";

		}

		public String ViolationCodesOriginalDbColumnName() {

			return "ViolationCodes";

		}

		public String ViolationCategory;

		public String getViolationCategory() {
			return this.ViolationCategory;
		}

		public Boolean ViolationCategoryIsNullable() {
			return true;
		}

		public Boolean ViolationCategoryIsKey() {
			return false;
		}

		public Integer ViolationCategoryLength() {
			return null;
		}

		public Integer ViolationCategoryPrecision() {
			return null;
		}

		public String ViolationCategoryDefault() {

			return null;

		}

		public String ViolationCategoryComment() {

			return "";

		}

		public String ViolationCategoryPattern() {

			return "";

		}

		public String ViolationCategoryOriginalDbColumnName() {

			return "ViolationCategory";

		}

		public Integer CodeScore;

		public Integer getCodeScore() {
			return this.CodeScore;
		}

		public Boolean CodeScoreIsNullable() {
			return true;
		}

		public Boolean CodeScoreIsKey() {
			return false;
		}

		public Integer CodeScoreLength() {
			return null;
		}

		public Integer CodeScorePrecision() {
			return null;
		}

		public String CodeScoreDefault() {

			return null;

		}

		public String CodeScoreComment() {

			return "";

		}

		public String CodeScorePattern() {

			return "";

		}

		public String CodeScoreOriginalDbColumnName() {

			return "CodeScore";

		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.InspectionId == null) ? 0 : this.InspectionId.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row13Struct other = (row13Struct) obj;

			if (this.InspectionId == null) {
				if (other.InspectionId != null)
					return false;

			} else if (!this.InspectionId.equals(other.InspectionId))

				return false;

			return true;
		}

		public void copyDataTo(row13Struct other) {

			other.Violation_ID = this.Violation_ID;
			other.InspectionId = this.InspectionId;
			other.ViolationCodes = this.ViolationCodes;
			other.ViolationCategory = this.ViolationCategory;
			other.CodeScore = this.CodeScore;

		}

		public void copyKeysDataTo(row13Struct other) {

			other.InspectionId = this.InspectionId;

		}

		private Integer readInteger(DataInputStream dis, ObjectInputStream ois) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			Integer intReturn;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = unmarshaller.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_DAMG_MIDPROJECT_DataPreparation.length) {
					if (length < 1024 && commonByteArray_DAMG_MIDPROJECT_DataPreparation.length == 0) {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[1024];
					} else {
						commonByteArray_DAMG_MIDPROJECT_DataPreparation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length);
				strReturn = new String(commonByteArray_DAMG_MIDPROJECT_DataPreparation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				dis.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				unmarshaller.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.InspectionId = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_DAMG_MIDPROJECT_DataPreparation) {

				try {

					int length = 0;

					this.InspectionId = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.InspectionId, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.InspectionId, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				this.Violation_ID = readInteger(dis, ois);

				this.ViolationCodes = readString(dis, ois);

				this.ViolationCategory = readString(dis, ois);

				this.CodeScore = readInteger(dis, ois);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
			try {
				int length = 0;

				this.Violation_ID = readInteger(dis, objectIn);

				this.ViolationCodes = readString(dis, objectIn);

				this.ViolationCategory = readString(dis, objectIn);

				this.CodeScore = readInteger(dis, objectIn);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				writeInteger(this.Violation_ID, dos, oos);

				writeString(this.ViolationCodes, dos, oos);

				writeString(this.ViolationCategory, dos, oos);

				writeInteger(this.CodeScore, dos, oos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut) {
			try {

				writeInteger(this.Violation_ID, dos, objectOut);

				writeString(this.ViolationCodes, dos, objectOut);

				writeString(this.ViolationCategory, dos, objectOut);

				writeInteger(this.CodeScore, dos, objectOut);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		public boolean supportMarshaller() {
			return true;
		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Violation_ID=" + String.valueOf(Violation_ID));
			sb.append(",InspectionId=" + InspectionId);
			sb.append(",ViolationCodes=" + ViolationCodes);
			sb.append(",ViolationCategory=" + ViolationCategory);
			sb.append(",CodeScore=" + String.valueOf(CodeScore));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (Violation_ID == null) {
				sb.append("<null>");
			} else {
				sb.append(Violation_ID);
			}

			sb.append("|");

			if (InspectionId == null) {
				sb.append("<null>");
			} else {
				sb.append(InspectionId);
			}

			sb.append("|");

			if (ViolationCodes == null) {
				sb.append("<null>");
			} else {
				sb.append(ViolationCodes);
			}

			sb.append("|");

			if (ViolationCategory == null) {
				sb.append("<null>");
			} else {
				sb.append(ViolationCategory);
			}

			sb.append("|");

			if (CodeScore == null) {
				sb.append("<null>");
			} else {
				sb.append(CodeScore);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row13Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.InspectionId, other.InspectionId);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tHashInput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tHashInput_4_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tHashInput_4");
		org.slf4j.MDC.put("_subJobPid", "N2Hchg_" + subJobPidCounter.getAndIncrement());

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row13Struct row13 = new row13Struct();

				/**
				 * [tAdvancedHash_row13 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row13", false);
				start_Hash.put("tAdvancedHash_row13", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row13";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row13");

				int tos_count_tAdvancedHash_row13 = 0;

				if (enableLogStash) {
					talendJobLog.addCM("tAdvancedHash_row13", "tAdvancedHash_row13", "tAdvancedHash");
					talendJobLogProcess(globalMap);
				}

				// connection name:row13
				// source node:tHashInput_4 - inputs:(after_tHashInput_3) outputs:(row13,row13)
				// | target node:tAdvancedHash_row13 - inputs:(row13) outputs:()
				// linked node: tMap_1 - inputs:(row12,row13)
				// outputs:(DimDate,DimInspectionType,DimLocation,DimViolation,DimBusiness)

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row13 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row13Struct> tHash_Lookup_row13 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row13Struct>getLookup(matchingModeEnum_row13);

				globalMap.put("tHash_Lookup_row13", tHash_Lookup_row13);

				/**
				 * [tAdvancedHash_row13 begin ] stop
				 */

				/**
				 * [tHashInput_4 begin ] start
				 */

				ok_Hash.put("tHashInput_4", false);
				start_Hash.put("tHashInput_4", System.currentTimeMillis());

				currentComponent = "tHashInput_4";

				int tos_count_tHashInput_4 = 0;

				if (enableLogStash) {
					talendJobLog.addCM("tHashInput_4", "tHashInput_4", "tHashInput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tHashInput_4 = 0;

				org.talend.designer.components.hashfile.common.MapHashFile mf_tHashInput_4 = org.talend.designer.components.hashfile.common.MapHashFile
						.getMapHashFile();
				org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<ViolationCode_DescStruct> tHashFile_tHashInput_4 = mf_tHashInput_4
						.getAdvancedMemoryHashFile("tHashFile_DataPreparation_" + pid + "_tHashOutput_4");
				if (tHashFile_tHashInput_4 == null) {
					throw new RuntimeException(
							"The hash is not initialized : The hash must exist before you read from it");
				}
				java.util.Iterator<ViolationCode_DescStruct> iterator_tHashInput_4 = tHashFile_tHashInput_4.iterator();
				while (iterator_tHashInput_4.hasNext()) {
					ViolationCode_DescStruct next_tHashInput_4 = iterator_tHashInput_4.next();

					row13.Violation_ID = next_tHashInput_4.Violation_ID;
					row13.InspectionId = next_tHashInput_4.InspectionId;
					row13.ViolationCodes = next_tHashInput_4.ViolationCodes;
					row13.ViolationCategory = next_tHashInput_4.ViolationCategory;
					row13.CodeScore = next_tHashInput_4.CodeScore;

					/**
					 * [tHashInput_4 begin ] stop
					 */

					/**
					 * [tHashInput_4 main ] start
					 */

					currentComponent = "tHashInput_4";

					tos_count_tHashInput_4++;

					/**
					 * [tHashInput_4 main ] stop
					 */

					/**
					 * [tHashInput_4 process_data_begin ] start
					 */

					currentComponent = "tHashInput_4";

					/**
					 * [tHashInput_4 process_data_begin ] stop
					 */

					/**
					 * [tAdvancedHash_row13 main ] start
					 */

					currentComponent = "tAdvancedHash_row13";

					if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

							, "row13", "tHashInput_4", "tHashInput_4", "tHashInput", "tAdvancedHash_row13",
							"tAdvancedHash_row13", "tAdvancedHash"

					)) {
						talendJobLogProcess(globalMap);
					}

					if (log.isTraceEnabled()) {
						log.trace("row13 - " + (row13 == null ? "" : row13.toLogString()));
					}

					row13Struct row13_HashRow = new row13Struct();

					row13_HashRow.Violation_ID = row13.Violation_ID;

					row13_HashRow.InspectionId = row13.InspectionId;

					row13_HashRow.ViolationCodes = row13.ViolationCodes;

					row13_HashRow.ViolationCategory = row13.ViolationCategory;

					row13_HashRow.CodeScore = row13.CodeScore;

					tHash_Lookup_row13.put(row13_HashRow);

					tos_count_tAdvancedHash_row13++;

					/**
					 * [tAdvancedHash_row13 main ] stop
					 */

					/**
					 * [tAdvancedHash_row13 process_data_begin ] start
					 */

					currentComponent = "tAdvancedHash_row13";

					/**
					 * [tAdvancedHash_row13 process_data_begin ] stop
					 */

					/**
					 * [tAdvancedHash_row13 process_data_end ] start
					 */

					currentComponent = "tAdvancedHash_row13";

					/**
					 * [tAdvancedHash_row13 process_data_end ] stop
					 */

					/**
					 * [tHashInput_4 process_data_end ] start
					 */

					currentComponent = "tHashInput_4";

					/**
					 * [tHashInput_4 process_data_end ] stop
					 */

					/**
					 * [tHashInput_4 end ] start
					 */

					currentComponent = "tHashInput_4";

					nb_line_tHashInput_4++;
				}

				mf_tHashInput_4.clearCache("tHashFile_DataPreparation_" + pid + "_tHashOutput_4");

				org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap
						.remove("tHashFile_DataPreparation_" + pid + "_tHashOutput_4");

				globalMap.put("tHashInput_4_NB_LINE", nb_line_tHashInput_4);

				ok_Hash.put("tHashInput_4", true);
				end_Hash.put("tHashInput_4", System.currentTimeMillis());

				/**
				 * [tHashInput_4 end ] stop
				 */

				/**
				 * [tAdvancedHash_row13 end ] start
				 */

				currentComponent = "tAdvancedHash_row13";

				tHash_Lookup_row13.endPut();

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row13", 2, 0,
						"tHashInput_4", "tHashInput_4", "tHashInput", "tAdvancedHash_row13", "tAdvancedHash_row13",
						"tAdvancedHash", "output")) {
					talendJobLogProcess(globalMap);
				}

				ok_Hash.put("tAdvancedHash_row13", true);
				end_Hash.put("tAdvancedHash_row13", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row13 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tHashInput_4 finally ] start
				 */

				currentComponent = "tHashInput_4";

				/**
				 * [tHashInput_4 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row13 finally ] start
				 */

				currentComponent = "tAdvancedHash_row13";

				/**
				 * [tAdvancedHash_row13 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tHashInput_4_SUBPROCESS_STATE", 1);
	}

	public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", "RKwcGw_" + subJobPidCounter.getAndIncrement());

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [talendJobLog begin ] start
				 */

				ok_Hash.put("talendJobLog", false);
				start_Hash.put("talendJobLog", System.currentTimeMillis());

				currentComponent = "talendJobLog";

				int tos_count_talendJobLog = 0;

				for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
					org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder
							.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
							.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid)
							.custom("father_pid", fatherPid).custom("root_pid", rootPid);
					org.talend.logging.audit.Context log_context_talendJobLog = null;

					if (jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE) {
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.sourceId(jcm.sourceId)
								.sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
								.targetId(jcm.targetId).targetLabel(jcm.targetLabel)
								.targetConnectorType(jcm.targetComponentName).connectionName(jcm.current_connector)
								.rows(jcm.row_count).duration(duration).build();
						auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
						auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).duration(duration)
								.status(jcm.status).build();
						auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
								.connectorType(jcm.component_name).connectorId(jcm.component_id)
								.connectorLabel(jcm.component_label).build();
						auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {// log current component
																							// input line
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.connectorType(jcm.component_name)
								.connectorId(jcm.component_id).connectorLabel(jcm.component_label)
								.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
								.rows(jcm.total_row_number).duration(duration).build();
						auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {// log current component
																								// output/reject line
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.connectorType(jcm.component_name)
								.connectorId(jcm.component_id).connectorLabel(jcm.component_label)
								.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
								.rows(jcm.total_row_number).duration(duration).build();
						auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
						java.lang.Exception e_talendJobLog = jcm.exception;
						if (e_talendJobLog != null) {
							try (java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();
									java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
								e_talendJobLog.printStackTrace(pw_talendJobLog);
								builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,
										java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
							}
						}

						if (jcm.extra_info != null) {
							builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
						}

						log_context_talendJobLog = builder_talendJobLog
								.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
								.connectorId(jcm.component_id)
								.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label)
								.build();

						auditLogger_talendJobLog.exception(log_context_talendJobLog);
					}

				}

				/**
				 * [talendJobLog begin ] stop
				 */

				/**
				 * [talendJobLog main ] start
				 */

				currentComponent = "talendJobLog";

				tos_count_talendJobLog++;

				/**
				 * [talendJobLog main ] stop
				 */

				/**
				 * [talendJobLog process_data_begin ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog process_data_begin ] stop
				 */

				/**
				 * [talendJobLog process_data_end ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog process_data_end ] stop
				 */

				/**
				 * [talendJobLog end ] start
				 */

				currentComponent = "talendJobLog";

				ok_Hash.put("talendJobLog", true);
				end_Hash.put("talendJobLog", System.currentTimeMillis());

				/**
				 * [talendJobLog end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [talendJobLog finally ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	private final static java.util.Properties jobInfo = new java.util.Properties();
	private final static java.util.Map<String, String> mdcInfo = new java.util.HashMap<>();
	private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();

	public static void main(String[] args) {
		final DataPreparation DataPreparationClass = new DataPreparation();

		int exitCode = DataPreparationClass.runJobInTOS(args);
		if (exitCode == 0) {
			log.info("TalendJob: 'DataPreparation' - Done.");
		}

		System.exit(exitCode);
	}

	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if (path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
		readJobInfo(new java.io.File(BUILD_PATH));
	}

	private void readJobInfo(java.io.File jobInfoFile) {

		if (jobInfoFile.exists()) {
			try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
				jobInfo.load(is);
			} catch (IOException e) {

				log.debug("Read jobInfo.properties file fail: " + e.getMessage());

			}
		}
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s", projectName,
				jobName, jobInfo.getProperty("gitCommitId"), "8.0.1.20230913_0925-patch"));

	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (!"".equals(log4jLevel)) {

			if ("trace".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.TRACE);
			} else if ("debug".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.DEBUG);
			} else if ("info".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.INFO);
			} else if ("warn".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.WARN);
			} else if ("error".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.ERROR);
			} else if ("fatal".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.FATAL);
			} else if ("off".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.OFF);
			}
			org.apache.logging.log4j.core.config.Configurator
					.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());

		}

		getjobInfo();
		log.info("TalendJob: 'DataPreparation' - Start.");

		java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
		for (Object jobInfoKey : jobInfoKeys) {
			org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
		}
		org.slf4j.MDC.put("_pid", pid);
		org.slf4j.MDC.put("_rootPid", rootPid);
		org.slf4j.MDC.put("_fatherPid", fatherPid);
		org.slf4j.MDC.put("_projectName", projectName);
		org.slf4j.MDC.put("_startTimestamp", java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC)
				.format(java.time.format.DateTimeFormatter.ISO_INSTANT));
		org.slf4j.MDC.put("_jobRepositoryId", "_g3hlEG_FEe6h4vxO7oEA5w");
		org.slf4j.MDC.put("_compiledAtTimestamp", "2023-10-22T17:39:02.493258Z");

		java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
		String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
		if (mxNameTable.length == 2) {
			org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
		} else {
			org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
		}

		if (enableLogStash) {
			java.util.Properties properties_talendJobLog = new java.util.Properties();
			properties_talendJobLog.setProperty("root.logger", "audit");
			properties_talendJobLog.setProperty("encoding", "UTF-8");
			properties_talendJobLog.setProperty("application.name", "Talend Studio");
			properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
			properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
			properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
			properties_talendJobLog.setProperty("log.appender", "file");
			properties_talendJobLog.setProperty("appender.file.path", "audit.json");
			properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
			properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
			properties_talendJobLog.setProperty("host", "false");

			System.getProperties().stringPropertyNames().stream().filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()),
							System.getProperty(key)));

			org.apache.logging.log4j.core.config.Configurator
					.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);

			auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory
					.createJobAuditLogger(properties_talendJobLog);
		}

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		org.slf4j.MDC.put("_pid", pid);

		if (rootPid == null) {
			rootPid = pid;
		}

		org.slf4j.MDC.put("_rootPid", rootPid);

		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}
		org.slf4j.MDC.put("_fatherPid", fatherPid);

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		try {
			java.util.Dictionary<String, Object> jobProperties = null;
			if (inOSGi) {
				jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

				if (jobProperties != null && jobProperties.get("context") != null) {
					contextStr = (String) jobProperties.get("context");
				}
			}
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = DataPreparation.class.getClassLoader()
					.getResourceAsStream("damg_midproject/datapreparation_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = DataPreparation.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						if (inOSGi && jobProperties != null) {
							java.util.Enumeration<String> keys = jobProperties.keys();
							while (keys.hasMoreElements()) {
								String propKey = keys.nextElement();
								if (defaultProps.containsKey(propKey)) {
									defaultProps.put(propKey, (String) jobProperties.get(propKey));
								}
							}
						}
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, ContextProperties.class, parametersToEncrypt));

		org.slf4j.MDC.put("_context", contextStr);
		log.info("TalendJob: 'DataPreparation' - Started.");
		java.util.Optional.ofNullable(org.slf4j.MDC.getCopyOfContextMap()).ifPresent(mdcInfo::putAll);

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		if (enableLogStash) {
			talendJobLog.addJobStartMessage();
			try {
				talendJobLogProcess(globalMap);
			} catch (java.lang.Exception e) {
				e.printStackTrace();
			}
		}

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tDBInput_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tDBInput_1) {
			globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

			e_tDBInput_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println(
					(endUsedMemory - startUsedMemory) + " bytes memory increase when running : DataPreparation");
		}
		if (enableLogStash) {
			talendJobLog.addJobEndMessage(startTime, end, status);
			try {
				talendJobLogProcess(globalMap);
			} catch (java.lang.Exception e) {
				e.printStackTrace();
			}
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");
		resumeUtil.flush();

		org.slf4j.MDC.remove("_subJobName");
		org.slf4j.MDC.remove("_subJobPid");
		org.slf4j.MDC.remove("_systemPid");
		log.info("TalendJob: 'DataPreparation' - Finished - status: " + status + " returnCode: " + returnCode);

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 761515 characters generated by Talend Cloud Data Fabric on the October 22,
 * 2023 at 1:39:02 PM EDT
 ************************************************************************************************/